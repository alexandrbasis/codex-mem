from pathlib import Path
import hashlib,json,shutil,tarfile
r=Path('/private/tmp/codex-mem-quality-20261021-r17-sealed')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
expected={'holdout-fixture.json':'0b0904c8ef9910e629417c108795115c7c793d70dc60c45509fcd3a1930ecbc2','holdout-gold.json':'a4dddb4de20fbbcce64f6327e9087b3b3a66e661ee3e0f833c52a43ef701aa8d','author-fact-rationale.json':'7bc598bab81a334edd65253bfdb9e4629cb391ee26f276efaae1fb0982fc1100','sealed-semantic-review.json':'6a2a2d93e3965bf136d124ffc73fa75e3a234d53038f4fda6f7727767415a873','sealed-semantic-review-metadata.json':'bb1bc11acca82a583f79ab58983b8ac6ba202e034a78fc79e212cc6cfecd1a42'}
for name,digest in expected.items():assert sha(r/name)==digest,name
old=json.loads((r/'manifest.json').read_text())
backup=r/'drafts/v5-handoff';backup.mkdir()
for name in ['manifest.json','pins.json','public-validation.json','selfcheck.json','rationale-clause-selfcheck.json']:
 shutil.copy2(r/name,backup/name)
metadata=json.loads((r/'sealed-semantic-review-metadata.json').read_text())
# Preserve every private file present at sealing, except live outputs with cyclic
# hashes and the archive itself. No original review file is rewritten.
archive=r/'authoring-review-history.tar.gz'
excluded={'authoring-review-history.tar.gz','manifest.json','pins.json'}
files=[p for p in sorted(r.rglob('*')) if p.is_file() and not (p.parent==r and p.name in excluded)]
with tarfile.open(archive,'x:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(r)),recursive=False)
with tarfile.open(archive,'r:gz') as tar:
 members=[m for m in tar.getmembers() if m.isfile()]
 assert len(members)==len(files)
 for p in files:
  stored=tar.extractfile(str(p.relative_to(r))).read()
  assert hashlib.sha256(stored).hexdigest()==sha(p)
archive.chmod(0o444)
mainfiles=['author.py','holdout-fixture.json','holdout-gold.json','author-fact-rationale.json','public-validation.json','selfcheck.json','rationale-clause-selfcheck.json','sealed-semantic-review.json','sealed-semantic-review-metadata.json','finalize_manifest.py','authoring-review-history.tar.gz']
attest=old['procedural_attestation']
attest['finalizer_reads']=[{'basename':n,'sha256':sha(r/n)} for n in ['sealed-semantic-review.json','sealed-semantic-review-metadata.json']]
attest['finalizer_read_scope']='The accepted detailed receipt was hashed and archived as bytes, not parsed. Accepted metadata was parsed. Existing author manifest was read for counts and read provenance. Every sealed file was read as bytes to archive and verify preservation.'
attest['review_v3_source']='Accepted independent reviewer metadata and parent authorization; accepted detailed receipt contents were not opened by the author.'
attest['source_generator_preserved']=True
attest['archive_preservation']='Every existing private file is archived except the live root manifest, root pins and archive itself. The previous root manifest and pins are preserved inside drafts/v5-handoff.'
attest['hold_bytes_after_handoff']=True
manifest={'schema_version':1,'status':'accepted_independent_review_pre_freeze_sealed','files':{name:sha(r/name) for name in mainfiles},'counts':old['counts'],'procedural_attestation':attest,'unresolved_findings':0,'validation_errors':[],'archive_file_count':len(files),'release_status':'Not released. Parent may not open fixture, gold, rationale, detailed review or archive before actual freeze and author formal release.'}
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
pins={'schema_version':1,'status':manifest['status'],'files':{**manifest['files'],'manifest.json':sha(r/'manifest.json')},'counts':manifest['counts'],'unresolved_findings':0,'release_status':manifest['release_status']}
(r/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
for name,digest in expected.items():assert sha(r/name)==digest
print(json.dumps({'status':manifest['status'],'files':pins['files'],'pins.json':sha(r/'pins.json'),'archive_file_count':len(files),'counts':manifest['counts'],'unresolved_findings':0},indent=2))
