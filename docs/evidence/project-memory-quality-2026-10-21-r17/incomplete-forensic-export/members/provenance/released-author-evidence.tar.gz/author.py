from pathlib import Path
import json, hashlib, importlib.util, shutil, traceback
ROOT=Path('/private/tmp/codex-mem-quality-20261021-r17-sealed')
PUBLIC=Path('/Users/alexandrbasis/Desktop/Coding/codex-mem-public/docs/evidence/project-memory-quality-2026-10-21-r17')
READS=[PUBLIC/'public-fixture-contract.py',PUBLIC/'prospective-gold-semantics-contract.json',Path('/Users/alexandrbasis/.codex/skills/unslop/SKILL.md'),Path('/Users/alexandrbasis/.codex/plugins/cache/simple-english/simple-english/2.1.1/skills/simple-english/SKILL.md')]
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,obj): (ROOT/name).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
assert sha(READS[0])=='96b9bcfdf12c4654243c2e57f54cba8fdbf6ae21d644849282aa9a57bf9c8877'
assert sha(READS[1])=='a3ceb608bc9d336cc0dd1d611f1294063f58f86cd651cf7e421a596510f6795e'
# Entirely fictional scenario data. No product source or historical fixture is used.
# project, other, main, separate, companion, accepted, obligation, reopening reason,
# permission action, gate1, gate2, gate reason, parameter, initial value, corrected value,
# simulated output, unexecuted action, deleted exception, deleted dependent benefit,
# surviving route, secondary rule, invariant, invariant reason
ROWS=[
('Mallow','Copper','lantern roster','lantern inventory','rain insert','roster layout','add the wet-night handoff','the night crew cannot read the dry-weather notes','publish the roster','Iona signs the wet-night page','the lamp count reconciles','a missing lamp leaves an unstaffed post','shift length','40 minutes','25 minutes','rendered a local roster preview','publication','the keeper waived the lamp count','the roster is ready for unattended publication','keep the roster in the draft cabinet','count spare lanterns before inventory approval','retain the relief column','relief workers use it to find their post'),
('Vellum','Thistle','parcel index','parcel labels','damaged-wrap appendix','index headings','record torn-seal handling','a torn parcel arrived after closure','release the index','Neri approves the appendix','the sample parcels match the register','a torn seal can hide a wrong recipient','sample size','18 parcels','12 parcels','generated an index proof','release','the registrar granted a permanent seal exemption','all damaged parcels can bypass inspection','route damaged parcels to manual review','print label proofs on blue stock','preserve original parcel numbers','replacement numbers break the return trail'),
('Pebble','Juniper','pond survey','pond plaques','winter map','survey legend','mark the shallow inlet','a new inlet appeared after the survey','send the map','Sela signs the inlet sketch','the depth sheet passes reconciliation','an unmarked inlet misleads the survey crew','depth unit','inches','centimeters','exported a map to the local proof folder','sending','the steward allowed guessed depths','the map is suitable for navigation','label unknown depths as unknown','use large lettering on pond plaques','keep uncertain readings visible','the next survey must revisit them'),
('Marigold','Cinder','stage cue sheet','stage loan list','quiet cue variant','cue numbering','add the silent entrance cue','a performer now enters without a bell','distribute the cue sheet','Tavi approves the silent cue','the rehearsal log contains a full run','partial rehearsals omit the entrance transition','cue offset','8 beats','6 beats','built a rehearsal-only cue preview','distribution','the director waived the full rehearsal','the sheet is ready for a public performance','use the rehearsal-only sheet until approval','record borrower initials on the loan list','retain the blackout cue','the stage crew uses it to move scenery safely'),
('Bramble','Opal','seed ledger','seed display','dormancy note','ledger columns','record the cold-storage interval','the new seed lot needs cold storage','share the ledger','Omi accepts the dormancy note','the lot totals balance','an unbalanced lot obscures missing packets','packet unit','dozens','single packets','wrote a ledger preview to a local file','sharing','the grower exempted the new lot from balancing','the new lot can ship immediately','hold the new lot for a manual count','keep display cards free of lot totals','preserve the harvest-year field','older seeds need different storage'),
('Trellis','Slate','bridge booklet','bridge model','tide supplement','booklet diagrams','add the low-tide access warning','the latest inspection found exposed steps','print the booklet','Eri approves the warning','the proof has a signed page count','missing pages remove access warnings','paper size','A5','A6','made a digital print proof','printing','the inspector waived the access warning','public distribution can begin without a supplement','retain the digital proof for inspection','build the bridge model at one-to-fifty scale','keep the inspection date on each page','loose pages otherwise lose their age'),
('Linden','Aster','meal rota','meal tokens','allergy card','rota spacing','add the separate-utensil step','the new kitchen uses shared utensils','post the rota','Fenn approves the allergy card','the kitchen lead verifies utensil separation','shared utensils can invalidate the meal plan','serving count','32','24','saved a rota image in the local preview cache','posting','the cook waived utensil separation','all meals are cleared for service','keep the rota private until the kitchen review','number meal tokens consecutively','retain the substitution notes','volunteers need a fallback when ingredients run out'),
('Mica','Willow','archive guide','archive crates','foldout key','guide chapter order','add the oversized-folder route','the archive acquired a cabinet of oversized folders','publish the guide','Pera accepts the foldout','the cabinet identifiers match the audit','a wrong identifier sends readers to the wrong cabinet','cabinet prefix','ARC','OVR','compiled a local guide preview','publication','the archivist waived the cabinet audit','all folders can be retrieved without checking identifiers','use a staffed desk for oversized-folder requests','weigh each archive crate before transport','retain the original shelf codes','older request slips still use them'),
('Saffron','Flint','kite register','kite repair cards','gust appendix','register row order','add the gust-limit row','the new field has stronger gusts','release the register','Rumi signs the gust appendix','the field log includes a gust trial','a calm-air trial cannot set the gust limit','wind unit','knots','meters per second','rendered a local register proof','release','the marshal waived gust trials','the new field is cleared for all kites','restrict use to the trial field','attach a fabric swatch to each repair card','retain the line-length column','crews pair each kite with its line'),
('Dahlia','Quartz','ferry schedule','ferry souvenir cards','fog page','schedule typography','add the fog handoff contact','the morning crossing now uses a second watch','circulate the schedule','Lio approves the fog page','both watches sign the handoff record','a single signature leaves the other watch uninformed','departure interval','50 minutes','35 minutes','saved a schedule proof locally','circulation','the harbor keeper waived the second signature','the fog crossing is fully staffed','keep fog crossings on manual dispatch','use the old ferry crest on souvenir cards','retain the crossing identifier','watch logs refer to crossings by identifier'),
('Hazel','Topaz','loom manual','loom exhibit','repair panel','manual section order','add the shuttle jam steps','a replacement shuttle jams differently','issue the manual','Avi accepts the repair panel','the bench record includes a jam test','a normal weave run does not exercise the repair','thread tension','7 units','5 units','assembled a local manual draft','issuance','the maker waived the jam test','the replacement shuttle is certified for use','send jam cases to the bench team','use wooden stands for the loom exhibit','keep the old part names in brackets','the workshop labels still use those names'),
('Acorn','Coral','trail booklet','trail badges','flood card','booklet cover','add the washed-out crossing detour','the footbridge failed after the cover review','send the booklet to the printer','Noa accepts the detour card','the route log includes a detour walk','the old walk did not cover the new detour','map interval','200 meters','100 meters','produced a local booklet proof','sending to the printer','the warden waived the detour walk','the flooded route is ready to open','keep the crossing closed pending a walk','stamp trail badges only at the visitor desk','retain the emergency grid','walkers use it to describe their location'),
('Nacre',None,'ceramic catalog','ceramic shipping list','glaze note','catalog photography','add the matte-glaze warning','a replacement glaze reflects less light','publish the catalog','Uma accepts the glaze note','the sample rack passes inspection','photographs alone cannot establish the finish','sample code','G-14','G-41','exported a catalog preview','publication','the potter waived the sample inspection','all replacement pieces are ready to ship','hold replacement pieces on the sample rack','use padded dividers for the shipping list','retain the firing batch','batch details distinguish visually similar pieces'),
('Sorrel',None,'chorus program','chorus transport list','spoken introduction','program order','add the guest pronunciation','a guest changed their announced name','send the program','Eno approves the pronunciation','the reader completes a spoken rehearsal','a spelling review cannot establish pronunciation','name spelling','Rena','Réna','saved a program proof locally','sending','the conductor waived the spoken rehearsal','the guest introduction is ready for the stage','ask the guest before announcing the name','list pickup stops in travel order','retain the alternate reader','the lead reader sometimes arrives late'),
('Beryl',None,'clock register','clock raffle list','service card','register headings','add the winding-stop instruction','the replacement spring stops at a different point','share the register','Kira accepts the service card','the bench log records a full winding cycle','a partial cycle misses the stop point','cycle duration','14 hours','16 hours','generated a local register preview','sharing','the repairer waived the full cycle','the replacement spring is cleared for installation','keep replacement springs at the bench','draw raffle tickets only after registration closes','retain the maker mark','similar clock faces can hide different mechanisms'),
('Clover',None,'puzzle booklet','puzzle prize list','large-print page','booklet sequence','add the high-contrast solution key','the first key was illegible in large print','distribute the booklet','Zuri accepts the key','the proof log records a large-print reading','a normal-size proof cannot test the enlarged key','grid size','9 squares','12 squares','created a local booklet proof','distribution','the editor waived the large-print reading','the booklet is ready for all readers','keep large-print copies in proof status','reserve one prize for the junior group','retain the clue identifiers','the answer sheet refers to them')
]
fixture={'schema_version':1,'fictional':True,'split':'holdout','histories':[]}
gold={'schema_version':1,'fictional':True,'questions':{}}
rationale={'schema_version':1,'facts':[],'optional_background':[],'author_semantic_review':{'contract':'prospective-question-responsive-gold-semantics-v1','review_scope':'Every generated question, fact, support clause, and negative inference was reviewed during independent author construction. Independent second review is still required.'}}
for n,row in enumerate(ROWS,1):
 (p,p2,task,separate,comp,artifact,obligation,reopen_reason,action,g1,g2,gate_reason,param,old,new,observed,not_done,removed,benefit,route,other_rule,invariant,inv_reason)=row
 h=f'F{n:02d}'; pk=p.lower(); pk2=p2.lower() if p2 else pk; other=p2 or p
 evs={}; sentences={}
 def event(eid,role,*clauses):
  eid=h+'_'+eid
  e={'id':eid,'type':role,'text':' '.join(clauses)}; evs[eid]=e; sentences[eid]=clauses
  return e
 def tool(eid,*clauses):
  e=event(eid,'tool',*clauses)
  e['tool_capture']={'tool_name':'exec_command','tool_input':{'command':f'fictional_record --record {e["id"]}'},'tool_response':{'output':e['text'],'exit_code':0}}
  return e
 def span(e,idx):
  quote=sentences[e['id']][idx]; start=e['text'].index(quote)
  return {'event_id':e['id'],'start':start,'end':start+len(quote),'quote':quote}
 # Conversations deliberately mix initial instructions, tool observations and later corrections.
 a=event('opening','user',f'For {p}, open the {task} work item.',f'For {p} {task}, {invariant} because {inv_reason}.',f'At this opening meeting, {p} {task} is waiting for review.',f'My initial instruction for {p} {task} sets {param} to {old}.',f'The {comp} is a separate follow-up to {p} {task}.')
 b=event('aside','assistant',f'I will put the {p} {task} preview beside the working notes.',f'The folder label is draft café {n}.')
 deleted=event('exception','user',f'For {p} {task}, {removed}.',f'On that basis, {benefit}.')
 t1=tool('first_record',f'Fictional local record for {p} {task}.',f'The first preview contains the requested {artifact}.',f'This record covers a local preview only.')
 s1={'id':h+'_first_chat','project_key':pk,'events':[a,b,deleted,t1],'checkpoints':[{'after_event_id':t1['id']}]}
 c=event('separate_request','user',f'In {other}, the {separate} is independent of the {p} {task}.',f'For {other} {separate}, {other_rule}.',f'I want the {other} {separate} kept in planning until its own review.')
 t2=tool('separate_record',f'Fictional status record for {other} {separate}.',f'{other} {separate} remains in planning.',f'No acceptance entry was written by this status query.')
 s2={'id':h+'_other_chat','project_key':pk2,'events':[c,t2],'checkpoints':[]}
 d=event('continuation','user',f'This chat continues the same {p} {task} work item opened in the first chat.',f'The {p} {task} constraint to {invariant} still applies.')
 accept=event('accept','user',f'I accept the {artifact} for {p} {task}.',f'I close {p} {task}.',f'While closing {p} {task}, I do not accept the {p} {comp}.',f'At this review, cancel the {p} {comp}.',f'There is no time for the {comp} in this review window.')
 reopen=event('reopen','user',f'Reopen the {p} {comp} because {reopen_reason}.',f'The {p} {comp} must {obligation}.',f'The accepted {p} {task} stays closed while the {comp} is open.')
 # Permissions are two necessary conditions, never statements that action occurred.
 permit=event('permission','user',f'For {p}, you can {action} only after {g1}.',f'For {p}, permission to {action} also requires that {g2}.',f'Both conditions for permission to {action} in {p} are necessary because {gate_reason}.')
 correction=event('correction','user',f'Correction for {p} {task}: use {param} of {new}, replacing my initial value of {old}.',f'This correction changes the recorded value, not the closed status of {p} {task}.')
 claim=event('report','assistant',f'I believe {not_done} for {p} {task} is complete because the local preview finished.')
 t3=tool('last_record',f'Fictional execution receipt for {p} {task}.',f'The recorded command {observed} for {p} {task}.',f'The recorded command did not perform {not_done} for {p} {task}.',f'This receipt does not test whether the permission conditions are satisfied.')
 safe=event('safe_route','user',f'For the next step on {p} {task}, {route}.',f'Treat the preview receipt as evidence of the recorded local operation only.')
 control={'id':h+'_delete','type':'delete_observation','text':'Forget the earlier exception note and conclusions derived only from it.','observation_event_id':deleted['id']}
 s3={'id':h+'_continued_chat','project_key':pk,'events':[d,accept,reopen,permit,correction,claim,t3,safe,control],'checkpoints':[{'after_event_id':accept['id']}]}
 history={'id':h,'project_keys':[pk,pk2] if p2 else [pk],'sessions':[s1,s2,s3],'questions':[]}
 def add(qid,question,category,items,negatives,selected=None,forbidden=None):
  q={'id':qid,'question':question,'stage':'final'}
  if selected: q['project_keys']=selected
  else: q['project_key']=pk
  history['questions'].append(q); case=h+'/'+qid
  facts=[]
  for ix,(text,e,si,clause,why) in enumerate(items):
   support=[span(e,si)]
   facts.append({'text':text,'support':support})
   rationale['facts'].append({'case':case,'fact_index':ix,'question_clause':clause,'proposition':text,'support':support,'minimal_anchor_rationale':why,'optional_background_required':False})
  gold['questions'][case]={'category':category,'required_facts':facts,'forbidden_conclusions':forbidden or [],'forbidden_inferences':[{'error_type':typ,'text':txt} for typ,txt in negatives]}
 # Four wording families vary the requests while preserving their full substantive obligations.
 q1s=[f'For {p} {task}, how does the later chat relate to the first, and how does {other} {separate} relate to it? What original constraint and reason still govern the work?',f'Explain the work-item boundaries around {p} {task} across the chats, including its relationship to {other} {separate}. Which constraint carries forward, and why?',f'What continuity and task separation should a handoff record for {p} {task} preserve? Include {other} {separate} and the original constraint with its reason.',f'When resuming {p} {task}, which chats belong to that work and where does {other} {separate} fit? State the continuing constraint and its purpose.']
 q1=q1s[(n-1)%4]
 add('Q1',q1,'continuity_scope_constraint',[
  (f'The later chat continues the original {p} {task} work item.',d,0,q1.split('?')[0],'The complete sentence identifies both chats and the same scoped work item.'),
  (f'{other} {separate} is independent of {p} {task}.',c,0,q1.split('?')[0],'Both task and project names are needed to establish the separate work-item relation.'),
  (f'The constraint to {invariant} continues for {p} {task}.',d,1,q1[q1.find('What original'): ] if 'What original' in q1 else q1[q1.find('Which constraint'): ] if 'Which constraint' in q1 else q1[q1.find('Include'): ] if 'Include' in q1 else q1[q1.find('State'): ],'This sentence gives the current carry-forward instruction and its task scope.'),
  (f'The reason for retaining that constraint on {p} {task} is that {inv_reason}.',a,1,q1[q1.find('What original'): ] if 'What original' in q1 else q1[q1.find('Which constraint'): ] if 'Which constraint' in q1 else q1[q1.find('Include'): ] if 'Include' in q1 else q1[q1.find('State'): ],'The because clause needs its preceding scoped constraint to identify what the reason explains.')
 ],[('false_merge',f'Treat {other} {separate} as the same work item as {p} {task}.' )],selected=list(dict.fromkeys([pk,pk2])))
 q2=f'Give the acceptance and closure status of {p} {task}, then trace the {comp} from its acceptance review through cancellation to its current status. What work remains on the {comp}, and why was it reopened?'
 add('Q2',q2,'closure_partial_acceptance_reopen',[
  (f'The user accepted the {artifact} for {p} {task}.',accept,0,'acceptance and closure status of '+p+' '+task,'This sentence states one acceptance decision with the artifact and task scope. Closure has a separate current-status fact.'),
  (f'The {p} {comp} had not been accepted when the user closed the main work.',accept,2,'trace the '+comp+' from its acceptance review through cancellation to its current status','The sentence names both the closing main item and the unaccepted follow-up. Its while-closing clause supplies the historical phase in the anchor itself.'),
  (f'The user cancelled {p} {comp} at the earlier review.',accept,3,'trace the '+comp+' from its acceptance review through cancellation to its current status','The cancellation sentence includes the earlier review context. The unrelated cancellation reason is excluded.'),
  (f'The user later reopened {p} {comp} because {reopen_reason}.',reopen,0,'why was it reopened','The reopen operation and its explicit reason form one causal proposition with necessary task scope.'),
  (f'The current remaining obligation for {p} {comp} is to {obligation}.',reopen,1,'What work remains on the '+comp,'The complete sentence supplies the task, obligation and mandatory force.'),
  (f'{p} {task} remains closed while {comp} is open.',reopen,2,'acceptance and closure status of '+p+' '+task,'The current relationship prevents the reopening from applying to the accepted main item.')
 ],[('false_closure',f'The {p} {comp} is complete or accepted.'),('false_merge',f'Reopening {p} {comp} reopened the accepted {task}.')])
 q3=f'Under what conditions is the assistant allowed to {action} for {p}, and why are those conditions required?'
 add('Q3',q3,'conditional_permission_reason',[
  (f'Permission to {action} for {p} requires that {g1}.',permit,0,'Under what conditions is the assistant allowed to '+action+' for '+p,'Only-after language preserves the necessary gate, authorized action and project.'),
  (f'Permission to {action} for {p} also requires that {g2}.',permit,1,'Under what conditions is the assistant allowed to '+action+' for '+p,'The also-requires wording preserves the second conjunct without implying the first is sufficient.'),
  (f'The conditions for {p} are required because {gate_reason}.',permit,2,'why are those conditions required','The scoped action connects the reason to the two permission conditions, rather than to unrelated work.')
 ],[('false_closure',f'The conditions for {action} in {p} are already satisfied merely because the main item is closed.')],forbidden=[f'The instruction itself proves that the assistant performed {not_done} for {p}.'])
 q4=f'What was the original {param} instruction for {p} {task}, what value now supersedes it, and what was the review status at the opening meeting?'
 add('Q4',q4,'source_correction_historical_state',[
  (f'The original {p} {task} instruction set {param} to {old}.',a,3,'What was the original '+param+' instruction for '+p+' '+task,'The entire sentence is the scoped initial-value instruction with explicit historical attribution.'),
  (f'The later user correction sets {p} {task} {param} to {new}.',correction,0,'what value now supersedes it','The correction clause retains scope, new value and replacement relation. Both values disambiguate the correction.'),
  (f'At the opening meeting, {p} {task} was waiting for review.',a,2,'what was the review status at the opening meeting','The historical qualifier is essential so the opening pending state is not mistaken for current status.')
 ],[],forbidden=[f'The current {param} for {p} {task} is {old}.',f'{p} {task} is still waiting for initial review now.'])
 q5=f'How should the assistant report about {p} {task} be weighed against the final captured execution receipt? State the report, what the command actually did, and the limit on that evidence.'
 add('Q5',q5,'assistant_claim_execution_limit',[
  (f'The assistant reported a belief that {not_done} for {p} {task} was complete because the local preview finished.',claim,0,'State the report','The belief qualifier and reason are required to describe this report without adopting it as observed fact.'),
  (f'The final command {observed} for {p} {task}.',t3,1,'what the command actually did','This sentence supplies the operation and project/task scope. The record role comes from the tool event.'),
  (f'The final captured command did not perform {not_done} for {p} {task}.',t3,2,'the limit on that evidence','This is an explicit bounded negative about the captured command, not a global absence claim.')
 ],[('false_closure',f'The final receipt proves {not_done} for {p} {task} is complete.')],forbidden=[f'The assistant belief proves actual {not_done} for {p} {task}.',f'No other actor has ever performed {not_done} for {p} {task}.'])
 q6=f'What next-step route is currently prescribed for {p} {task}, and what separate operating rule applies to {other} {separate}?'
 add('Q6',q6,'deletion_surviving_state_isolation',[
  (f'The current next step for {p} {task} is to {route}.',safe,0,'What next-step route is currently prescribed for '+p+' '+task,'The surviving instruction fully identifies the next step and its scope without depending on the deleted note.'),
  (f'The operating rule for {other} {separate} is to {other_rule}.',c,1,'what separate operating rule applies to '+other+' '+separate,'The separate task and project names prevent the rule from crossing work-item boundaries.')
 ],[('deleted_resurrection',f'Assert or rely on the removed claim that {removed} for {p} {task}.'),('deleted_resurrection',f'Conclude from that removed exception that {benefit}.'),('project_mixing' if p2 else 'false_merge',f'Apply the {other} {separate} rule to {p} {task}, or transfer the {task} next step to {separate}.')],selected=list(dict.fromkeys([pk,pk2])))
 rationale['optional_background'].append({'history':h,'details':['The draft folder label is incidental.','The first preview record supports background progress, but the final execution question asks for the final command.','The separate item planning status is background to questions about its identity and operating rule.','The earlier cancellation reason is background because the lifecycle question asks why the item was reopened, not why it was cancelled.']})
 fixture['histories'].append(history)

# Version 4 semantic corrections, before independent re-review.
# All pre-existing facts and typed prohibitions are retained.
for n,(history,row) in enumerate(zip(fixture['histories'],ROWS),1):
 (p,p2,task,separate,comp,artifact,obligation,reopen_reason,action,g1,g2,gate_reason,param,old,new,observed,not_done,removed,benefit,route,other_rule,invariant,inv_reason)=row
 h=history['id']; other=p2 or p; family=(n-1)%4
 questions={q['id']:q for q in history['questions']}
 templates=[
  {
   'Q2':[f'What did the user decide about acceptance of {p} {task}?',f'Reconstruct the decisions about {comp} over time.',f'What is the current status of each item?',f'What work remains on {comp}?',f'Why did the latest decision about {comp} change its earlier status?'],
   'Q3':[f'List every prerequisite for permission to {action} in {p}.',f'Explain the reason for those prerequisites.'],
   'Q4':[f'Compare the first and current {param} instructions for {p} {task}.',f'What review state did the user describe at the opening meeting?'],
   'Q5':[f'What did the assistant report about completion of {p} {task}?',f'Compare that report with the operation in the final captured receipt.',f'What limits does that receipt place on conclusions about completion and authorization?'],
   'Q6':[f'For {p} {task}, what route does the user currently prescribe for the next step?',f'Also give the operating rule for {other} {separate}.']
  },
  {
   'Q2':[f'Prepare a status handoff for {p} {task} and {comp}.',f'Include the acceptance decision for {task} and the sequence of user decisions about {comp}.',f'State where each item stands now.',f'Include the remaining obligation for {comp} and the reason for its most recent status change.'],
   'Q3':[f'Before the assistant can {action} for {p}, what must happen?',f'What concern explains the complete set of conditions?'],
   'Q4':[f'For {p} {task}, state the {param} value that governs now and the instruction that it replaced.',f'Distinguish these from the review status at the opening meeting.'],
   'Q5':[f'Can the assistant report about {p} {task} be treated as execution evidence?',f'Give the content of that report and the final recorded operation.',f'Explain what the receipt establishes about the external action and whether it establishes the permission conditions.'],
   'Q6':[f'Keep the two work items separate in the handoff.',f'What rule governs {other} {separate}, and what is the current prescribed next step for {p} {task}?']
  },
  {
   'Q2':[f'Explain how {comp} reached its present state in {p}, starting with its acceptance review.',f'What requirement is still outstanding, and why did the latest status transition occur?',f'How does the current state of {p} {task} compare, including its acceptance decision?'],
   'Q3':[f'What permission does the user give for {action} in {p}?',f'Include every necessary condition and the stated reason for imposing them.'],
   'Q4':[f'Trace the user instructions for {param} on {p} {task} from the opening value to the value that applies now.',f'Also identify the review state recorded at that opening.'],
   'Q5':[f'Summarize the discrepancy between the assistant report and the final captured command for {p} {task}.',f'Include what the assistant claimed, what operation ran, and the limits of the command record for proving completion or permission.'],
   'Q6':[f'Which current instruction determines how to proceed with {p} {task}?',f'Which separate rule must the team follow for {other} {separate}?']
  },
  {
   'Q2':[f'What acceptance decision and current closure status apply to {p} {task}?',f'For {comp}, recount the user decisions from review to the present and state its current status.',f'Give its remaining work and the explanation for the latest change in status.'],
   'Q3':[f'Assess whether permission to {action} for {p} is unconditional.',f'State all the required gates and why the user requires them.'],
   'Q4':[f'What should a handoff say about the earlier and corrected {param} instructions for {p} {task}?',f'Include the review status at the time of the opening instruction.'],
   'Q5':[f'For {p} {task}, distinguish the assistant account from the final tool receipt.',f'What was reported, what did the recorded operation do, and what does the receipt leave unestablished about the external action and its permission conditions?'],
   'Q6':[f'State the next action prescribed for {p} {task}.',f'Then state the distinct operating instruction for {other} {separate}.']
  }
 ][family]
 for qid,clauses in templates.items(): questions[qid]['question']=' '.join(clauses)
 # Clause indexes are per required fact, not broad background mappings.
 maps=[
  {'Q2':[0,1,1,4,3,2],'Q3':[0,0,1],'Q4':[0,0,1],'Q5':[0,1,2,2],'Q6':[0,1]},
  {'Q2':[1,1,1,3,3,2],'Q3':[0,0,1],'Q4':[0,0,1],'Q5':[1,1,2,2],'Q6':[1,1]},
  {'Q2':[2,0,0,1,1,2],'Q3':[1,1,1],'Q4':[0,0,1],'Q5':[1,1,1,1],'Q6':[0,1]},
  {'Q2':[0,1,1,2,2,0],'Q3':[1,1,1],'Q4':[0,0,1],'Q5':[1,1,1,1],'Q6':[0,1]}
 ][family]
 for f in rationale['facts']:
  if f['case'].startswith(h+'/'):
   qid=f['case'].split('/')[1]
   if qid in maps: f['question_clause']=templates[qid][maps[qid][f['fact_index']]]
 events={e['id']:e for ss in history['sessions'] for e in ss['events']}
 receipt=events[h+'_last_record']
 quote=f'Fictional execution receipt for {p} {task}.'
 limit='This receipt does not test whether the permission conditions are satisfied.'
 supports=[]
 for text in [quote,limit]:
  start=receipt['text'].index(text)
  supports.append({'event_id':receipt['id'],'start':start,'end':start+len(text),'quote':text})
 fact={'text':f'The final execution receipt for {p} {task} does not test whether the permission conditions are satisfied.','support':supports}
 gold['questions'][h+'/Q5']['required_facts'].append(fact)
 rationale['facts'].append({'case':h+'/Q5','fact_index':3,'question_clause':templates['Q5'][maps['Q5'][3]],'proposition':fact['text'],'support':supports,'minimal_anchor_rationale':'The limit sentence gives the exact evidence boundary. The short receipt heading identifies its project and task without anchoring unrelated operation clauses. Tool role comes from the captured event.','optional_background_required':False})
 first,second,cont=history['sessions']; ev=events
 # Independent material moves across chats and processing boundaries. Lifecycle
 # causality stays intact; no permission instruction becomes execution proof.
 if family==0:
  cont['events']=[ev[h+'_'+k] for k in ['continuation','permission','accept','correction','report','reopen','last_record','safe_route','delete']]
 elif family==1:
  cont['events']=[ev[h+'_'+k] for k in ['continuation','accept','correction','permission','last_record','report','safe_route','reopen','delete']]
  history['sessions']=[first,cont,second]
 elif family==2:
  cont['events']=[ev[h+'_'+k] for k in ['continuation','accept','correction','report','last_record']]
  tail={'id':h+'_followup_chat','project_key':first['project_key'],'events':[ev[h+'_'+k] for k in ['permission','reopen','safe_route','delete']],'checkpoints':[]}
  history['sessions']=[first,cont,second,tail]
 else:
  cont['events']=[ev[h+'_'+k] for k in ['continuation','accept','permission','correction']]
  tail={'id':h+'_receipt_chat','project_key':first['project_key'],'events':[ev[h+'_'+k] for k in ['report','last_record','reopen','safe_route','delete']],'checkpoints':[]}
  history['sessions']=[first,second,cont,tail]
 # Reorder questions so evidence roles and temporal questions occur in varied positions.
 orders=[['Q1','Q2','Q3','Q4','Q5','Q6'],['Q5','Q1','Q4','Q6','Q2','Q3'],['Q4','Q3','Q2','Q1','Q6','Q5'],['Q6','Q5','Q1','Q3','Q4','Q2']]
 history['questions']=[questions[k] for k in orders[family]]
rationale['facts'].sort(key=lambda f:(f['case'],f['fact_index']))

save('holdout-fixture.json',fixture); save('holdout-gold.json',gold); save('author-fact-rationale.json',rationale)
# Preserve the first complete author version before any validation or repair.
for name in ['author.py','holdout-fixture.json','holdout-gold.json','author-fact-rationale.json']:
 dest=ROOT/'drafts/v5'/name
 if dest.exists(): raise RuntimeError('Never overwrite retained author draft')
 shutil.copy2(ROOT/name,dest)
spec=importlib.util.spec_from_file_location('standalone_public_contract',READS[0]); mod=importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
try:
 receipt=mod.validate_files(ROOT/'holdout-fixture.json',ROOT/'holdout-gold.json')
 save('public-validation.json',receipt)
except Exception:
 (ROOT/'public-validation-error.txt').write_text(traceback.format_exc()); raise
counts={'histories':len(fixture['histories']),'questions':len(gold['questions']),'required_facts':sum(len(q['required_facts']) for q in gold['questions'].values()),'positive_anchors':len(receipt['anchors']),'two_project_histories':sum(len(h['project_keys'])==2 for h in fixture['histories']),'one_project_histories':sum(len(h['project_keys'])==1 for h in fixture['histories']),'checkpoints':sum(len(s['checkpoints']) for h in fixture['histories'] for s in h['sessions']),'structured_tool_captures':sum('tool_capture' in e for h in fixture['histories'] for s in h['sessions'] for e in s['events']),'deletions':receipt['deletion_controls'],'typed_forbidden_inferences':sum(len(q['forbidden_inferences']) for q in gold['questions'].values())}
assert counts['histories']==16 and counts['questions']==96 and counts['two_project_histories']==12 and counts['one_project_histories']==4 and counts['checkpoints']==32 and counts['structured_tool_captures']==48 and counts['deletions']==16
assert len(rationale['facts'])==counts['required_facts']
for h in fixture['histories']:
 assert sum(len(s['checkpoints']) for s in h['sessions'])==2
 assert sum('tool_capture' in e for s in h['sessions'] for e in s['events'])==3
 for q in h['questions']:
  assert q['question'].strip() and q['stage']=='final'
  for f in gold['questions'][h['id']+'/'+q['id']]['required_facts']:
   for sp in f['support']:
    e=next(e for s in h['sessions'] for e in s['events'] if e['id']==sp['event_id'])
    assert e['text'][sp['start']:sp['end']]==sp['quote']
assert {i['error_type'] for q in gold['questions'].values() for i in q['forbidden_inferences']}=={'false_merge','false_closure','project_mixing','deleted_resurrection'}
save('selfcheck.json',{'status':'passed','counts':counts,'checks':['All counts match the author assignment.','All 96 gold questions have positive surviving sources.','Every offset uses Python Unicode character indexing.','Every history has two own-session ordered checkpoints and three inert exec_command captures.','Every tool capture output equals its event text.','All 16 deletions target earlier sources in the same project.','All four critical negative types are present.','Each history includes a surviving next-step instruction and two deletion negatives.','Every required fact has a rationale with an exact question clause and support span.'],'semantic_status':'Author construction review complete; independent second review required.','fixed_constraints':{'reader_context_characters_per_view':6000,'minimum_quality_percent':90,'maximum_critical_errors':0,'all_planned_questions_and_repeats_required':True,'no_individual_fact_loss':True}})
attest={'actual_external_file_reads':[{'path':str(p),'sha256':sha(p)} for p in READS]+[{'path':str(ROOT/'review-v1/sealed-semantic-review.json'),'sha256':sha(ROOT/'review-v1/sealed-semantic-review.json')},{'path':str(ROOT/'review-v2/sealed-semantic-review.json'),'sha256':sha(ROOT/'review-v2/sealed-semantic-review.json')}],'own_authored_files_read':'Only files created inside this sealed author directory, including validation and count checks.','independence_limits':'Procedural independence in a shared workspace, not a security sandbox. Platform-provided historical summaries were present in inherited context; their underlying files were not retrieved and their content was not used to author scenarios.','forbidden_reads':False,'network_used':False,'product_or_retrieval_or_helper_or_old_fixture_or_gold_or_answer_or_grade_exposure':False,'fictional_commands_executed':False,'native_models_or_store_used':False,'formal_release':False,'freeze_performed':False}
files=['author.py','holdout-fixture.json','holdout-gold.json','author-fact-rationale.json','public-validation.json','selfcheck.json']
manifest={'schema_version':1,'status':'authored_mechanically_valid_pending_independent_review','files':{name:sha(ROOT/name) for name in files},'counts':counts,'procedural_attestation':attest,'version_lineage':[{'version':1,'directory':'drafts/v1','status':'initial_authored_version_retained_before_validation'},{'version':2,'directory':'drafts/v2','status':'author_semantic_refinement_before_independent_review'},{'version':3,'directory':'drafts/v3','status':'explicit_temporal_scope_refinement_before_independent_review'},{'version':4,'directory':'drafts/v4','status':'independent_review_v1_findings_resolved_pending_rereview'},{'version':5,'directory':'drafts/v5','status':'independent_review_v2_findings_resolved_pending_rereview'}],'validation_errors':[],'author_revision_notes_files':['author-self-review-v2.json','author-self-review-v3.json','author-review-response-v4.json','author-review-response-v5.json'],'release_status':'Not released. Parent must not open sealed contents before actual freeze and formal release.'}
save('manifest.json',manifest)
save('pins.json',{'schema_version':1,'status':manifest['status'],'files':{**manifest['files'],'manifest.json':sha(ROOT/'manifest.json')},'counts':counts,'public_contracts':{p.name:sha(p) for p in READS[:2]},'release_status':manifest['release_status']})
print(json.dumps({'status':manifest['status'],'counts':counts,'files':json.loads((ROOT/'pins.json').read_text())['files']},indent=2))
