import sys
sys.dont_write_bytecode=True
import json,hashlib,importlib.util,collections
from pathlib import Path
import jsonschema
S=Path('/private/tmp/codex-mem-quality-20261021-r22-sealed');P=Path('/private/tmp/codex-mem-quality-20261021-r22-author-pack')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def save(n,o):
 p=S/n;assert not p.exists();p.write_text(json.dumps(o,ensure_ascii=False,indent=2)+'\n');return sha(p)
oldhash='e50cb458300dc336d4336b7b2c3433f1bfc1ef03b21fce8c2f9105da6c4cbcd1';oldmeta='65b568d3852942ea7b7645536b225a185d009edec6e4d5731291dece680d3628'
assert sha(S/'sealed-semantic-review.v001.json')==oldhash and sha(S/'sealed-semantic-review-metadata.v001.json')==oldmeta
assert sha(S/'sealed-semantic-review.json')==oldhash and sha(S/'sealed-semantic-review-metadata.json')==oldmeta
assert sha(S/'author-manifest.v003.json')=='5dcbf5e4b587ca5d3b52a08d9bbc8458d4063ba81f80423fcc3b52dfc5fdddd6'
m=read(S/'author-manifest.v003.json')
for n,h in m['generic_pack_files'].items():assert sha(P/n)==h
for n in ['holdout-fixture.json','holdout-gold.json','rationale.json','author-attestation.v003.json','mechanical-result.v003.json']:assert sha(S/n)==m['files'][n]
spec=importlib.util.spec_from_file_location('public_contract',P/'public-fixture-contract.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
mechanical=v.validate_files(S/'holdout-fixture.json',S/'holdout-gold.json')
f=read(S/'holdout-fixture.json');g=read(S/'holdout-gold.json');r=read(S/'rationale.json');rm={q['case']:q for q in r['questions']};old=read(S/'sealed-semantic-review.v001.json');om={q['case']:q for q in old['question_reviews']}
assert sha(S/'holdout-fixture.json')==old['input_hashes']['fixture_sha256']
counts=collections.Counter(histories=len(f['histories']),questions=len(g['questions']),positive_anchors=len(mechanical['anchors']),deletion_controls=mechanical['deletion_controls']);types=collections.Counter();reviews=[]
checks=['question_responsive','source_entails_proposition','all_required_conjuncts_preserved','scope_role_time_permission_preserved','minimal_sufficient_surviving_support','negative_cases_consistent']
resolutions={
'h01/q1':'The deposit proposition now names the April 8 receipt. Exact disjoint same-event spans identify "Vellum Fair receipt", "on April 8", and the deposit sentence, resolving "that receipt" without requiring the reservation count again.',
'h05/q3':'Correction and validation are now separate required propositions. Each retains both failed routes, the project and print-approval condition. The validation predicate and shared grammatical subject are exact spans from the same surviving coordinated sentence. No conjunct was dropped.',
'h06/q5':'The ingredient-sheet antecedent is explicitly named in the proposition and supplied as a short surviving source span. The sending rule retains Nila, Safa, and the ordering before allergen approval. The unasked supplier-change reason remains outside this obligation.',
'h09/q3':'Repair state and Kian ownership now occupy separate fact indexes. The state remains separate and open; the owner support combines the same-event repair subject with the assignment predicate.',
'h16/q3':'Acknowledgment state and Pia ownership now occupy separate fact indexes. The current open state and independently attributed ownership each retain the project and task. Exact subject/predicate spans support ownership without repeating the other obligation.'}
changed=[]
for h in f['histories']:
 obs=sum(e['type']!='delete_observation' for se in h['sessions'] for e in se['events']);cp=sum(len(se.get('checkpoints',[])) for se in h['sessions']);assert obs<=9 and len(h['sessions'])<=3 and cp<=2;counts.update(observations=obs,sessions=len(h['sessions']),checkpoints=cp)
 for q in h['questions']:
  k=h['id']+'/'+q['id'];entry=g['questions'][k];prior=om[k]
  assert rm[k]['question']==q['question'] and len(rm[k]['required_facts'])==len(entry['required_facts'])
  oldfacts=[{'text':a['proposition'],'support':a['support']} for a in prior['required_facts']]
  if oldfacts!=entry['required_facts']:changed.append(k)
  assert entry['forbidden_conclusions']==[x['text'] for x in entry['forbidden_inferences']]
  for n in entry['forbidden_inferences']:assert '"'+n['text']+'"' in prior['negative_case_findings']
  counts.update(required_facts=len(entry['required_facts']),typed_negatives=len(entry['forbidden_inferences']));types.update(n['error_type'] for n in entry['forbidden_inferences'])
  facts=[]
  for i,a in enumerate(entry['required_facts']):
   b=rm[k]['required_facts'][i];assert b['fact_index']==i and b['proposition']==a['text'] and b['support']==a['support']
   facts.append({'fact_index':i,'question_clause':b['question_clause'],'proposition':a['text'],'support':a['support'],'checks':dict.fromkeys(checks,True),'finding':''})
  reviews.append({'case':k,'required_facts':facts,'optional_background':prior['optional_background'],'negative_case_findings':prior['negative_case_findings'],'question_requirements_complete':True,'difficult_scenarios_preserved':True})
assert set(changed)==set(resolutions)
assert counts=={'histories':16,'questions':96,'positive_anchors':132,'deletion_controls':16,'observations':128,'sessions':48,'checkpoints':32,'required_facts':126,'typed_negatives':73}
assert counts['observations']<=144 and counts['sessions']<=48 and counts['checkpoints']<=32
assert len({q['case'] for q in reviews})==96
att='independent_author_inputs_only_no_product_prior_inputs_answers_or_grades'
hashes={'fixture_sha256':sha(S/'holdout-fixture.json'),'gold_sha256':sha(S/'holdout-gold.json'),'mechanical_contract_sha256':sha(P/'public-fixture-contract.py'),'semantic_guidance_sha256':sha(P/'prospective-gold-semantics-contract.json'),'author_fact_rationale_sha256':sha(S/'rationale.json')}
disclosure='Platform-injected general MEMORY_SUMMARY, project path and AGENTS instructions, skill catalog, tools and assigned task were visible. No empty-context claim. Deliberate inputs were limited to the approved generic pack, current independently authored inputs and provenance, and this reviewer\'s own earlier rejected review for revision lineage. No product source, historical fixture/gold/answers/grades/diagnostics, retrieval, user database/history, connected app, web, native or external model input was accessed. Only the unchanged public validator and own stdlib/jsonschema receipt code were executed with bytecode writing disabled.'
review={'schema_version':1,'status':'accepted','unresolved_findings':0,'reviewer_identity':'Independent reviewer /root/sealed_r22_semantic_reviewer. Input v003, review v002, predecessor rejected review v001. '+disclosure,'independence_attestation':att,'input_hashes':hashes,'question_reviews':reviews}
jsonschema.validate(review,read(P/'sealed-semantic-review-findings.schema.json'))
fullhash=save('sealed-semantic-review.v002.json',review)
meta={'schema_version':1,'status':'accepted','unresolved_findings':0,**{k:v for k,v in hashes.items() if k!='author_fact_rationale_sha256'},'sealed_review_receipt_sha256':fullhash,'independence_attestation':att,'coverage':{'questions':96,'required_facts':126,'all_questions_reviewed':True,'all_required_facts_reviewed':True,'negative_cases_reviewed':True}}
jsonschema.validate(meta,read(P/'sealed-semantic-review-metadata.schema.json'))
metahash=save('sealed-semantic-review-metadata.v002.json',meta)
save('sealed-semantic-review-mechanical.v002.json',{'status':mechanical['status'],'counts':dict(counts),'typed_negative_counts':dict(types)})
save('sealed-semantic-review-provenance.v002.json',{'schema_version':1,'status':'accepted','input_version':'v003','review_version':'v002','predecessor_review':'v001','predecessor_full_sha256':oldhash,'predecessor_metadata_sha256':oldmeta,'author_manifest_sha256':sha(S/'author-manifest.v003.json'),'generic_pack_pins':m['generic_pack_files'],'input_hashes':hashes,'metadata_sha256':metahash,'full_receipt_sha256':fullhash,'counts':dict(counts),'typed_negative_counts':dict(types),'unresolved_findings':0,'resolved_findings':resolutions,'disclosure':disclosure,'formal_release':False,'trial_clock_started':False,'model_calls':0,'fixed_constraints_unchanged':{'minimum_quality_percent':90,'maximum_critical_errors':0,'no_individual_fact_loss':True,'planned_slots':216}})
(S/'sealed-semantic-review.json').write_bytes((S/'sealed-semantic-review.v002.json').read_bytes());(S/'sealed-semantic-review-metadata.json').write_bytes((S/'sealed-semantic-review-metadata.v002.json').read_bytes())
assert sha(S/'sealed-semantic-review.json')==fullhash and sha(S/'sealed-semantic-review-metadata.json')==metahash
assert sha(S/'sealed-semantic-review.v001.json')==oldhash and sha(S/'sealed-semantic-review-metadata.v001.json')==oldmeta
print(json.dumps({'status':'accepted','metadata_path':str(S/'sealed-semantic-review-metadata.v002.json'),'metadata_sha256':metahash,'full_receipt_sha256':fullhash,'input_hashes':hashes,'counts':dict(counts),'unresolved_findings':0,'input_version':'v003','review_version':'v002','predecessor_review':'v001'},indent=2))
