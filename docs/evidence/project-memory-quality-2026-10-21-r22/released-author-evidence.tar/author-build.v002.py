import json,hashlib,pathlib,importlib.util,collections,sys
sys.dont_write_bytecode=True
P=pathlib.Path('/private/tmp/codex-mem-quality-20261021-r22-sealed')
A=pathlib.Path('/private/tmp/codex-mem-quality-20261021-r22-author-pack')
histories=[]; gold={}; rationale=[]
def add(projects, events, queries):
    hid=f'h{len(histories)+1:02d}'; sessions=[]; em={}
    # Exactly three chronological sessions: A, B, A; positions explicitly supplied below.
    for si,(project, rows) in enumerate(zip([projects[0],projects[1],projects[0]],events),1):
        out=[]
        for label,role,parts in rows:
            eid=hid+'_'+label
            if role=='delete_observation':
                out.append({'id':eid,'type':role,'text':'Remove this observation from retained memory.','observation_event_id':hid+'_'+parts});continue
            body=' '.join(parts); em[label]=(eid,body,parts,project,role)
            out.append({'id':eid,'type':role,'text':body})
        sessions.append({'id':hid+f'_s{si}','project_key':project,'events':out,'checkpoints':[{'after_event_id':out[-1]['id']}] if si<3 else []})
    qs=[]
    for qi,(question,selected,facts,negatives,category) in enumerate(queries,1):
        qid=f'q{qi}'; case=hid+'/'+qid
        q={'id':qid,'question':question,'stage':'final'}
        if selected=='both':q['project_keys']=projects
        else:q['project_key']=projects[int(selected)]
        qs.append(q); fs=[]; rs=[]
        for label,pi,clause in facts:
            eid,body,parts,proj,role=em[label]; quote=parts[pi];start=body.index(quote)
            support={'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote}
            fs.append({'text':quote,'support':[support]})
            rs.append({'fact_index':len(fs)-1,'question_clause':clause,'proposition':quote,'support':[support],'necessary_nearby_context':'The proposition names its actor, task, and applicable condition or time directly. Session project scope is supplied by the selected project. Source role is '+role+'.','optional_background':[]})
        gold[case]={'category':category,'required_facts':fs,'forbidden_conclusions':[n[1] for n in negatives],'forbidden_inferences':[{'error_type':n[0],'text':n[1]} for n in negatives]}
        rationale.append({'case':case,'question':question,'required_facts':rs,'optional_background':['Unasked descriptive details and other tasks in the history are not recall obligations for this question.']})
    histories.append({'id':hid,'project_keys':projects,'sessions':sessions,'questions':qs})

add(['VellumFair','CopperFair'],[
 [('a','user',['Fictional Vellum Fair: Elin may reserve six indoor stalls, but may not pay deposits.']),('old','user',['The provisional gate code for Vellum Fair is MOTH-73.']),('b','tool',['Vellum Fair receipt: all six indoor stall reservations were confirmed on April 8.','No deposit was charged on that receipt.'])],
 [('c','user',['For fictional Copper Fair, Elin may pay deposits for two outdoor stalls.']),('d','assistant',['I think the Vellum Fair booth plan is fully finished.'])],
 [('e','user',['Vellum Fair reservations are accepted as complete.','Reopen the Vellum Fair sign layout because the west entrance moved.']),('f','user',['Elin must send the revised Vellum Fair sign layout to Noor only if Noor confirms the new entrance map.','Cancel the Vellum Fair balloon order.']),('g','user',['For Vellum Fair access, Elin must ask the gate steward for a fresh code on arrival.']),('del','delete_observation','old')]
],[
 ('What did the April 8 Vellum Fair receipt confirm about reservations and deposits?','0',[('b',0,'reservations'),('b',1,'deposits')],[], 'observed_result'),
 ('Which Vellum Fair work is complete, and which work was reopened for what reason?','0',[('e',0,'Which Vellum Fair work is complete'),('e',1,'which work was reopened for what reason')],[('false_closure','The entire Vellum Fair booth plan remains complete.'),('false_merge','Reopening the sign layout also reopened the accepted stall reservations.')],'partial_and_reopen'),
 ('What must Elin do with the revised Vellum Fair layout, and under what condition?','0',[('f',0,'What must Elin do with the revised Vellum Fair layout, and under what condition?')],[('false_closure','The conditional layout delivery has already occurred.')],'conditional'),
 ('How does Elin’s deposit permission differ between Vellum Fair and Copper Fair?','both',[('a',0,'Vellum Fair'),('c',0,'Copper Fair')],[('project_mixing','Elin may pay Vellum Fair deposits under Copper Fair permission.')],'project_permissions'),
 ('What is the latest instruction for the Vellum Fair balloon order?','0',[('f',1,'latest instruction for the Vellum Fair balloon order')],[('false_closure','The balloon order was successfully delivered.')],'cancellation'),
 ('How must Elin obtain Vellum Fair access now?','0',[('g',0,'How must Elin obtain Vellum Fair access now?')],[('deleted_resurrection','Elin should use MOTH-73 for Vellum Fair access.')],'deletion_surviving_rule')
])
add(['LarchAudio','ReedAudio'],[
 [('a','user',['Fictional Larch Audio: Sumi must subtitle every interview in the spring collection.','Sumi may publish subtitles only after Ada signs the language review.']),('old','assistant',['The Larch Audio archive password is lantern09.']),('b','assistant',['I have drafted subtitles for three Larch Audio interviews; I have not submitted a publication request.'])],
 [('c','user',['Fictional Reed Audio needs subtitles only for its opening interview.']),('d','tool',['Larch Audio audit on May 2: subtitle drafts exist for three of five spring interviews.'])],
 [('e','user',['Accept the three existing Larch Audio drafts as drafts.','The two remaining Larch Audio interviews still need subtitle drafts.']),('f','user',['Cancel Larch Audio’s synthetic narrator experiment because the speakers declined voice imitation.','Ada’s language-review signature remains required before any Larch Audio subtitle publication.']),('g','user',['Sumi must enter Larch Audio through the archive’s single-use invitation flow.']),('del','delete_observation','old')]
],[
 ('What was Sumi’s original subtitle scope for Larch Audio?','0',[('a',0,'original subtitle scope for Larch Audio')],[('project_mixing','Only the opening Larch Audio interview needs subtitles.')],'scope'),
 ('What did the May 2 Larch Audio audit establish?','0',[('d',0,'What did the May 2 Larch Audio audit establish?')],[('false_closure','All five subtitle drafts existed at the audit.')],'tool_evidence'),
 ('What has been accepted in Larch Audio, and what drafting work remains?','0',[('e',0,'What has been accepted in Larch Audio'),('e',1,'what drafting work remains')],[('false_merge','Acceptance of three drafts completes drafting for all five interviews.')],'partial_acceptance'),
 ('Who must sign which review before any Larch Audio subtitles may be published?','0',[('f',1,'Who must sign which review before any Larch Audio subtitles may be published?')],[('false_closure','Draft acceptance already authorizes subtitle publication.')],'permission'),
 ('Which Larch Audio experiment was canceled, and why?','0',[('f',0,'Which Larch Audio experiment was canceled, and why?')],[], 'cancellation_reason'),
 ('What access method must Sumi use for Larch Audio now?','0',[('g',0,'What access method must Sumi use for Larch Audio now?')],[('deleted_resurrection','Use lantern09 as the Larch Audio archive password.')],'deletion_surviving_rule')
])
add(['PebbleLab','TernLab'],[
 [('a','user',['Fictional Pebble Lab: Ivo owns the seawater sample inventory, while Rhea owns freezer maintenance.']),('b','tool',['Pebble Lab inspection: freezer F2 passed its seal test on June 4.']),('old','user',['Pebble Lab’s sample transfer destination is Locker 17.'])],
 [('c','user',['In fictional Tern Lab, Rhea owns both sample inventory and freezer maintenance.']),('d','assistant',['I reported the Pebble Lab inventory closed after seeing the freezer seal result.'])],
 [('e','user',['Close Pebble Lab freezer maintenance after the June 4 pass.','Pebble Lab sample inventory is still open because two vial labels are illegible.']),('f','user',['Ivo must photograph both illegible Pebble Lab labels before requesting replacements.']),('g','user',['Pebble Lab sample transfers must wait for a destination assigned by the on-duty custodian.']),('del','delete_observation','old')]
],[
 ('Who owns the two separate Pebble Lab tasks?','0',[('a',0,'Who owns the two separate Pebble Lab tasks?')],[('project_mixing','Rhea owns Pebble Lab sample inventory.'),('false_merge','Inventory and freezer maintenance are the same Pebble Lab task.')],'ownership'),
 ('What did the June 4 Pebble Lab inspection verify?','0',[('b',0,'What did the June 4 Pebble Lab inspection verify?')],[('false_closure','The inspection verified that all sample labels were readable.')],'evidence_scope'),
 ('What did the assistant report about Pebble Lab inventory, and what prompted that report?','0',[('d',0,'What did the assistant report about Pebble Lab inventory, and what prompted that report?')],[], 'attributed_report'),
 ('What are the current states of Pebble Lab maintenance and inventory, including the reason inventory remains open?','0',[('e',0,'current states of Pebble Lab maintenance'),('e',1,'inventory, including the reason inventory remains open')],[('false_closure','Pebble Lab inventory is closed.')],'separate_states'),
 ('What must Ivo do before requesting replacement labels at Pebble Lab?','0',[('f',0,'What must Ivo do before requesting replacement labels at Pebble Lab?')],[], 'ordered_obligation'),
 ('What governs where Pebble Lab samples may be transferred now?','0',[('g',0,'What governs where Pebble Lab samples may be transferred now?')],[('deleted_resurrection','Transfer Pebble Lab samples to Locker 17.')],'deletion_surviving_rule')
])
add(['SaffronStage','IndigoStage'],[
 [('old','user',['Fictional Saffron Stage’s emergency entrance is the garden gate.']),('a','user',['Fictional Saffron Stage: Lena may rehearse the chase with foam props only.']),('b','tool',['Saffron Stage rigging ledger: the overhead banner was installed and signed off on July 11.'])],
 [('c','user',['Fictional Indigo Stage allows wooden rehearsal props after its own safety briefing.']),('d','assistant',['I recommend a public Saffron Stage dress rehearsal on Friday; this is a proposal.'])],
 [('e','user',['The Saffron Stage banner installation is complete.','Reopen Saffron Stage lighting cues to correct glare on the new banner.']),('f','user',['Lena may invite the public to the Saffron Stage rehearsal only after Mei approves the revised lighting cues.','Cancel the Saffron Stage smoke effect.']),('g','user',['Saffron Stage emergency entry must follow the route posted by the duty marshal that evening.']),('del','delete_observation','old')]
],[
 ('Which props may Lena currently use for the Saffron Stage chase rehearsal?','0',[('a',0,'Which props may Lena currently use for the Saffron Stage chase rehearsal?')],[('project_mixing','Lena may use wooden props at Saffron Stage based on Indigo Stage’s rule.')],'permission'),
 ('What Saffron Stage work is complete, and what was reopened with what purpose?','0',[('e',0,'What Saffron Stage work is complete'),('e',1,'what was reopened with what purpose')],[('false_merge','Lighting cue reopening makes the banner installation incomplete.'),('false_closure','All Saffron Stage lighting work is complete.')],'reopening'),
 ('What did the assistant propose for Saffron Stage, and was it stated as a proposal?','0',[('d',0,'What did the assistant propose for Saffron Stage, and was it stated as a proposal?')],[], 'proposal_role'),
 ('What approval must precede Lena inviting the public to Saffron Stage rehearsal?','0',[('f',0,'What approval must precede Lena inviting the public to Saffron Stage rehearsal?')],[('false_closure','The assistant’s Friday recommendation authorizes public attendance.')],'conditional_permission'),
 ('What is the latest instruction concerning the Saffron Stage smoke effect?','0',[('f',1,'latest instruction concerning the Saffron Stage smoke effect')],[], 'cancellation'),
 ('Which rule governs Saffron Stage emergency entry now?','0',[('g',0,'Which rule governs Saffron Stage emergency entry now?')],[('deleted_resurrection','The garden gate is the approved Saffron Stage emergency entrance.')],'deletion_surviving_rule')
])
add(['JuniperMap','QuartzMap'],[
 [('a','user',['Fictional Juniper Map: Oren must validate all twelve wheelchair routes before the print edition is approved.']),('b','tool',['Juniper Map route checker: ten routes passed; two routes failed the curb-width check.']),('old','assistant',['Juniper Map print files go to the blue external drive.'])],
 [('c','user',['Fictional Quartz Map needs validation of only its harbor route.']),('d','user',['For Quartz Map, a digital-only release is approved.'])],
 [('e','user',['Accept the ten passing Juniper Map routes individually.','The Juniper Map print edition remains unapproved until both failed routes are corrected and validated.']),('f','user',['Oren must ask Tavi to remeasure both failing Juniper Map curbs.','Cancel the Juniper Map foldout insert to keep the booklet pocket-sized.']),('g','user',['Juniper Map print files must be uploaded through the printer’s newly issued transfer link.']),('del','delete_observation','old')]
],[
 ('How many routes was Oren required to validate before Juniper Map print approval?','0',[('a',0,'How many routes was Oren required to validate before Juniper Map print approval?')],[('project_mixing','Only the harbor route needs validation for Juniper Map.')],'quantified_scope'),
 ('What were the Juniper Map checker results, including the failure criterion?','0',[('b',0,'What were the Juniper Map checker results, including the failure criterion?')],[], 'tool_result'),
 ('What has been accepted for Juniper Map, and what still prevents print approval?','0',[('e',0,'What has been accepted for Juniper Map'),('e',1,'what still prevents print approval')],[('false_merge','Acceptance of ten routes accepts the full print edition.'),('false_closure','The Juniper Map print edition is approved.')],'partial_acceptance'),
 ('What must Oren ask Tavi to do for Juniper Map?','0',[('f',0,'What must Oren ask Tavi to do for Juniper Map?')],[], 'actor_scope'),
 ('What Juniper Map item was canceled, and for what reason?','0',[('f',1,'What Juniper Map item was canceled, and for what reason?')],[], 'cancellation_reason'),
 ('How must Juniper Map print files be transferred now?','0',[('g',0,'How must Juniper Map print files be transferred now?')],[('deleted_resurrection','Put Juniper Map print files on the blue external drive.')],'deletion_surviving_rule')
])
add(['MarbleKitchen','WillowKitchen'],[
 [('a','user',['Fictional Marble Kitchen: Nila may test the soup recipe with staff, but may not serve it to guests.']),('old','user',['Marble Kitchen’s supplier contact is Daro at extension 481.']),('b','tool',['Marble Kitchen tasting card: eight staff rated batch B acceptable on August 6.'])],
 [('c','user',['Fictional Willow Kitchen permits guest service of its separately approved soup recipe.']),('d','assistant',['I described Marble Kitchen batch B as ready for guest service.'])],
 [('e','user',['Accept Marble Kitchen batch B for staff tastings only.','Guest service at Marble Kitchen still requires allergen review by Safa.']),('f','user',['Reopen the Marble Kitchen ingredient sheet because the stock supplier changed.','Nila must send the updated sheet to Safa before requesting allergen approval.']),('g','user',['Marble Kitchen supplier questions must go through the kitchen’s current purchasing portal.']),('del','delete_observation','old')]
],[
 ('What did the August 6 Marble Kitchen tasting card actually record?','0',[('b',0,'What did the August 6 Marble Kitchen tasting card actually record?')],[('false_closure','The tasting card records completed allergen approval.')],'evidence'),
 ('For what use is Marble Kitchen batch B accepted, and what remains required for guest service?','0',[('e',0,'For what use is Marble Kitchen batch B accepted'),('e',1,'what remains required for guest service')],[('project_mixing','Willow Kitchen’s recipe approval authorizes Marble Kitchen guest service.'),('false_merge','Staff acceptance is equivalent to guest-service approval.')],'partial_permission'),
 ('What did the assistant claim about Marble Kitchen batch B?','0',[('d',0,'What did the assistant claim about Marble Kitchen batch B?')],[], 'assistant_claim'),
 ('What Marble Kitchen document was reopened, and why?','0',[('f',0,'What Marble Kitchen document was reopened, and why?')],[('false_closure','The Marble Kitchen ingredient sheet remains closed.')],'reopening_reason'),
 ('What must Nila send to whom before requesting Marble Kitchen allergen approval?','0',[('f',1,'What must Nila send to whom before requesting Marble Kitchen allergen approval?')],[], 'prerequisite'),
 ('How must Marble Kitchen supplier questions be routed now?','0',[('g',0,'How must Marble Kitchen supplier questions be routed now?')],[('deleted_resurrection','Call Daro at extension 481 for Marble Kitchen supplier questions.')],'deletion_surviving_rule')
])
add(['OchreGarden','SilverGarden'],[
 [('a','user',['Fictional Ochre Garden: Bex owns irrigation repairs; Hal owns the planting roster.']),('b','tool',['Ochre Garden meter: irrigation pressure passed the overnight test on September 3.']),('old','user',['Ochre Garden’s seed cabinet combination is 38-12-64.'])],
 [('c','user',['Fictional Silver Garden assigns both irrigation and the planting roster to Hal.']),('d','assistant',['I marked the entire Ochre Garden opening checklist complete after the pressure test.'])],
 [('e','user',['Ochre Garden irrigation repairs are closed as successful.','Ochre Garden’s planting roster remains pending until Hal gets two volunteer confirmations.']),('f','user',['Cancel the Ochre Garden pond excavation because the soil survey found buried pipes.','Bex must buy replacement nozzles only if pressure drops again.']),('g','user',['Ochre Garden seed access requires borrowing the custodian’s supervised cabinet key.']),('del','delete_observation','old')]
],[
 ('Who owns irrigation and the planting roster in Ochre Garden?','0',[('a',0,'Who owns irrigation and the planting roster in Ochre Garden?')],[('project_mixing','Hal owns Ochre Garden irrigation repairs.')],'ownership'),
 ('Which Ochre Garden task is successfully closed, and what is still needed for the planting roster?','0',[('e',0,'Which Ochre Garden task is successfully closed'),('e',1,'what is still needed for the planting roster')],[('false_merge','The pressure pass closes the planting roster.'),('false_closure','The entire Ochre Garden opening checklist is complete.')],'task_isolation'),
 ('What did the assistant mark complete in Ochre Garden, and on what basis?','0',[('d',0,'What did the assistant mark complete in Ochre Garden, and on what basis?')],[], 'role_attribution'),
 ('What was canceled in Ochre Garden, and why?','0',[('f',0,'What was canceled in Ochre Garden, and why?')],[], 'cancellation_reason'),
 ('Under what condition must Bex buy Ochre Garden replacement nozzles?','0',[('f',1,'Under what condition must Bex buy Ochre Garden replacement nozzles?')],[('false_closure','Replacement nozzles have already been purchased.')],'conditional_obligation'),
 ('How may the Ochre Garden seed cabinet be accessed now?','0',[('g',0,'How may the Ochre Garden seed cabinet be accessed now?')],[('deleted_resurrection','Use 38-12-64 to open the Ochre Garden seed cabinet.')],'deletion_surviving_rule')
])
add(['NimbusFerry','HarborFerry'],[
 [('a','user',['Fictional Nimbus Ferry: Ren may book a training crossing for four crew, with no passengers.']),('b','tool',['Nimbus Ferry training log: the four-crew crossing finished without faults on October 9.']),('old','assistant',['Nimbus Ferry departure updates are posted on channel 26.'])],
 [('c','user',['Fictional Harbor Ferry may carry passengers on its licensed sightseeing route.']),('d','user',['Harbor Ferry’s sightseeing approval applies only to Harbor Ferry.'])],
 [('e','user',['Accept the Nimbus Ferry training crossing as complete.','Reopen Nimbus Ferry’s evacuation drill to include the new wheelchair ramp.']),('f','user',['Ren may schedule the Nimbus Ferry evacuation drill only after Uma confirms ramp installation.','Nimbus Ferry passenger trips remain prohibited during the training program.']),('g','user',['Nimbus Ferry departure updates must be obtained from the dispatch desk in person.']),('del','delete_observation','old')]
],[
 ('What was Ren allowed to book for Nimbus Ferry, including crew count and passenger restriction?','0',[('a',0,'What was Ren allowed to book for Nimbus Ferry, including crew count and passenger restriction?')],[('project_mixing','Harbor Ferry sightseeing approval permits Nimbus Ferry passengers.')],'permission_scope'),
 ('What did the October 9 Nimbus Ferry log record?','0',[('b',0,'What did the October 9 Nimbus Ferry log record?')],[], 'observed_result'),
 ('What Nimbus Ferry work is accepted as complete, and what is reopened for what purpose?','0',[('e',0,'What Nimbus Ferry work is accepted as complete'),('e',1,'what is reopened for what purpose')],[('false_merge','Reopening the evacuation drill reopens the completed crossing.'),('false_closure','The Nimbus Ferry evacuation drill is complete.')],'reopen_distinct_task'),
 ('What must happen before Ren may schedule the Nimbus Ferry evacuation drill?','0',[('f',0,'What must happen before Ren may schedule the Nimbus Ferry evacuation drill?')],[], 'conditional_permission'),
 ('What is the current rule for Nimbus Ferry passenger trips during training?','0',[('f',1,'current rule for Nimbus Ferry passenger trips during training')],[('false_closure','A fault-free training crossing authorizes passenger trips.')],'surviving_constraint'),
 ('Where must Nimbus Ferry departure updates be obtained now?','0',[('g',0,'Where must Nimbus Ferry departure updates be obtained now?')],[('deleted_resurrection','Use channel 26 for Nimbus Ferry departure updates.')],'deletion_surviving_rule')
])
add(['BirchMuseum','OpalMuseum'],[
 [('a','user',['Fictional Birch Museum: Dena must count all loaned masks before returning any crate.']),('old','user',['Birch Museum crate pickup uses dock C at noon.']),('b','tool',['Birch Museum inventory: all nine loaned masks were counted on November 5.'])],
 [('c','user',['Fictional Opal Museum returns its crates without a mask count because its loan contains books only.']),('d','assistant',['I recommend combining the Birch Museum mask return and the pedestal repair into one completion record.'])],
 [('e','user',['Birch Museum’s mask count is complete.','Birch Museum’s pedestal repair remains a separate open task assigned to Kian.']),('f','user',['Dena may return Birch Museum crates only after lender Zora signs the condition report.','Cancel Birch Museum’s extra courier booking because the lender will collect the crates.']),('g','user',['Birch Museum crate pickup must follow the appointment sent by the lender’s current dispatcher.']),('del','delete_observation','old')]
],[
 ('What mask-count obligation applied before Dena could return any Birch Museum crate?','0',[('a',0,'What mask-count obligation applied before Dena could return any Birch Museum crate?')],[('project_mixing','Birch Museum may return crates without a mask count because Opal Museum does.')],'universal_prerequisite'),
 ('What did the November 5 Birch Museum inventory establish?','0',[('b',0,'What did the November 5 Birch Museum inventory establish?')],[], 'verified_count'),
 ('What is the current state of the Birch Museum mask count and pedestal repair, and who owns the repair?','0',[('e',0,'current state of the Birch Museum mask count'),('e',1,'pedestal repair, and who owns the repair')],[('false_merge','The mask return and pedestal repair share one completion state.'),('false_closure','Kian’s pedestal repair is complete.')],'distinct_tasks'),
 ('Whose signature on what document is required before Dena may return Birch Museum crates?','0',[('f',0,'Whose signature on what document is required before Dena may return Birch Museum crates?')],[], 'permission'),
 ('Why was Birch Museum’s extra courier booking canceled?','0',[('f',1,'Why was Birch Museum’s extra courier booking canceled?')],[], 'cancellation'),
 ('What is the current rule for Birch Museum crate pickup arrangements?','0',[('g',0,'current rule for Birch Museum crate pickup arrangements')],[('deleted_resurrection','Birch Museum crates should be picked up at dock C at noon.')],'deletion_surviving_rule')
])
add(['CinderRelay','MossRelay'],[
 [('a','user',['Fictional Cinder Relay: Vesa canceled the hill race on December 2 because the footbridge was closed.']),('old','assistant',['Cinder Relay check-in is at the red school bus.']),('b','user',['Vesa reopened Cinder Relay hill-race planning on December 6 after the council reopened the footbridge.'])],
 [('c','user',['Fictional Moss Relay remains canceled despite its footbridge reopening, because its insurer withdrew coverage.']),('d','tool',['Cinder Relay inspection on December 7: the footbridge passed its load test.'])],
 [('e','user',['Cinder Relay bridge inspection is accepted as complete.','Cinder Relay hill-race registration remains closed until Tal signs the insurance renewal.']),('f','user',['Vesa must notify every previously registered Cinder Relay runner if registration reopens.']),('g','user',['Cinder Relay check-in location must be taken from the organizer’s final event notice.']),('del','delete_observation','old')]
],[
 ('When and why did Vesa cancel the Cinder Relay hill race?','0',[('a',0,'When and why did Vesa cancel the Cinder Relay hill race?')],[], 'historical_cancellation'),
 ('When and why did Vesa reopen Cinder Relay planning?','0',[('b',0,'When and why did Vesa reopen Cinder Relay planning?')],[('project_mixing','Cinder Relay remains canceled for Moss Relay’s insurer withdrawal.')],'historical_reopen'),
 ('How does the current Moss Relay cancellation differ from the decision to reopen Cinder Relay planning?','both',[('c',0,'current Moss Relay cancellation'),('b',0,'decision to reopen Cinder Relay planning')],[('project_mixing','Reopening Cinder Relay planning also reopens Moss Relay.')],'project_difference'),
 ('What Cinder Relay work is complete, and what still prevents registration reopening?','0',[('e',0,'What Cinder Relay work is complete'),('e',1,'what still prevents registration reopening')],[('false_merge','Bridge inspection acceptance authorizes race registration.'),('false_closure','Cinder Relay registration is open.')],'partial_acceptance'),
 ('Whom must Vesa notify, and under what condition, for Cinder Relay?','0',[('f',0,'Whom must Vesa notify, and under what condition, for Cinder Relay?')],[], 'conditional_all'),
 ('What source governs the Cinder Relay check-in location now?','0',[('g',0,'What source governs the Cinder Relay check-in location now?')],[('deleted_resurrection','Cinder Relay check-in is at the red school bus.')],'deletion_surviving_rule')
])
add(['TopazPress','AshPress'],[
 [('a','user',['Fictional Topaz Press: Fen proposed releasing the poetry booklet in two languages.']),('b','user',['Topaz Press editor Yara approved only the French edition for printing.']),('old','user',['Topaz Press delivery address is 14 Lantern Lane.'])],
 [('c','user',['Fictional Ash Press editor Yara approved both French and Italian editions for printing.']),('d','assistant',['I treated Yara’s Ash Press approval as permission for both Topaz Press editions.'])],
 [('e','user',['Topaz Press French proof correction is complete.','Reopen the Topaz Press Italian translation to fix the missing final stanza.']),('f','user',['Fen must send the revised Topaz Press Italian translation to Yara for a separate printing decision.','Cancel the Topaz Press bilingual slipcase.']),('g','user',['Topaz Press deliveries must use the address on the buyer’s latest confirmed purchase order.']),('del','delete_observation','old')]
],[
 ('What did Fen propose for Topaz Press, and which edition did Yara actually approve for printing?','0',[('a',0,'What did Fen propose for Topaz Press'),('b',0,'which edition did Yara actually approve for printing')],[('false_merge','Fen’s proposal itself approved both editions.')],'proposal_vs_authority'),
 ('How do Yara’s Topaz Press and Ash Press printing approvals differ?','both',[('b',0,'Topaz Press'),('c',0,'Ash Press printing approvals')],[('project_mixing','Yara approved both Topaz Press editions because both Ash Press editions were approved.')],'project_authority'),
 ('What mistaken permission did the assistant attribute to Topaz Press?','0',[('d',0,'What mistaken permission did the assistant attribute to Topaz Press?')],[], 'attributed_error'),
 ('What Topaz Press work is complete, and what was reopened for what correction?','0',[('e',0,'What Topaz Press work is complete'),('e',1,'what was reopened for what correction')],[('false_closure','The Topaz Press Italian translation is complete.')],'reopen'),
 ('What must Fen do before a new Topaz Press Italian printing decision, and what packaging was canceled?','0',[('f',0,'What must Fen do before a new Topaz Press Italian printing decision'),('f',1,'what packaging was canceled')],[], 'two_obligations'),
 ('Which address must Topaz Press deliveries use now?','0',[('g',0,'Which address must Topaz Press deliveries use now?')],[('deleted_resurrection','Deliver Topaz Press orders to 14 Lantern Lane.')],'deletion_surviving_rule')
])
add(['KestrelSchool','DuneSchool'],[
 [('a','user',['Fictional Kestrel School: Arlo must obtain consent from every guardian before displaying student portraits publicly.']),('old','assistant',['Kestrel School portrait files are stored on the public Gallery-Z folder.']),('b','tool',['Kestrel School consent ledger: consent has been received for seven of eight portraits.'])],
 [('c','user',['Fictional Dune School displays staff portraits under a separate staff agreement.']),('d','assistant',['I called the Kestrel School display ready because most guardians had replied.'])],
 [('e','user',['Accept the seven consent records for Kestrel School.','The eighth Kestrel School portrait must stay private until its guardian consents.']),('f','user',['Arlo must replace the eighth Kestrel School portrait with a blank card if consent is still missing at setup time.','The Kestrel School frame assembly is complete.']),('g','user',['Kestrel School portrait files must be accessed through individual invitations issued by the records officer.']),('del','delete_observation','old')]
],[
 ('What consent scope applies before Kestrel School student portraits can be displayed publicly?','0',[('a',0,'What consent scope applies before Kestrel School student portraits can be displayed publicly?')],[('project_mixing','Dune School’s staff agreement authorizes Kestrel School student portraits.')],'quantifier'),
 ('How much Kestrel School consent did the ledger record?','0',[('b',0,'How much Kestrel School consent did the ledger record?')],[], 'tool_record'),
 ('What consent work is accepted for Kestrel School, and what restriction remains on the eighth portrait?','0',[('e',0,'What consent work is accepted for Kestrel School'),('e',1,'what restriction remains on the eighth portrait')],[('false_closure','All eight Kestrel School portraits have public-display consent.')],'partial_acceptance'),
 ('What must Arlo do at setup if the remaining Kestrel School consent is still missing?','0',[('f',0,'What must Arlo do at setup if the remaining Kestrel School consent is still missing?')],[], 'conditional_time'),
 ('Which physical assembly task is complete at Kestrel School?','0',[('f',1,'Which physical assembly task is complete at Kestrel School?')],[('false_merge','Completed frame assembly also completes guardian consent collection.')],'genuine_closure'),
 ('How must Kestrel School portrait files be accessed now?','0',[('g',0,'How must Kestrel School portrait files be accessed now?')],[('deleted_resurrection','Access Kestrel School portraits through public Gallery-Z.')],'deletion_surviving_rule')
])
add(['AsterClock','FlintClock'],[
 [('a','user',['Fictional Aster Clock: Mira assigned gear cleaning to Sol and dial repainting to Eda.']),('b','tool',['Aster Clock bench log: gear cleaning passed inspection on February 10.']),('old','user',['Aster Clock spare springs are in drawer 42.'])],
 [('c','user',['Fictional Flint Clock assigns both gear cleaning and dial repainting to Sol.']),('d','assistant',['I reported Aster Clock restoration finished after the gear inspection.'])],
 [('e','user',['Close Aster Clock gear cleaning as accepted.','Reopen Aster Clock dial repainting because the hour numerals were copied in the wrong style.']),('f','user',['Eda may repaint the Aster Clock numerals only after Mira approves a paper sample.','Cancel Aster Clock’s optional chime upgrade.']),('g','user',['Aster Clock spare parts must be located using the conservator’s current bin register.']),('del','delete_observation','old')]
],[
 ('Who was assigned Aster Clock gear cleaning and dial repainting?','0',[('a',0,'Who was assigned Aster Clock gear cleaning and dial repainting?')],[('project_mixing','Sol owns Aster Clock dial repainting under Flint Clock’s assignment.')],'owners'),
 ('What did the Aster Clock bench log establish on February 10?','0',[('b',0,'What did the Aster Clock bench log establish on February 10?')],[], 'tool_result'),
 ('What Aster Clock task is accepted, and which task was reopened for what reason?','0',[('e',0,'What Aster Clock task is accepted'),('e',1,'which task was reopened for what reason')],[('false_closure','Aster Clock restoration is finished.'),('false_merge','The accepted gear task and reopened dial task have the same state.')],'task_states'),
 ('Whose approval of what must Eda obtain before repainting Aster Clock numerals?','0',[('f',0,'Whose approval of what must Eda obtain before repainting Aster Clock numerals?')],[], 'permission'),
 ('What is the latest instruction for Aster Clock’s chime upgrade?','0',[('f',1,'latest instruction for Aster Clock’s chime upgrade')],[], 'cancellation'),
 ('How must Aster Clock spare parts be located now?','0',[('g',0,'How must Aster Clock spare parts be located now?')],[('deleted_resurrection','Find Aster Clock spare springs in drawer 42.')],'deletion_surviving_rule')
])
add(['CoralSurvey','SlateSurvey'],[
 [('a','user',['Fictional Coral Survey: Neri must collect a tide reading at each of four coves.']),('old','assistant',['Coral Survey’s raw-data upload token is coral-fast-6.']),('b','tool',['Coral Survey logger: readings from all four coves were saved on March 12.'])],
 [('c','user',['Fictional Slate Survey collects only the western cove because its permit covers no other site.']),('d','assistant',['I said Coral Survey’s report was ready to publish after all four readings arrived.'])],
 [('e','user',['Coral Survey data collection is complete.','Coral Survey publication remains blocked until Jo verifies the instrument calibration.']),('f','user',['Neri must repeat every Coral Survey reading if Jo finds the calibration outside tolerance.','Cancel Coral Survey’s aerial photo appendix because cloud cover made it unusable.']),('g','user',['Coral Survey raw data must be uploaded using a fresh token obtained from the survey coordinator for each upload.']),('del','delete_observation','old')]
],[
 ('What was Neri’s Coral Survey collection scope, and what did the March 12 logger confirm?','0',[('a',0,'What was Neri’s Coral Survey collection scope'),('b',0,'what did the March 12 logger confirm')],[('project_mixing','Coral Survey is restricted to the western cove by Slate Survey’s permit.')],'scope_and_evidence'),
 ('What Coral Survey work is complete, and what still blocks publication?','0',[('e',0,'What Coral Survey work is complete'),('e',1,'what still blocks publication')],[('false_merge','Data collection completion is publication approval.'),('false_closure','Coral Survey is cleared to publish.')],'separate_gates'),
 ('What did the assistant say about Coral Survey publication readiness, and on what basis?','0',[('d',0,'What did the assistant say about Coral Survey publication readiness, and on what basis?')],[], 'attribution'),
 ('When must Neri repeat Coral Survey readings, and how many of them must be repeated?','0',[('f',0,'When must Neri repeat Coral Survey readings, and how many of them must be repeated?')],[], 'conditional_quantifier'),
 ('Which Coral Survey appendix was canceled, and why?','0',[('f',1,'Which Coral Survey appendix was canceled, and why?')],[], 'cancellation_reason'),
 ('What token rule applies to each Coral Survey raw-data upload now?','0',[('g',0,'What token rule applies to each Coral Survey raw-data upload now?')],[('deleted_resurrection','Use coral-fast-6 for Coral Survey raw-data uploads.')],'deletion_surviving_rule')
])
add(['EmberParade','FrostParade'],[
 [('a','user',['Fictional Ember Parade: Lio canceled the lantern float after the first battery test failed.']),('b','user',['Reopen the Ember Parade lantern float for a replacement-battery trial only.']),('old','user',['Ember Parade assembly point is the old mill yard.'])],
 [('c','user',['Fictional Frost Parade’s lantern float is approved for the full procession.']),('d','tool',['Ember Parade trial report: the replacement battery passed the twenty-minute bench test.'])],
 [('e','user',['Accept the Ember Parade replacement-battery bench trial as complete.','Ember Parade’s lantern float still needs a rolling test before procession approval.']),('f','user',['Lio must arrange the Ember Parade rolling test with Cato only if the route steward grants a closed-road slot.','Lio may not substitute Frost Parade’s approval for the Ember Parade rolling test.']),('g','user',['Ember Parade participants must use the assembly point announced in the marshal’s same-day briefing.']),('del','delete_observation','old')]
],[
 ('Why was the Ember Parade lantern float canceled initially?','0',[('a',0,'Why was the Ember Parade lantern float canceled initially?')],[], 'historical_reason'),
 ('For what limited scope was the Ember Parade lantern float reopened?','0',[('b',0,'For what limited scope was the Ember Parade lantern float reopened?')],[('false_closure','Reopening the Ember Parade float approved it for the procession.')],'limited_reopen'),
 ('What Ember Parade trial is accepted as complete, and what test remains before procession approval?','0',[('e',0,'What Ember Parade trial is accepted as complete'),('e',1,'what test remains before procession approval')],[('false_merge','The bench trial and rolling test are the same completed test.')],'partial_acceptance'),
 ('With whom and under what condition must Lio arrange Ember Parade’s rolling test?','0',[('f',0,'With whom and under what condition must Lio arrange Ember Parade’s rolling test?')],[], 'conditional_actor'),
 ('May Lio substitute Frost Parade approval for Ember Parade’s rolling test?','0',[('f',1,'May Lio substitute Frost Parade approval for Ember Parade’s rolling test?')],[('project_mixing','Frost Parade’s float approval clears Ember Parade’s float for the procession.')],'explicit_isolation'),
 ('Which assembly point rule applies to Ember Parade participants now?','0',[('g',0,'Which assembly point rule applies to Ember Parade participants now?')],[('deleted_resurrection','Ember Parade participants should assemble at the old mill yard.')],'deletion_surviving_rule')
])
add(['GarnetLibrary','HazelLibrary'],[
 [('a','user',['Fictional Garnet Library: Ziv must repair the bindings of all six donated atlases.']),('b','tool',['Garnet Library conservation log: all six atlas bindings passed inspection on April 19.']),('old','assistant',['Garnet Library donor acknowledgments must be mailed to Box 105.'])],
 [('c','user',['Fictional Hazel Library needs repairs only to its two largest atlases.']),('d','assistant',['I suggested treating Garnet Library binding repair and donor acknowledgment as one finished donation task.'])],
 [('e','user',['Garnet Library binding repair is accepted as complete.','Garnet Library donor acknowledgment remains open and belongs to Pia.']),('f','user',['Pia must send Garnet Library acknowledgments only after each donor approves the public name spelling.','Cancel Garnet Library’s proposed donor plaque because donors requested private thanks.']),('g','user',['Garnet Library acknowledgments must use each donor’s newly confirmed delivery preference.']),('del','delete_observation','old')]
],[
 ('What repair scope did Ziv have for Garnet Library?','0',[('a',0,'What repair scope did Ziv have for Garnet Library?')],[('project_mixing','Ziv needs to repair only the two largest Garnet Library atlases.')],'quantifier_scope'),
 ('What did the April 19 Garnet Library conservation log verify?','0',[('b',0,'What did the April 19 Garnet Library conservation log verify?')],[], 'tool_result'),
 ('What Garnet Library work is complete, and what remains open with which owner?','0',[('e',0,'What Garnet Library work is complete'),('e',1,'what remains open with which owner')],[('false_merge','Binding repair and donor acknowledgment are one completed task.'),('false_closure','Garnet Library donor acknowledgment is complete.')],'separate_obligations'),
 ('What approval must precede Pia sending Garnet Library acknowledgments?','0',[('f',0,'What approval must precede Pia sending Garnet Library acknowledgments?')],[], 'conditional_each'),
 ('What Garnet Library proposal was canceled, and why?','0',[('f',1,'What Garnet Library proposal was canceled, and why?')],[], 'cancellation_reason'),
 ('How must delivery be chosen for Garnet Library acknowledgments now?','0',[('g',0,'How must delivery be chosen for Garnet Library acknowledgments now?')],[('deleted_resurrection','Mail Garnet Library donor acknowledgments to Box 105.')],'deletion_surviving_rule')
])
# Move main-project observations out of the secondary project session.
for h in histories:
    secondary=h['sessions'][1]['events']
    moved=[e for e in secondary if e['id'].endswith('_d') and e['type'] in ('assistant','tool')]
    h['sessions'][1]['events']=[e for e in secondary if e not in moved]
    h['sessions'][1]['checkpoints']=[{'after_event_id':h['sessions'][1]['events'][-1]['id']}]
    h['sessions'][2]['events']=moved+h['sessions'][2]['events']
# Refine original author wording before sealing v002: independent ownership
# and result propositions receive separate, self-contained exact anchors.
revisions={
 'Fictional Vellum Fair: Elin may reserve six indoor stalls, but may not pay deposits.':[
  'Fictional Vellum Fair: Elin may reserve six indoor stalls.',
  'Elin may not pay deposits for Vellum Fair.'],
 'Fictional Copper Fair, Elin may pay deposits for two outdoor stalls.':[
  'Elin may pay deposits for two outdoor stalls at fictional Copper Fair.'],
 'Fictional Pebble Lab: Ivo owns the seawater sample inventory, while Rhea owns freezer maintenance.':[
  'Ivo owns Pebble Lab’s seawater sample inventory.',
  'Rhea owns Pebble Lab’s freezer maintenance.'],
 'Fictional Ochre Garden: Bex owns irrigation repairs; Hal owns the planting roster.':[
  'Bex owns Ochre Garden irrigation repairs.',
  'Hal owns Ochre Garden’s planting roster.'],
 'Fictional Aster Clock: Mira assigned gear cleaning to Sol and dial repainting to Eda.':[
  'Mira assigned Aster Clock gear cleaning to Sol.',
  'Mira assigned Aster Clock dial repainting to Eda.'],
 'Juniper Map route checker: ten routes passed; two routes failed the curb-width check.':[
  'Juniper Map route checker: ten routes passed.',
  'Juniper Map route checker: two routes failed the curb-width check.']
}
# The deposit question does not require the unrelated reservation permission.
only_last={'Fictional Vellum Fair: Elin may reserve six indoor stalls, but may not pay deposits.'}
for h in histories:
    em={e['id']:e for s in h['sessions'] for e in s['events'] if e['type']!='delete_observation'}
    for e in em.values():
        for old,new in revisions.items():e['text']=e['text'].replace(old,' '.join(new))
    for q in h['questions']:
        case=h['id']+'/'+q['id']; entry=gold[case]
        r=next(x for x in rationale if x['case']==case)
        facts=[]; reasons=[]
        for f,rr in zip(entry['required_facts'],r['required_facts']):
            old=f['text']; replacements=revisions.get(old,[old])
            if old in only_last:replacements=replacements[-1:]
            for text in replacements:
                quote=text;event=em[f['support'][0]['event_id']];body=event['text']
                start=body.index(quote)
                if quote.startswith('Fictional '):
                    quote=quote[len('Fictional '):];start+=len('Fictional ')
                proposition=quote
                if event['type']=='assistant':
                    if proposition.startswith('I '):proposition='The assistant '+proposition[2:]
                    elif proposition.startswith('I have '):proposition='The assistant has '+proposition[7:]
                support={'event_id':event['id'],'source_field':'body','start':start,'end':start+len(quote),'quote':quote}
                facts.append({'text':proposition,'support':[support]})
                reasons.append(dict(rr,fact_index=len(facts)-1,proposition=proposition,support=[support]))
        entry['required_facts']=facts;r['required_facts']=reasons
fixture={'schema_version':1,'fictional':True,'split':'holdout','histories':histories}
goldfile={'schema_version':1,'fictional':True,'questions':gold}
ratfile={'schema_version':1,'status':'sealed_author_rationale','fictional':True,'questions':rationale}
def write(name,value):
    (P/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
for base,value in [('holdout-fixture',fixture),('holdout-gold',goldfile),('rationale',ratfile)]:
    write(base+'.json',value);write(base+'.v002.json',value)
# Verify again immediately before executing the public mechanical contract.
pins=json.loads((A/'generic-pack-pins.json').read_text())
for name,pin in pins['files'].items():assert sha(A/name)==pin
spec=importlib.util.spec_from_file_location('public_contract',A/'public-fixture-contract.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
result=module.validate_files(P/'holdout-fixture.json',P/'holdout-gold.json')
write('mechanical-result.v002.json',result)
per=[]
for h in histories:
    entries=[gold[h['id']+'/'+q['id']] for q in h['questions']]
    es=[e for s in h['sessions'] for e in s['events']]
    row={'history_id':h['id'],'questions':len(h['questions']),'required_facts':sum(len(x['required_facts']) for x in entries),'positive_anchors':sum(len(f['support']) for x in entries for f in x['required_facts']),'typed_negatives':sum(len(x['forbidden_inferences']) for x in entries),'deletion_controls':sum(e['type']=='delete_observation' for e in es),'observations':sum(e['type']!='delete_observation' for e in es),'sessions':len(h['sessions']),'checkpoints':sum(len(s['checkpoints']) for s in h['sessions'])}
    assert row['observations']<=9 and row['sessions']<=3 and row['checkpoints']<=2
    assert max(len(e['text']) for e in es)<=600
    per.append(row)
counts={'histories':len(histories)}
for key in ['questions','required_facts','positive_anchors','typed_negatives','deletion_controls','observations','sessions','checkpoints']:counts[key]=sum(r[key] for r in per)
counts['typed_negative_counts']=dict(collections.Counter(n['error_type'] for x in gold.values() for n in x['forbidden_inferences']))
counts['maximum_event_characters']=max(len(e['text']) for h in histories for s in h['sessions'] for e in s['events'])
counts['per_history']=per
assert counts['questions']==96 and counts['deletion_controls']==16
assert counts['observations']<=144 and counts['sessions']<=48 and counts['checkpoints']<=32
attestation={'schema_version':1,'status':'authored_pending_independent_semantic_review','accepted_input_version':'v002','deliberately_accessed_inputs':[str(A/n) for n in sorted(['generic-pack-pins.json',*pins['files']])],'approved_pack_pin_verification':'All four supplied content pins verified before use and again before validator import; pins file hashed separately.','platform_injected_context_disclosure':'The platform supplied a general MEMORY_SUMMARY containing project-memory context, project path and AGENTS instructions, skill catalog, tool descriptions, and this author task. That injected context was visible. It was not retrieved by this agent. No claim of an empty context is made. The new fictional cases were composed without using remembered project names, scenarios, code, prior evaluations, or failure patterns.','deliberate_product_source_reads':0,'deliberate_prior_fixture_gold_answer_report_or_diagnostic_reads':0,'connected_app_or_database_or_history_reads':0,'web_or_native_or_external_model_calls':0,'model_use':'Only this author agent’s own reasoning; no other model invoked.','authorship':'New fictional scenarios composed in this task; no prior cases adapted.','output_access':'Read and executed own newly authored build scripts and produced sealed files within the assigned output directory. The v001 public-validator import may incidentally have created Python bytecode beside the approved validator; no additional input was read. Bytecode writing disabled for v002.','repeat_selection':'Not selected by author; awaiting blind parent selection.','release_status':'No freeze, trial clock, native gate, or formal release performed.'}
write('author-attestation.v002.json',attestation)
manifest={'schema_version':1,'status':'mechanically_valid_pending_independent_sealed_review','accepted_input_version':'v002','files':{p.name:sha(p) for p in sorted(P.iterdir()) if p.is_file() and p.name!='author-manifest.v002.json'},'generic_pack_files':{p.name:sha(p) for p in sorted(A.iterdir()) if p.is_file()},'counts':counts,'repeat_selection':{'status':'awaiting_blind_parent_selection','selected_by_author':False},'version_lineage':[{'version':'v001','status':'retained_mechanical_failure','predecessor':None},{'version':'v002','status':'corrected_before_freeze','predecessor':'v001'}],'independence_scope':'Only five approved generic pack files deliberately read; platform-injected general memory/project context disclosed in author-attestation.v002.json. No product/prior-input/answer/diagnostic access or external model calls. No formal release.'}
write('author-manifest.v002.json',manifest)
print(json.dumps({'manifest_path':str(P/'author-manifest.v002.json'),'manifest_sha256':sha(P/'author-manifest.v002.json'),'counts':counts,'mechanical_status':result['status']},indent=2))
