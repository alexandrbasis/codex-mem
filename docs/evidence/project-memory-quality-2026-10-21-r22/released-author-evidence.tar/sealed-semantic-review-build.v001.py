import sys
sys.dont_write_bytecode = True
import json, hashlib
from pathlib import Path
import jsonschema
P=Path('/private/tmp/codex-mem-quality-20261021-r22-author-pack')
S=Path('/private/tmp/codex-mem-quality-20261021-r22-sealed')
def read(p): return json.loads(p.read_text())
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def save(name,value):
    path=S/name
    assert not path.exists(), name
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
    return sha(path)
manifest=read(S/'author-manifest.v002.json')
assert sha(S/'author-manifest.v002.json')=='c2604b0705cf5108fcec490b842c3a384df29e29cf23a6ea4df2a3d7521c61f2'
for name,pin in manifest['generic_pack_files'].items(): assert sha(P/name)==pin
for name in ['holdout-fixture.json','holdout-gold.json','rationale.json','author-attestation.v002.json','mechanical-result.v002.json']: assert sha(S/name)==manifest['files'][name]
f=read(S/'holdout-fixture.json');g=read(S/'holdout-gold.json');r={q['case']:q for q in read(S/'rationale.json')['questions']}
checks=['question_responsive','source_entails_proposition','all_required_conjuncts_preserved','scope_role_time_permission_preserved','minimal_sufficient_surviving_support','negative_cases_consistent']
issues={
('h01/q1',1):(['minimal_sufficient_surviving_support'], 'The support is only "No deposit was charged on that receipt." The deictic "that receipt" requires the preceding surviving identification "Vellum Fair receipt" and April 8 context. The other fact supplies that context in a different recall obligation, but this fact\'s own anchor does not. Include the shortest sufficient antecedent span(s) from h01_b, and name the receipt in the proposition. The rationale incorrectly says the proposition names the applicable scope and time directly.'),
('h05/q3',1):(['question_responsive'], 'This fact bundles two independently required conditions: the failed routes must be "corrected" and "validated" before print approval. The question asks what still prevents approval. Both conditions are supported and retained in the text, but the contract requires one responsive proposition per required fact and splitting conjunctions when each obligation must be recalled. Separate the correction and validation conditions into independently checked facts, each retaining both-route scope and the print-approval condition. Do not drop either requirement.'),
('h06/q5',0):(['minimal_sufficient_surviving_support','scope_role_time_permission_preserved','all_required_conjuncts_preserved'], 'The question asks "What must Nila send". The fact and sole anchor say only "the updated sheet", without identifying the ingredient sheet. The preceding surviving sentence names "the Marble Kitchen ingredient sheet". Include its shortest sufficient antecedent span with the sending rule and make the document identity explicit in the proposition. The rationale\'s claim that the task is named directly is false here. This is a missing explicit answer requirement as well as insufficient support context; the recipient and ordering condition are otherwise preserved.'),
('h09/q3',1):(['question_responsive'], 'The question independently asks the repair\'s current state and "who owns the repair". The fact merges "remains a separate open task" and "assigned to Kian". Both are supported, but they are distinct responsive propositions and should be separate required facts under the atomicity requirement. Preserve repair scope and its separation from the mask count in the appropriate fact(s).'),
('h16/q3',1):(['question_responsive'], 'The question asks what remains open "with which owner". The fact conjoins "donor acknowledgment remains open" and "belongs to Pia". These are separate requested propositions. Split state and ownership into independently required facts, retaining Garnet Library and donor-acknowledgment scope in both. Both conjuncts are currently present and supported; the finding concerns atomicity, not factual falsity.')
}
reviews=[]
negative_count=0
for hist in f['histories']:
    events={e['id']:(e,ses['project_key']) for ses in hist['sessions'] for e in ses['events']}
    deleted={e['observation_event_id'] for ses in hist['sessions'] for e in ses['events'] if e['type']=='delete_observation'}
    for q in hist['questions']:
        case=hist['id']+'/'+q['id']; entry=g['questions'][case]; rr=[]
        for i,fact in enumerate(entry['required_facts']):
            ck=dict.fromkeys(checks,True)
            finding=''
            if (case,i) in issues:
                false_keys,finding=issues[(case,i)]
                for key in false_keys: ck[key]=False
            supports=[]
            for a in fact['support']:
                e,project=events[a['event_id']]
                assert e['type']!='delete_observation' and e['id'] not in deleted
                assert e['text'][a['start']:a['end']]==a['quote']
                supports.append({key:a[key] for key in ['event_id','source_field','start','end','quote']})
            rr.append({'fact_index':i,'question_clause':r[case]['required_facts'][i]['question_clause'],'proposition':fact['text'],'support':supports,'checks':ck,'finding':finding})
        negatives=[]
        for n in entry['forbidden_inferences']:
            negative_count+=1
            explanation={
              'deleted_resurrection':'Consistent: this would revive the removed source or its dependent operational conclusion; the required fact instead uses a surviving positive rule.',
              'false_closure':'Consistent: this would assert completion or authorization beyond the surviving source, including task-state, permission, or instruction-versus-occurrence distinctions.',
              'false_merge':'Consistent: this would collapse separately scoped tasks, partial acceptance, or distinct decisions into a single state.',
              'project_mixing':'Consistent: the permission, ownership, scope, or state belongs to the other project and cannot transfer to the selected project.'
            }[n['error_type']]
            negatives.append(n['error_type']+': "'+n['text']+'" — '+explanation)
        if not negatives: negatives=['No typed or untyped prohibition is attached to this question. Reviewed its positive facts against all surviving source roles, states, conditions and project scope; no additional negative inconsistency found.']
        reviews.append({'case':case,'required_facts':rr,'optional_background':['Other unasked tasks, deleted source content, and assistant opinions not requested by this question are not positive recall obligations. Source role and session project remain necessary interpretive context.'],'negative_case_findings':'\n'.join(negatives),'question_requirements_complete':case!='h06/q5','difficult_scenarios_preserved':True})
att='independent_author_inputs_only_no_product_prior_inputs_answers_or_grades'
hashes={'fixture_sha256':sha(S/'holdout-fixture.json'),'gold_sha256':sha(S/'holdout-gold.json'),'mechanical_contract_sha256':sha(P/'public-fixture-contract.py'),'semantic_guidance_sha256':sha(P/'prospective-gold-semantics-contract.json'),'author_fact_rationale_sha256':sha(S/'rationale.json')}
disclosure='Platform-injected MEMORY_SUMMARY, repository path and AGENTS instructions, skills catalog, tool descriptions, and this task were visible. No empty-context claim is made. No memory lookup, product-source read, prior fixture/gold/answer/grade/diagnostic read, database/history/app/web/native/external-model call was performed. Deliberate inputs were confined to the five approved generic pack files, current fixture/gold/rationale, current author manifest/attestation/mechanical receipt. Only the unchanged public mechanical validator and this reviewer\'s own stdlib/jsonschema receipt code were executed, with bytecode writing disabled.'
review={'schema_version':1,'status':'changes_required','unresolved_findings':len(issues),'reviewer_identity':'Independent sealed reviewer /root/sealed_r22_semantic_reviewer; input version v002; review v001. '+disclosure,'independence_attestation':att,'input_hashes':hashes,'question_reviews':reviews}
jsonschema.validate(review,read(P/'sealed-semantic-review-findings.schema.json'))
assert len(reviews)==96 and len({q['case'] for q in reviews})==96
assert sum(len(q['required_facts']) for q in reviews)==123
assert sum(bool(x['finding']) for q in reviews for x in q['required_facts'])==len(issues)
for q in reviews: assert [x['fact_index'] for x in q['required_facts']]==list(range(len(g['questions'][q['case']]['required_facts'])))
receipt_hash=save('sealed-semantic-review.v001.json',review)
assert not (S/'sealed-semantic-review.json').exists()
(S/'sealed-semantic-review.json').write_bytes((S/'sealed-semantic-review.v001.json').read_bytes())
assert sha(S/'sealed-semantic-review.json')==receipt_hash
metadata={'schema_version':1,'status':'changes_required','unresolved_findings':len(issues),**{k:v for k,v in hashes.items() if k!='author_fact_rationale_sha256'},'sealed_review_receipt_sha256':receipt_hash,'independence_attestation':att,'coverage':{'questions':96,'required_facts':123,'all_questions_reviewed':True,'all_required_facts_reviewed':True,'negative_cases_reviewed':True}}
jsonschema.validate(metadata,read(P/'sealed-semantic-review-metadata.schema.json'))
metadata_hash=save('sealed-semantic-review-metadata.v001.json',metadata)
assert not (S/'sealed-semantic-review-metadata.json').exists()
(S/'sealed-semantic-review-metadata.json').write_bytes((S/'sealed-semantic-review-metadata.v001.json').read_bytes())
assert sha(S/'sealed-semantic-review-metadata.json')==metadata_hash
provenance={'schema_version':1,'status':'changes_required','input_version':'v002','review_version':'v001','predecessor_review':None,'author_manifest_sha256':sha(S/'author-manifest.v002.json'),'generic_pack_pins':manifest['generic_pack_files'],'input_hashes':hashes,'metadata_sha256':metadata_hash,'full_receipt_sha256':receipt_hash,'counts':read(S/'sealed-semantic-review-mechanical.v001.json')['counts'],'typed_negative_counts':read(S/'sealed-semantic-review-mechanical.v001.json')['typed_negative_counts'],'unresolved_findings':len(issues),'disclosure':disclosure,'formal_release':False,'trial_clock_started':False,'model_calls':0,'fixed_constraints_unchanged':{'minimum_quality_percent':90,'maximum_critical_errors':0,'no_individual_fact_loss':True,'planned_slots':216}}
save('sealed-semantic-review-provenance.v001.json',provenance)
print(json.dumps({'status':metadata['status'],'metadata_path':str(S/'sealed-semantic-review-metadata.v001.json'),'metadata_sha256':metadata_hash,'full_receipt_sha256':receipt_hash,'counts':provenance['counts'],'unresolved_findings':len(issues),'input_version':'v002','review_version':'v001'}))
