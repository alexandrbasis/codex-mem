import json,pathlib,hashlib,sys,importlib.util,collections,copy
sys.dont_write_bytecode=True
P=pathlib.Path('/private/tmp/codex-mem-quality-20261021-r22-sealed');A=pathlib.Path('/private/tmp/codex-mem-quality-20261021-r22-author-pack')
def read(n):return json.loads((P/n).read_text())
def write(n,v):(P/n).write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
fixture=read('holdout-fixture.v002.json');gold=read('holdout-gold.v002.json');rat=read('rationale.v002.json')
events={e['id']:e for h in fixture['histories'] for s in h['sessions'] for e in s['events']}
rs={r['case']:r for r in rat['questions']}
def anchor(eid,quote):
 body=events[eid]['text'];start=body.index(quote)
 return {'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote}
def replace(case,index,specs):
 fs=[];rr=[]
 for proposition,clause,eid,quotes,context in specs:
  supports=[anchor(eid,q) for q in quotes]
  fs.append({'text':proposition,'support':supports})
  rr.append({'fact_index':0,'question_clause':clause,'proposition':proposition,'support':supports,'necessary_nearby_context':context,'optional_background':[]})
 gold['questions'][case]['required_facts'][index:index+1]=fs
 rs[case]['required_facts'][index:index+1]=rr
 for i,r in enumerate(rs[case]['required_facts']):r['fact_index']=i
replace('h01/q1',1,[('The April 8 Vellum Fair receipt records that no deposit was charged.','deposits','h01_b',['Vellum Fair receipt','on April 8','No deposit was charged on that receipt.'],'The first two spans identify the receipt and its date; the final sentence uses “that receipt” to refer to that same record. Reservation count is optional for this deposit proposition.')])
replace('h05/q3',1,[
 ('Both failed Juniper Map routes must be corrected before the print edition can be approved.','what still prevents print approval','h05_e',['The Juniper Map print edition remains unapproved until both failed routes are corrected'],'This exact prefix preserves the approval condition, both-route quantifier and correction obligation; validation is a separate required fact.'),
 ('Both failed Juniper Map routes must be validated before the print edition can be approved.','what still prevents print approval','h05_e',['The Juniper Map print edition remains unapproved until both failed routes are','validated'],'The shared sentence prefix supplies the project, both-route subject and approval condition for the coordinated validation predicate. Correction is separately required.')])
replace('h06/q5',0,[('Nila must send the updated Marble Kitchen ingredient sheet to Safa before requesting allergen approval.','What must Nila send to whom before requesting Marble Kitchen allergen approval?','h06_f',['the Marble Kitchen ingredient sheet','Nila must send the updated sheet to Safa before requesting allergen approval.'],'The first span supplies the document antecedent of “the updated sheet”; the second states the actor, recipient and required ordering. The supplier-change reason is optional for this question.')])
replace('h09/q3',1,[
 ('Birch Museum’s pedestal repair remains a separate open task.','current state of the Birch Museum mask count and pedestal repair','h09_e',['Birch Museum’s pedestal repair remains a separate open task'],'This prefix states the repair status and its separation from the preceding mask-count task. Ownership is independently required.'),
 ('Kian owns Birch Museum’s pedestal repair.','who owns the repair','h09_e',['Birch Museum’s pedestal repair','assigned to Kian'],'The subject span identifies the repair; the assignment predicate names its owner. The intervening state is independently required.')])
replace('h16/q3',1,[
 ('Garnet Library donor acknowledgment remains open.','what remains open','h16_e',['Garnet Library donor acknowledgment remains open'],'This prefix states the acknowledgment task and its current state. Ownership is separately required.'),
 ('Pia owns Garnet Library donor acknowledgment.','with which owner','h16_e',['Garnet Library donor acknowledgment','belongs to Pia'],'The subject span supplies the task and project for the ownership predicate. Open status is a separate required proposition.')])
for stem,x in [('holdout-fixture',fixture),('holdout-gold',gold),('rationale',rat)]:write(stem+'.v003.json',x);write(stem+'.json',x)
pins=json.loads((A/'generic-pack-pins.json').read_text())
for name,pin in pins['files'].items():assert sha(A/name)==pin
spec=importlib.util.spec_from_file_location('contract',A/'public-fixture-contract.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
mechanical=m.validate_files(P/'holdout-fixture.v003.json',P/'holdout-gold.v003.json');write('mechanical-result.v003.json',mechanical)
per=[]
for h in fixture['histories']:
 entries=[gold['questions'][h['id']+'/'+q['id']] for q in h['questions']];es=[e for s in h['sessions'] for e in s['events']]
 per.append({'history_id':h['id'],'questions':len(h['questions']),'required_facts':sum(len(x['required_facts']) for x in entries),'positive_anchors':sum(len(f['support']) for x in entries for f in x['required_facts']),'typed_negatives':sum(len(x['forbidden_inferences']) for x in entries),'deletion_controls':sum(e['type']=='delete_observation' for e in es),'observations':sum(e['type']!='delete_observation' for e in es),'sessions':len(h['sessions']),'checkpoints':sum(len(s['checkpoints']) for s in h['sessions'])})
counts={'histories':len(per)}
for k in ['questions','required_facts','positive_anchors','typed_negatives','deletion_controls','observations','sessions','checkpoints']:counts[k]=sum(r[k] for r in per)
counts['typed_negative_counts']=dict(collections.Counter(n['error_type'] for x in gold['questions'].values() for n in x['forbidden_inferences']))
counts['maximum_event_characters']=max(len(e['text']) for e in events.values());counts['per_history']=per
assert counts['questions']==96 and counts['deletion_controls']==16 and counts['observations']<=144 and counts['sessions']<=48 and counts['checkpoints']<=32
for row in per:assert row['observations']<=9 and row['sessions']<=3 and row['checkpoints']<=2
att=read('author-attestation.v002.json');att['accepted_input_version']='v003';att['status']='revised_pending_independent_semantic_review'
att['deliberately_accessed_inputs'].append(str(P/'sealed-semantic-review.v001.json'))
att['review_input_sha256']='e50cb458300dc336d4336b7b2c3433f1bfc1ef03b21fce8c2f9105da6c4cbcd1'
att['revision_scope']='Addressed the five private semantic findings by refining required-fact atomicity and sufficient surviving support context. Fixture and questions remain byte-identical to v002; all previous versions and review files retained unchanged. Author does not claim independent review acceptance.'
att['count_definitions']={'maximum_event_characters':'Maximum Python len(event["text"]) over all events, including deletion controls, excluding nested tool_capture fields.'}
write('author-attestation.v003.json',att)
manifest=read('author-manifest.v002.json');manifest['accepted_input_version']='v003';manifest['status']='mechanically_valid_pending_independent_sealed_review';manifest['counts']=counts
manifest['version_lineage'].append({'version':'v003','status':'semantic_revision_pending_independent_review','predecessor':'v002'})
manifest['independence_scope']='Only approved generic pack inputs and authorized sealed review v001 deliberately read beyond own author outputs. Platform-injected general memory/project context and incidental v001 bytecode artifact disclosed. No product/prior-trial/answer/diagnostic access or external model calls. No formal release.'
manifest['files']={p.name:sha(p) for p in sorted(P.iterdir()) if p.is_file() and p.name!='author-manifest.v003.json'}
write('author-manifest.v003.json',manifest)
print(json.dumps({'manifest_path':str(P/'author-manifest.v003.json'),'manifest_sha256':sha(P/'author-manifest.v003.json'),'counts':{k:v for k,v in counts.items() if k!='per_history'},'mechanical_status':mechanical['status'],'fixture_unchanged':sha(P/'holdout-fixture.v003.json')==sha(P/'holdout-fixture.v002.json'),'fixture_sha256':sha(P/'holdout-fixture.v003.json'),'gold_sha256':sha(P/'holdout-gold.v003.json'),'rationale_sha256':sha(P/'rationale.v003.json')},indent=2))
