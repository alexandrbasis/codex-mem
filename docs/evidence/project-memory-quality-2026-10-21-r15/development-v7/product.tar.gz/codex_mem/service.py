"""A small, local queue for bounded observation processing.

The service deliberately stores only project scheduling metadata.  Observation
text remains in :mod:`codex_mem.store`, where the processor leases it just
before a worker runs.  Hooks (or a future CLI) explicitly enqueue an approved
project. Opt-in project memory also discovers bounded durable pending work;
this module never scans the filesystem or starts itself at login.

``run_service`` is the foreground worker used by the packaged CLI.  The
``start_service`` helper starts one detached ``service run`` child, guarded by
an atomic startup reservation and a child-owned PID lock.  Stopping is a
durable request observed between bounded processor invocations; it never sends
signals to a PID that might have been reused by an unrelated process.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import errno
import json
import math
import os
from pathlib import Path
import secrets
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
from typing import Any

try:  # The supported host platforms provide flock; retain a stdlib fallback.
    import fcntl
except ImportError:  # pragma: no cover - Windows does not provide flock
    fcntl = None  # type: ignore[assignment]

from .config import automatic_capture_enabled, data_dir_path, hooks_disabled, load_config, project_memory_enabled
from . import __version__
from .processor import (
    DEFAULT_TIMEOUT, INVALID_RESPONSE_REASONS, MODEL, PROCESSOR_ID, REASONING_EFFORT, process_pending,
)
from .store import MAX_LEASE_SECONDS, project_key
from .observation_diagnostics import RUNNER_FAILURE_REASONS as _RUNNER_REASONS, safe_storage_failure_detail


SERVICE_STATE_FILENAME = "service-state.json"
SERVICE_STATE_LOCK_FILENAME = ".service-state.lock"
SERVICE_PID_FILENAME = "service.pid"
SERVICE_STARTUP_FILENAME = ".service-starting.json"
SERVICE_STARTUP_ENV = "CODEX_MEM_SERVICE_STARTUP_NONCE"

STATE_VERSION = 1
MAX_STATE_BYTES = 256 * 1024
MAX_QUEUED_PROJECTS = 256
MAX_TIMEOUT_RETRIES = 5
DEFAULT_MAX_TIMEOUT_RETRIES = 2
MAX_LEASE_RECOVERY_RETRIES = 2
MAX_PRECLAIM_STORAGE_RETRIES = 2
MAX_RUNNER_FAILURE_RETRIES = 2
MAX_UNKNOWN_RUNNER_FAILURE_RETRIES = 1
COOLDOWN_BACKOFF_SECONDS = 3600.0
MAX_COOLDOWN_BACKOFF_SECONDS = 6 * 3600.0
_TRANSPORT_FAILURE_CODES = frozenset({"runner_unavailable", "protocol_error"})
MAX_PROCESSOR_WORKERS = 4
WORKER_RECOVERY_SUCCESSES = 4
DEFAULT_POLL_INTERVAL = 1.0
DEFAULT_STARTUP_TIMEOUT = 3.0
DEFAULT_STARTUP_TTL = 15.0
DEFAULT_BACKOFF_SECONDS = 5.0
MAX_BACKOFF_SECONDS = 300.0
_INFLIGHT_GRACE_SECONDS = 10.0
_SAFE_CODE_CHARS = set("abcdefghijklmnopqrstuvwxyz0123456789_-")
_PARK_REASONS = {"not_selected", "processor_disabled", "semantic_disabled", "rejected_batches"}
# Only fixed backend codes belong in queue metadata. Syntax checks alone
# would also accept private text or tokens that happen to look like a code.
_INDEX_FAILURE_CODES = frozenset({
    "embedding_failed", "invalid_embedding_input", "invalid_embedding", "indexing_failed",
    "dependency_missing", "dependency_version_mismatch", "runtime_unavailable",
    "model_not_ready", "model_layout_invalid", "model_hash_mismatch", "storage_failure",
    "storage_protocol_error", "document_too_large", "chunking_failed", "invalid_chunking",
    "invalid_document", "invalid_embedding_prefix", "tokenizer_failure",
})
_CONTENT_REJECTION_REASONS = frozenset({
    "invalid_json", "invalid_output_shape", "invalid_note_shape", "invalid_source_ids",
    "unknown_source_handle", "invalid_disposition", "too_many_notes", "missing_required_summary",
    "skipped_with_content", "processed_without_content", "invalid_observation_metadata",
    "source_attribution_conflict", "invalid_summary_shape", "invalid_summary_attribution",
    "future_summary_source", "invalid_summary_text", "invalid_summary_metadata", "empty_session_summary", "invalid_text", "invalid_tags",
    "jev_quality_rejected", "jev_quality_uncertain", "jev_quality_input_limit",
})
_TRANSIENT_RUNNER_REASONS = frozenset({
    "jev_filter_timeout", "jev_filter_transport", "jev_filter_invalid_response", "jev_filter_failure",
    "native_rate_limit", "native_server_error", "native_connection_error",
})


class ServiceError(RuntimeError):
    """A stable, non-sensitive local service error."""


class ServiceAlreadyRunning(ServiceError):
    """Raised internally when a live service PID lock already exists."""


class ServiceStateError(ServiceError):
    """Raised when durable queue metadata is unavailable or malformed."""


class _IndexFailure(ServiceError):
    """Carry only allowlisted metadata from a failed indexer receipt."""

    def __init__(self, receipt: Mapping[str, Any]) -> None:
        super().__init__("index_failure")
        self.detail = _index_failure_detail(receipt)


def enqueue(
    project: str | os.PathLike[str],
    data_dir: str | os.PathLike[str] | None = None,
    *,
    retry_failed: bool = False,
    coalesce_seconds: float = 0,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]] = load_config,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Durably schedule one explicitly approved project.

    The queue holds no observation text or model output. A normal enqueue
    wakes a project with quarantined batches without retrying those batches.
    Non-retryable or exhausted failures still require explicit recovery.
    """

    if not isinstance(retry_failed, bool):
        raise ValueError("retry_failed must be true or false")
    if (isinstance(coalesce_seconds, bool) or not isinstance(coalesce_seconds, (int, float))
            or not math.isfinite(coalesce_seconds) or not 0 <= coalesce_seconds <= 5):
        raise ValueError("coalesce_seconds must be between 0 and 5")
    workspace = project_key(project)
    eligible, reason, _, _ = _eligibility(workspace, data_dir, config_loader)
    if not eligible:
        return {"status": "disabled", "project": workspace, "reason": reason}

    now = _checked_now(clock)
    base = _base_dir(data_dir)
    with _state_lock(base):
        state = _load_state(base)
        projects = state["projects"]
        record = projects.get(workspace)
        if record is None:
            if len(projects) >= MAX_QUEUED_PROJECTS:
                raise ServiceError("service queue is full")
            # An explicit retry can be the first queue record created after a
            # Store-level observation or embedding failure.  Preserve the
            # caller's decision even though this service state has not itself
            # recorded a blocked failure yet.
            projects[workspace] = _new_record(now, retry_requested=retry_failed)
            if coalesce_seconds and not retry_failed:
                projects[workspace]["capture_due_at"] = now + coalesce_seconds
                projects[workspace]["due_at"] = now + coalesce_seconds
            _write_state(base, state)
            return {"status": "queued", "project": workspace}

        if record["blocked"] and not retry_failed:
            return {"status": "blocked", "project": workspace, "code": record["last_code"]}

        if retry_failed:
            _preserve_retry_target(record)
            record["storage_attempts"] = 0
        # Only automatic tool captures coalesce. Keep the first deadline,
        # so an uninterrupted stream cannot postpone processing indefinitely.
        # Ordinary writes and lifecycle boundaries clear the capture delay.
        if not coalesce_seconds or retry_failed:
            record["capture_due_at"] = None
        elif not record["attempts"] and not record["retry_requested"] and not record["pending_retries"]:
            if record["capture_due_at"] is None and (
                    record["parked"] is not None or record["inflight_generation"] is not None):
                record["capture_due_at"] = now + coalesce_seconds
        record["generation"] += 1
        record["fresh_work_due"] = True
        # Fresh captures must not turn a scheduled recovery into a retry
        # storm. Only an explicit recovery can override the durable backoff.
        if retry_failed or not record["attempts"]:
            record["due_at"] = (record["capture_due_at"]
                                if record["capture_due_at"] is not None
                                else min(record["due_at"], now))
        record["parked"] = None
        # Keep an explicit retry request distinct from the queue's local
        # failure state.  This permits recovery of a Store job that failed
        # outside an earlier service run.
        if retry_failed:
            record["retry_requested"] = True
            record["retry_generation"] = record["generation"]
            record["retry_job_id"] = None
            record["retry_error_code"] = None
            record["retry_attempt_count"] = None
        if record["blocked"]:
            record["blocked"] = False
            record["attempts"] = 0
            record["last_code"] = None
            # Store deliberately requires an explicit retry signal after a
            # failed leased observation job.  Keep that signal separate from
            # the service's timeout-backoff counter.
            record["retry_requested"] = True
            record["retry_generation"] = record["generation"]
            record["retry_job_id"] = None
            record["retry_error_code"] = None
            record["retry_attempt_count"] = None
        _write_state(base, state)
        return {"status": "queued", "project": workspace}


def resume_pending(
    project: str | os.PathLike[str],
    data_dir: str | os.PathLike[str] | None = None,
    *,
    rejected_job_id: str,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]] = load_config,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Resume independent work after inspecting an exact rejected batch.

    This recovers legacy project-wide invalid_response blocks. It never
    changes or retries the rejected Store job; retry_failed remains false.
    Other project failures cannot be cleared through this narrower operation.
    """

    workspace = project_key(project)
    eligible, reason, _, _ = _eligibility(workspace, data_dir, config_loader)
    if not eligible:
        return {"status": "disabled", "project": workspace, "reason": reason}
    base = _base_dir(data_dir)
    if not _persisted_rejection(base, workspace, rejected_job_id):
        return {"status": "blocked", "project": workspace, "code": "rejection_unavailable"}
    now = _checked_now(clock)
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(workspace)
        if record is not None and record["blocked"]:
            reason_code = record["last_rejected_reason"]
            if (record["last_code"] != "invalid_response"
                    or (reason_code is not None and reason_code not in _CONTENT_REJECTION_REASONS)):
                return {"status": "blocked", "project": workspace, "code": record["last_code"],
                        "reason_code": reason_code}
        if record is None:
            if len(state["projects"]) >= MAX_QUEUED_PROJECTS:
                raise ServiceError("service queue is full")
            record = state["projects"][workspace] = _new_record(now)
        if record["inflight_generation"] is not None:
            return {"status": "blocked", "project": workspace, "code": "work_inflight"}
        _preserve_retry_target(record)
        _record_rejection(record, rejected_job_id)
        record["generation"] += 1
        record["blocked"] = False
        record["parked"] = None
        record["due_at"] = now
        record["attempts"] = 0
        record["retry_requested"] = False
        record["retry_generation"] = None
        record["retry_job_id"] = None
        record["retry_error_code"] = None
        record["retry_attempt_count"] = None
        _write_state(base, state)
    return {"status": "queued", "project": workspace,
            "rejected_job_id": rejected_job_id, "retry_failed": False}


def resume_storage_pending(
    project: str | os.PathLike[str],
    data_dir: str | os.PathLike[str] | None = None,
    *,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]] = load_config,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Explicitly resume fresh work after repairing a preclaim storage failure.

    No durable failed job is retried. Existing exact retry permissions keep
    their attempt selectors and deadlines, and running leases remain exclusive.
    """
    workspace = project_key(project)
    eligible, reason, _, _ = _eligibility(workspace, data_dir, config_loader)
    if not eligible:
        return {"status": "disabled", "project": workspace, "reason": reason}
    base = _base_dir(data_dir)
    now = _checked_now(clock)
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(workspace)
        if record is None or not record["blocked"] or record["last_code"] != "storage_failure":
            return {"status": "blocked", "project": workspace, "code": "blocker_unavailable"}
        detail = safe_storage_failure_detail(record["last_failure_detail"])
        if (record["last_failure_job"] is not None or detail is None
                or detail["operation"] not in {"open", "reconcile", "claim", "lease_lookup"}
                or record["retry_requested"]):
            return {"status": "blocked", "project": workspace, "code": "preclaim_failure_unavailable"}
        if record["inflight_generation"] is not None:
            return {"status": "blocked", "project": workspace, "code": "work_inflight"}
        if not _project_leases_clear(base, workspace, now):
            return {"status": "blocked", "project": workspace, "code": "lease_unavailable"}
        target_count = len(record["pending_retries"]) + int(record["retry_job_id"] is not None)
        if target_count >= MAX_PROCESSOR_WORKERS:
            return {"status": "blocked", "project": workspace, "code": "retry_capacity_unavailable"}
        record["generation"] += 1
        record["blocked"] = False
        record["parked"] = None
        record["capture_due_at"] = None
        record["fresh_work_due"] = True
        record["last_code"] = "invalid_response" if record["rejected_batches"] else None
        if not target_count:
            record["attempts"] = 0
            record["storage_attempts"] = 0
            record["due_at"] = now
        _write_state(base, state)
    return {"status": "queued", "project": workspace, "retry_failed": False}


def _project_leases_clear(base: Path, project: str, now: float) -> bool:
    """Fail closed on missing or ambiguous durable lease metadata."""
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        rows = connection.execute(
            "SELECT lease_expires_at FROM observation_jobs WHERE project=? AND status='running'",
            (project,),
        ).fetchall()
        for row in rows:
            if not isinstance(row[0], str):
                return False
            expiry = datetime.fromisoformat(row[0].replace("Z", "+00:00"))
            if expiry.tzinfo is None or expiry > datetime.fromtimestamp(now, timezone.utc):
                return False
        return True
    except (OSError, sqlite3.Error, ServiceError, ValueError, OverflowError):
        return False
    finally:
        if connection is not None:
            connection.close()


def recover_runner_failure(
    project: str | os.PathLike[str],
    data_dir: str | os.PathLike[str] | None = None,
    *,
    job_id: str,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]] = load_config,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Explicitly retry one inspected runner failure, preserving quarantine."""
    return _recover_operational_failure(project, data_dir, job_id=job_id, code="runner_failure",
                                        config_loader=config_loader, clock=clock)


def recover_storage_failure(
    project: str | os.PathLike[str],
    data_dir: str | os.PathLike[str] | None = None,
    *,
    job_id: str,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]] = load_config,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Retry one inspected storage failure after its cause has been repaired."""
    return _recover_operational_failure(project, data_dir, job_id=job_id, code="storage_failure",
                                        config_loader=config_loader, clock=clock)


def _recover_operational_failure(
    project: str | os.PathLike[str], data_dir: str | os.PathLike[str] | None, *,
    job_id: str, code: str,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]],
    clock: Callable[[], float],
) -> dict[str, Any]:
    if code not in {"runner_failure", "storage_failure"}:
        raise ValueError("unsupported operational recovery code")
    workspace = project_key(project)
    eligible, reason, _, _ = _eligibility(workspace, data_dir, config_loader)
    if not eligible:
        return {"status": "disabled", "project": workspace, "reason": reason}
    base = _base_dir(data_dir)
    now = _checked_now(clock)
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(workspace)
        if record is None:
            return {"status": "blocked", "project": workspace, "code": "blocker_unavailable"}
        if record["inflight_generation"] is not None:
            return {"status": "blocked", "project": workspace, "code": "work_inflight"}
        scheduled_target = None
        if not record["blocked"]:
            # Explicit recovery may accelerate one exact scheduled runner
            # retry after its cause is repaired. Keep the attempt-bound claim
            # and all other lanes' cooldowns; never widen to failed batches.
            if (code == "runner_failure" and record["last_code"] in {None, code, "invalid_response"}
                    and record["parked"] is None and not record["retry_requested"]):
                targets = [_retry_target(record), *record["pending_retries"]]
                matching = [target for target in targets if target["job_id"] == job_id
                            and target["error_code"] == code]
                if len(matching) == 1:
                    snapshot = _runner_failure_snapshot(base, workspace, job_id)
                    if (snapshot is not None
                            and snapshot["attempt_count"] == matching[0]["attempt_count"]
                            and snapshot["reason_code"] in _TRANSIENT_RUNNER_REASONS):
                        scheduled_target = matching[0]
            if scheduled_target is None:
                return {"status": "blocked", "project": workspace, "code": "blocker_unavailable"}
        elif record["last_code"] != code:
            return {"status": "blocked", "project": workspace, "code": record["last_code"]}
        if not _persisted_failed_batch(base, workspace, job_id, code):
            return {"status": "blocked", "project": workspace, "code": "failed_claim_unavailable"}
        if scheduled_target is None:
            _preserve_retry_target(record)
        elif record["retry_job_id"] != job_id:
            # Swap a selected pending retry into the active slot. Removing it
            # first reserves space for the previous active permission.
            record["pending_retries"] = [target for target in record["pending_retries"]
                                         if target["job_id"] != job_id]
            _preserve_retry_target(record)
        record["generation"] += 1
        record["blocked"] = False
        record["parked"] = None
        record["last_code"] = None
        record["due_at"] = now
        record["attempts"] = 0
        record["retry_requested"] = False
        record["retry_generation"] = None
        record["retry_job_id"] = job_id
        record["retry_error_code"] = scheduled_target["error_code"] if scheduled_target else None
        record["retry_attempt_count"] = scheduled_target["attempt_count"] if scheduled_target else None
        _write_state(base, state)
    return {"status": "queued", "project": workspace, "job_id": job_id, "retry_failed": False}


def reconcile_batch_recovery(
    project: str | os.PathLike[str],
    data_dir: str | os.PathLike[str] | None = None,
    *,
    job_id: str,
    expected_attempt_count: int,
    recovered_error_code: str,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Reconcile queue warnings after a guarded recovery reached a terminal state.

    The Store is read-only here. An inflight worker, an unrelated blocker, or
    another failure of the same class remains authoritative.
    """
    if (not _valid_job_id(job_id) or isinstance(expected_attempt_count, bool)
            or not isinstance(expected_attempt_count, int) or expected_attempt_count < 2
            or not isinstance(recovered_error_code, str) or recovered_error_code not in {
                "timeout", "runner_failure", "storage_failure", "invalid_response"
            }):
        raise ValueError("reconciliation requires the exact terminal recovery snapshot")
    workspace = project_key(project)
    base = _base_dir(data_dir)
    connection = None
    try:
        with _state_lock(base):
            state = _load_state(base)
            record = state["projects"].get(workspace)
            if record is None:
                return {"status": "not_queued"}
            if record["inflight_generation"] is not None:
                return {"status": "deferred", "code": "work_inflight"}
            database = base / "memory.sqlite3"
            _reject_link_or_nonfile(database)
            connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
            recovered = connection.execute(
                "SELECT status,error_code FROM observation_jobs WHERE id=? AND project=? AND processor_id=? "
                "AND model=? AND reasoning_effort=? AND status IN ('processed','skipped','failed') "
                "AND attempt_count=? AND lease_token IS NULL AND lease_expires_at IS NULL",
                (job_id, workspace, PROCESSOR_ID, MODEL, REASONING_EFFORT, expected_attempt_count),
            ).fetchone()
            if recovered is None:
                return {"status": "blocked", "code": "recovery_unavailable"}
            from .observation_diagnostics import read_failure_receipts
            recovered_failures = read_failure_receipts(connection, job_id)
            current_reason = (recovered_failures[-1]["reason_code"] if recovered_failures
                              and recovered_failures[-1]["attempt_count"] == expected_attempt_count else None)
            failures = connection.execute(
                "SELECT id,error_code FROM observation_jobs WHERE project=? AND processor_id=? "
                "AND model=? AND reasoning_effort=? AND status='failed' ORDER BY updated_at DESC,id DESC",
                (workspace, PROCESSOR_ID, MODEL, REASONING_EFFORT),
            ).fetchall()
            rejected = [row[0] for row in failures if row[1] == "invalid_response"]
            previous_rejected_job = record["last_rejected_job"]
            previous_rejected_reason = record["last_rejected_reason"]
            record["rejected_batches"] = len(rejected)
            record["last_rejected_job"] = rejected[0] if rejected else None
            record["last_rejected_reason"] = None
            if rejected:
                details = read_failure_receipts(connection, rejected[0])
                record["last_rejected_reason"] = (details[-1]["reason_code"] if details else
                    previous_rejected_reason if rejected[0] == previous_rejected_job else None)
            matching_blocker = record["blocked"] and record["last_code"] == recovered_error_code
            matching_failure_remains = any(row[1] == recovered_error_code for row in failures)
            failed_recovery = recovered[0] == "failed"
            safe_content_rejection = recovered[1] == "invalid_response" and current_reason in _CONTENT_REJECTION_REASONS
            replaced_blocker = matching_blocker and not matching_failure_remains
            if failed_recovery and not safe_content_rejection and (not record["blocked"] or replaced_blocker):
                # A rejected repair is a new observed outcome. Preserve any
                # earlier unrelated blocker; otherwise stop on an operational
                # or unexplained failure without losing another job's retry state.
                record["blocked"] = True
                record["last_code"] = _normalise_code(recovered[1])
                record["last_failure_at"] = _checked_now(clock)
                record["last_failure_detail"] = None
            cleared_blocker = replaced_blocker and (not failed_recovery or safe_content_rejection)
            quarantine_only = (not record["blocked"] and record["last_code"] in {None, "invalid_response"}
                               and record["retry_job_id"] is None and not record["retry_requested"])
            if cleared_blocker:
                record["blocked"] = False
            if cleared_blocker or quarantine_only:
                record["last_code"] = "invalid_response" if rejected else None
                if cleared_blocker:
                    record["attempts"] = 0
                # Do not change deliberate scope/feature parks. A future
                # ordinary enqueue or configured worker can drain fresh work.
                if record["parked"] == "rejected_batches":
                    record["parked"] = None
                    record["due_at"] = _checked_now(clock)
                elif cleared_blocker:
                    record["due_at"] = _checked_now(clock)
            _write_state(base, state)
            return {"status": "reconciled", "blocked": record["blocked"],
                    "rejected_batches": len(rejected)}
    except (OSError, sqlite3.Error, ServiceError, ValueError):
        # The batch already committed. Surface this separate metadata gap;
        # never present it as a failed model attempt that should be rerun.
        return {"status": "unavailable", "code": "state_unavailable"}
    finally:
        if connection is not None:
            connection.close()


def recover_expired(
    project: str | os.PathLike[str],
    data_dir: str | os.PathLike[str] | None = None,
    *,
    job_id: str,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]] = load_config,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Explicitly release a legacy blocker backed by an exact expired claim.

    No Store jobs are changed here. Normal claiming recovers expired running
    work, while failed and quarantined batches remain excluded.
    """
    workspace = project_key(project)
    eligible, reason, _, _ = _eligibility(workspace, data_dir, config_loader)
    if not eligible:
        return {"status": "disabled", "project": workspace, "reason": reason}
    base = _base_dir(data_dir)
    now = _checked_now(clock)
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(workspace)
        if record is None or not record["blocked"]:
            return {"status": "blocked", "project": workspace, "code": "blocker_unavailable"}
        # Older filter timeouts could leave the Store lease running while the
        # scheduler recorded runner_failure. Release only that exact mismatch;
        # ordinary runner failures still require a durable failed receipt.
        legacy_filter_timeout = (
            record["last_code"] == "runner_failure"
            and record["last_failure_job"] == job_id
            and record["last_failure_detail"] == _runner_failure_detail("jev_filter_timeout")
        )
        if record["last_code"] not in {"storage_failure", "lease_expired"} and not legacy_filter_timeout:
            return {"status": "blocked", "project": workspace, "code": record["last_code"]}
        if record["inflight_generation"] is not None:
            return {"status": "blocked", "project": workspace, "code": "work_inflight"}
        if not _persisted_expired_claim(base, workspace, job_id, now):
            return {"status": "blocked", "project": workspace, "code": "expired_claim_unavailable"}
        _preserve_retry_target(record)
        record["generation"] += 1
        record["blocked"] = False
        record["parked"] = None
        record["last_code"] = None
        record["due_at"] = now
        # Releasing this stale claim grants an attempt, not a fresh automatic
        # lease-recovery budget if that attempt expires again.
        if not legacy_filter_timeout:
            record["attempts"] = 0
        record["retry_requested"] = False
        record["retry_generation"] = None
        record["retry_job_id"] = None
        record["retry_error_code"] = None
        record["retry_attempt_count"] = None
        _write_state(base, state)
    return {"status": "queued", "project": workspace, "job_id": job_id, "retry_failed": False}


def run_service(
    data_dir: str | os.PathLike[str] | None = None,
    *,
    stop_event: Any | None = None,
    processor: Callable[..., Mapping[str, Any]] | None = None,
    runner: Callable[..., Mapping[str, Any]] | None = None,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]] = load_config,
    clock: Callable[[], float] = time.time,
    sleeper: Callable[[float], Any] = time.sleep,
    poll_interval: int | float = DEFAULT_POLL_INTERVAL,
    processor_timeout: int | float = DEFAULT_TIMEOUT,
    max_timeout_retries: int = DEFAULT_MAX_TIMEOUT_RETRIES,
    retry_backoff: int | float = DEFAULT_BACKOFF_SECONDS,
    indexer: Callable[..., Any] | None = None,
    max_cycles: int | None = None,
    usage_collector: Callable[..., Mapping[str, Any]] | None = None,
    processor_workers: int | None = None,
    project_memory_processor: Callable[..., Mapping[str, Any]] | None = None,
) -> dict[str, Any]:
    """Run one local worker until stopped.

    A running service is single-instance per data directory.  It uses the
    processor's own Store leases and processes bounded project cohorts.
    ``runner`` is a backwards-friendly test seam alias for ``processor``;
    only one may be supplied.  With ``max_cycles=None`` this is a persistent
    foreground service.  Tests can supply a finite cycle count and fake clock.
    ``project_memory_processor`` replaces only the opt-in episode worker in
    tests; durable pending discovery and current privacy gates still apply.
    """

    active_processor = _choose_processor(processor, runner)
    checked_poll = _validate_nonnegative_number(poll_interval, "poll_interval")
    checked_timeout = _validate_timeout(processor_timeout)
    checked_retries = _validate_retries(max_timeout_retries)
    checked_backoff = _validate_positive_number(retry_backoff, "retry_backoff")
    checked_cycles = _validate_cycles(max_cycles)
    # Preserve historical injected-processor behavior unless the caller opts in.
    if processor_workers is None and processor is None and runner is None:
        try:
            processor_workers = config_loader(data_dir).get("processor_workers", 2)
        except Exception:
            # The normal gate returns a paused receipt for unavailable config.
            processor_workers = 1
    configured_workers = _validate_workers(1 if processor_workers is None else processor_workers)
    effective_workers = configured_workers
    successful_calls = 0
    pool = None
    _validate_stop_event(stop_event)

    base = _base_dir(data_dir)
    pid_lock = _PidLock(base, _checked_now(clock))
    try:
        pid_lock.acquire()
    except ServiceAlreadyRunning:
        return _service_receipt("already_running", jobs=0)
    except ServiceError:
        return _service_receipt("error", jobs=0, code="lock_unavailable")

    jobs = 0
    last_code: str | None = None
    try:
        _record_owner(base, pid_lock.pid, pid_lock.nonce, _checked_now(clock))

        _record_workers(base, configured_workers, effective_workers, 0)
        cycles = 0
        next_usage_at = 0.0
        next_usage_reconcile_at = 0.0
        checked_legacy_runner_blocks = False
        recovery_turns: set[str] = set()
        project_memory_retry_at: dict[str, float] = {}
        project_memory_previous: str | None = None
        while True:
            if _event_is_set(stop_event):
                return _service_receipt("stopped", jobs=jobs, code=last_code)
            if checked_cycles is not None and cycles >= checked_cycles:
                return _service_receipt("cycle_limit", jobs=jobs, code=last_code)
            cycles += 1

            now = _checked_now(clock)
            gate = _refresh_queue_gates(base, data_dir, config_loader)
            if not gate["active"]:
                return _service_receipt("paused", jobs=jobs, code=gate["reason"])
            if not checked_legacy_runner_blocks and gate["processor_enabled"]:
                _recover_legacy_runner_blocks(base, now, checked_backoff)
                checked_legacy_runner_blocks = True
            if now >= next_usage_reconcile_at:
                next_usage_reconcile_at = now + 30.0
                _reconcile_observer_usage(base)
            # Metadata accounting is independent of observation work: a
            # blocked or idle memory queue must not stop token collection.
            if usage_collector is not None and now >= next_usage_at:
                next_usage_at = now + 30.0
                try:
                    settings = config_loader(data_dir)
                    if settings.get("usage_enabled", True):
                        usage_collector(config=settings)
                except Exception:
                    # Accounting failure must never block memory extraction.
                    # The collector's atomic cursor permits a later retry.
                    pass
            # This path reads only indexed durable event metadata. Notification
            # loss and prompt-only turns cannot strand committed PM events.
            # One bounded job per cycle leaves ordinary work a turn every time.
            if not _event_is_set(stop_event) and not _load_state_readonly(base)["stop_requested"]:
                project_memory_previous = _run_project_memory_cycle(
                    data_dir, config_loader, now, project_memory_retry_at,
                    previous=project_memory_previous, processor=project_memory_processor,
                )
            # A bounded model call can consume most of its timeout. Lease the
            # ordinary queue against current time, not the prior cycle start.
            now = _checked_now(clock)
            choice = _claim_due_project(base, now, checked_timeout)
            if choice["kind"] == "stop":
                _consume_stop_request(base)
                return _service_receipt("stopped", jobs=jobs, code=last_code)
            if choice["kind"] == "wait":
                _bounded_sleep(sleeper, _sleep_delay(choice.get("due_at"), now, checked_poll))
                continue

            project = choice["project"]
            generation = choice["generation"]
            assert isinstance(project, str)
            assert isinstance(generation, int)
            eligible, reason, processor_enabled, semantic_enabled = _eligibility(
                project, data_dir, config_loader
            )
            if not eligible:
                _park_unprocessed_project(base, project, generation, reason, _checked_now(clock))
                if reason in {"disabled", "service_disabled", "configuration_unavailable"}:
                    return _service_receipt("paused", jobs=jobs, code=reason)
                # One excluded project must not starve a different approved
                # project.  It is parked until configuration changes or a new
                # explicit enqueue refreshes it.
                continue

            retry_failed = bool(choice["retry_requested"])
            # Maintenance permissions are consumed only by this coordinator,
            # before worker futures exist. Alternate with ordinary work so a
            # large quarantine manifest cannot starve fresh captures.
            if (processor_enabled and not retry_failed and choice["retry_job_id"] is None
                    and not choice["attempts"]):
                if project in recovery_turns:
                    recovery_turns.remove(project)
                elif _pending_maintenance(base, project):
                    from .quarantine_recovery import run_next
                    _record_workers(base, configured_workers, effective_workers, 1)
                    try:
                        recovery = run_next(project, data_dir, processor=active_processor,
                                            timeout=checked_timeout)
                    finally:
                        _record_workers(base, configured_workers, effective_workers, 0)
                    if recovery is not None:
                        recovery_turns.add(project)
                        jobs += int(recovery["result"]["status"] in {"processed", "skipped", "failed"})
                        _finish_maintenance(base, project, generation, _checked_now(clock))
                        continue
            if processor_enabled and (configured_workers > 1 or choice["pending_retries"]):
                if pool is None:
                    pool = ThreadPoolExecutor(max_workers=configured_workers, thread_name_prefix="observation")
                width = 1 if retry_failed or choice["retry_job_id"] is not None or choice["attempts"] else effective_workers
                if choice.get("fresh_retry_width"):
                    width = min(width, choice["fresh_retry_width"])
                # All futures have a slot now. Never queue leased projects behind
                # another long-running model call, and never refill a partial cohort.
                _record_workers(base, configured_workers, effective_workers, width)
                futures = [pool.submit(_call_processor, active_processor, project, data_dir,
                    retry_failed, checked_timeout,
                    retry_job_id=None if retry_failed else choice["retry_job_id"],
                    retry_error_code=None if retry_failed else choice["retry_error_code"],
                    retry_attempt_count=None if retry_failed else choice["retry_attempt_count"],
                    parallel_sessions=True) for _ in range(width)]
                results = []
                for future in as_completed(futures):
                    results.append(future.result())
                    _record_workers(base, configured_workers, effective_workers, width - len(results))
                jobs += len(results)
                transient = any((isinstance(r.get("reason_code"), str) and r["reason_code"] in _TRANSIENT_RUNNER_REASONS)
                                or (isinstance(r.get("code"), str) and r["code"] in {"timeout", *_TRANSPORT_FAILURE_CODES})
                                for r in results)
                if transient:
                    effective_workers, successful_calls = 1, 0
                else:
                    successful_calls += sum(r.get("status") in {"processed", "skipped"} for r in results)
                    if successful_calls >= WORKER_RECOVERY_SUCCESSES:
                        effective_workers = min(configured_workers, effective_workers + 1)
                        successful_calls = 0
                _record_workers(base, configured_workers, effective_workers, 0)
                outcome = _finish_cohort(base, project, generation, choice, results,
                    data_dir=data_dir, semantic_enabled=semantic_enabled, indexer=indexer,
                    now=_checked_now(clock), max_timeout_retries=checked_retries,
                    retry_backoff=checked_backoff)
                last_code = outcome.get("code") or last_code
                if outcome["status"] == "halted" and not _has_other_eligible_project(
                    base, data_dir, config_loader, excluded_project=project):
                    return _service_receipt("halted", jobs=jobs, code=last_code)
                continue
            automatic_retry_allowed = True
            if processor_enabled:
                result = _call_processor(
                    active_processor, project, data_dir, retry_failed, checked_timeout,
                    retry_job_id=None if retry_failed else choice["retry_job_id"],
                    retry_error_code=None if retry_failed else choice["retry_error_code"],
                    retry_attempt_count=None if retry_failed else choice["retry_attempt_count"],
                )
                jobs += 1
                if (result.get("status") == "blocked" and result.get("code") == "recovery_unavailable"
                        and choice["retry_error_code"] in {"runner_failure", *_TRANSPORT_FAILURE_CODES} and not retry_failed):
                    result = _reconcile_retry_snapshot(base, project, choice["retry_job_id"], _checked_now(clock))
                    # A changed failed attempt has consumed the scheduled
                    # permission. Only a genuinely expired running lease may
                    # return to the ordinary atomic reclamation path.
                    automatic_retry_allowed = result.get("code") == "lease_expired"
                status, code = _processor_outcome(result)
                last_code = code or last_code
            else:
                # Disabling the native processor does not prevent local
                # semantic indexing.  Keep the raw-observation queue intact
                # so re-enabling processing never silently loses its work.
                status, code = "idle", None

            # Indexing also runs when observation processing is idle: explicit
            # memory notes can need embedding even when no raw observations do.
            failure_detail = _safe_failure_detail(result.get("failure_detail")) if processor_enabled else None
            try:
                index_pending = (
                    _run_indexer(indexer, project, data_dir, retry_failed) if semantic_enabled else False
                )
            except _IndexFailure as exc:
                status, code = "failed", "index_failure"
                failure_detail = exc.detail
                last_code = code
            except Exception:
                status, code = "failed", "index_failure"
                failure_detail = _index_failure_detail({})
                last_code = code

            if status == "failed":
                # A persisted content rejection is isolated to its leased
                # batch. Store excludes failed sources from ordinary claims;
                # continue new work with retry_failed=False, never rearm it.
                if code == "invalid_response" and _quarantine_rejection(
                    base, project, generation, result.get("job_id"), _checked_now(clock),
                    reason_code=result.get("reason_code"),
                ):
                    continue
                retrying = _finish_failure(
                    base,
                    project,
                    generation,
                    code or "invalid_result",
                    now=_checked_now(clock),
                    max_timeout_retries=checked_retries,
                    retry_backoff=checked_backoff,
                    rejected_job_id=result.get("job_id") if processor_enabled else None,
                    reason_code=result.get("reason_code") if processor_enabled else None,
                    failure_detail=failure_detail,
                    automatic_retry_allowed=automatic_retry_allowed,
                )
                if retrying:
                    continue
                # A bad project is quarantined by _finish_failure, but it
                # must not stop unrelated approved work from draining.  Keep
                # the historical halted receipt when this was the only
                # eligible project, so callers still get a clear failure.
                if _has_other_eligible_project(
                    base, data_dir, config_loader, excluded_project=project
                ):
                    continue
                return _service_receipt("halted", jobs=jobs, code=code or "invalid_result")

            if not processor_enabled:
                _finish_local_only(
                    base,
                    project,
                    generation,
                    index_pending,
                    semantic_enabled,
                    _checked_now(clock),
                )
                # Continue across all queued projects.  A drained local index
                # pass parks only this project until processor configuration
                # changes; it cannot repeatedly spin on the same record.
                continue

            if status == "deferred":
                _finish_deferred(base, project, generation, result["retry_at"], _checked_now(clock))
                continue

            _finish_success(
                base,
                project,
                generation,
                status,
                index_pending,
                _checked_now(clock),
            )
    except ServiceStateError:
        return _service_receipt("error", jobs=jobs, code="state_unavailable")
    except ServiceError:
        return _service_receipt("error", jobs=jobs, code="service_unavailable")
    finally:
        if pool is not None:
            pool.shutdown(wait=True)
        try:
            _clear_owner(base, pid_lock.pid, pid_lock.nonce)
        except ServiceError:
            pass
        pid_lock.release()


def _run_project_memory_cycle(
    data_dir: str | os.PathLike[str] | None,
    config_loader: Callable[..., Mapping[str, Any]],
    now: float,
    retry_at: dict[str, float],
    *,
    previous: str | None = None,
    processor: Callable[..., Mapping[str, Any]] | None = None,
) -> str | None:
    """Discover one ready durable batch without depending on hook delivery.

    Core applies persisted session quiet/checkpoint/size thresholds before a
    background claim. Fresh captures remain available as provisional signals.
    """
    try:
        settings = config_loader(data_dir)
        if settings.get("service_enabled") is not True or settings.get("processor_enabled") is not True:
            return previous
        projects = settings.get("project_memory_projects", [])
        if not isinstance(projects, list) or len(projects) > MAX_QUEUED_PROJECTS:
            return previous
        selected = [project for project in projects if project_memory_enabled(project, settings)]
        for project in list(retry_at):
            if project not in selected:
                del retry_at[project]
        if not selected:
            return previous
        from .store import Store
        from .project_memory import ProjectMemory
        with Store(data_dir=data_dir) as store:
            pending = ProjectMemory(store).pending_projects(
                limit=MAX_QUEUED_PROJECTS, projects=selected, ready_only=True)
        eligible = [project for project in pending if project in selected and now >= retry_at.get(project, 0)]
        if not eligible:
            return previous
        # Rotation prevents a long-running first project from starving others.
        if previous in eligible:
            offset = eligible.index(previous) + 1
            eligible = eligible[offset:] + eligible[:offset]
        project = eligible[0]
        current = config_loader(data_dir)
        if (current.get("service_enabled") is not True or current.get("processor_enabled") is not True
                or not project_memory_enabled(project, current)):
            return previous
        if processor is None:
            from .episode_processor import process_project_memory
            processor = process_project_memory
        # Core persists job-specific backoff. This additional guard also covers
        # failures before a claim, such as an unavailable processor module.
        retry_at[project] = now + DEFAULT_BACKOFF_SECONDS
        result = processor(project, data_dir=data_dir, background=True)
        if isinstance(result, Mapping) and result.get("status") == "processed":
            retry_at.pop(project, None)
        return project
    except Exception:
        # PM must never take observation processing, indexing, or usage offline.
        return previous


def start_service(
    data_dir: str | os.PathLike[str] | None = None,
    *,
    launcher: Callable[[list[str], Mapping[str, str]], Any] | None = None,
    clock: Callable[[], float] = time.time,
    sleeper: Callable[[float], Any] = time.sleep,
    startup_timeout: int | float = DEFAULT_STARTUP_TIMEOUT,
) -> dict[str, Any]:
    """Start one detached packaged ``service run`` child.

    This function does not enqueue work and never changes host startup/login
    configuration.  It returns bounded lifecycle states, or ``unknown`` when
    PID-lock visibility is unavailable and starting another worker is unsafe.
    """

    checked_timeout = _validate_nonnegative_number(startup_timeout, "startup_timeout")
    base = _base_dir(data_dir)
    status = service_status(base, clock=clock)
    if status["status"] == "running":
        return {"status": "running", "pid": status.get("pid")}
    if status["status"] == "starting":
        return {"status": "already_starting", "pid": status.get("pid")}
    if status["status"] in {"unknown", "unavailable"}:
        return {
            "status": status["status"],
            "code": status.get("code", "status_unavailable"),
        }
    lock_held = _pid_lock_held(base)
    if lock_held is None:
        return {"status": "unknown", "code": "lock_visibility_unavailable"}
    if lock_held:
        return {"status": "already_starting"}

    try:
        _clear_stop_request(base)
        reservation = _reserve_startup(base, _checked_now(clock))
    except ServiceAlreadyRunning:
        return {"status": "already_starting"}
    except ServiceError:
        return {"status": "error", "code": "startup_unavailable"}

    launcher_script = Path(__file__).resolve().parents[1] / "scripts" / "codex-mem.py"
    command = [
        sys.executable,
        str(launcher_script),
        "--data-dir",
        str(base),
        "service",
        "run",
    ]
    environment = dict(os.environ)
    environment[SERVICE_STARTUP_ENV] = reservation["nonce"]
    try:
        child = (launcher or _spawn_service_child)(command, environment)
        child_pid = _child_pid(child)
        _set_startup_child(base, reservation["nonce"], child_pid)
    except Exception:
        _clear_startup_reservation(base, reservation["nonce"])
        return {"status": "error", "code": "startup_failed"}

    deadline = _checked_now(clock) + checked_timeout
    while _checked_now(clock) < deadline:
        status = service_status(base, clock=clock)
        if status["status"] == "running" and status.get("pid") == child_pid:
            _clear_startup_reservation(base, reservation["nonce"])
            return {"status": "started", "pid": child_pid}
        if _child_exited(child):
            _clear_startup_reservation(base, reservation["nonce"])
            return {"status": "error", "code": "startup_failed"}
        _bounded_sleep(sleeper, min(0.05, max(0.0, deadline - _checked_now(clock))))
    return {"status": "starting", "pid": child_pid}


def stop_service(
    data_dir: str | os.PathLike[str] | None = None,
    *,
    expected_owner: str | None = None,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Request a bounded cooperative shutdown without signalling a PID."""

    base = _base_dir(data_dir)
    status = service_status(base, clock=clock)
    if status["status"] in {"unknown", "unavailable"}:
        return {
            "status": status["status"],
            "code": status.get("code", "status_unavailable"),
        }
    if expected_owner is not None and status.get("owner_id") != expected_owner:
        return {"status": "blocked", "code": "owner_changed"}
    if status["status"] not in {"running", "starting"}:
        return {"status": "not_running"}
    try:
        with _state_lock(base):
            state = _load_state(base)
            if expected_owner is not None:
                # Owner registration and cleanup take this same state lock.
                # Compare again inside it so an installer cannot stop a worker
                # that replaced the daemon it inspected before activation.
                owner = state["owner"]
                lock = _read_pid_lock(base)
                if (not owner or not lock or _pid_lock_held(base) is not True
                        or owner["pid"] != lock["pid"] or owner["nonce"] != lock["nonce"]
                        or f"{owner['pid']}:{owner['nonce']}" != expected_owner
                        or not _pid_alive(owner["pid"])):
                    return {"status": "blocked", "code": "owner_changed"}
            state["stop_requested"] = True
            state["stop_requested_at"] = _checked_now(clock)
            _write_state(base, state)
    except ServiceError:
        return {"status": "error", "code": "state_unavailable"}
    return {"status": "stopping", "pid": status.get("pid")}


def service_status(
    data_dir: str | os.PathLike[str] | None = None,
    *,
    clock: Callable[[], float] = time.time,
) -> dict[str, Any]:
    """Return a safe queue and ownership summary without reading observations."""

    try:
        now = _checked_now(clock)
        base = _base_dir(data_dir)
        state = _load_state_readonly(base)
    except ServiceError:
        return {
            "status": "unavailable",
            "running": None,
            "lock_held": None,
            "queued_projects": 0,
            "blocked_projects": 0,
            "code": "status_unavailable",
        }

    lock = _read_pid_lock(base)
    owner = state["owner"]
    lock_held = _pid_lock_held(base)
    projects = state["projects"]
    blocked = sum(1 for record in projects.values() if record["blocked"])
    failures = {
        project: {"code": record["last_code"], "last_failure_at": record["last_failure_at"],
                  "detail": record["last_failure_detail"]}
        for project, record in projects.items() if record["blocked"]
    }
    rejected_projects = [project for project, record in projects.items() if record["rejected_batches"]]
    rejection_counts = _rejection_counts(base, rejected_projects)
    quarantines = {
        project: {"batches": None if rejection_counts is None else rejection_counts.get(project, 0),
                  "last_job_id": projects[project]["last_rejected_job"], "code": "invalid_response",
                  "reason_code": projects[project]["last_rejected_reason"]}
        for project in rejected_projects
        if rejection_counts is None or rejection_counts.get(project, 0)
    }
    quarantine_status = {
        "quarantined_projects": None if rejection_counts is None else len(quarantines),
        "quarantined_batches": None if rejection_counts is None else sum(rejection_counts.values()),
        "quarantines": quarantines,
    }
    if lock_held is None:
        result: dict[str, Any] = {
            "status": "unknown",
            "running": None,
            "lock_held": None,
            "queued_projects": len(projects),
            "blocked_projects": blocked,
            "failures": failures,
            "stop_requested": state["stop_requested"],
            "code": "lock_visibility_unavailable",
            **quarantine_status,
        }
        if lock and owner and lock["pid"] == owner["pid"] and lock["nonce"] == owner["nonce"]:
            result["pid"] = lock["pid"]
        return result
    running = bool(
        lock
        and owner
        and lock_held
        and lock["pid"] == owner["pid"]
        and lock["nonce"] == owner["nonce"]
        and _pid_alive(lock["pid"])
    )
    startup = _read_startup_reservation(base)
    starting = bool(
        not running
        and (
            lock_held
            or (
                startup
                and now - startup["started_at"] <= DEFAULT_STARTUP_TTL
                and _pid_alive(startup["pid"])
            )
        )
    )
    result: dict[str, Any] = {
        "status": "running" if running else "starting" if starting else "stopped",
        "running": running,
        "lock_held": lock_held,
        "queued_projects": len(projects),
        "blocked_projects": blocked,
        "failures": failures,
        "stop_requested": state["stop_requested"],
        **quarantine_status,
    }
    if running and lock is not None:
        result["pid"] = lock["pid"]
        result["owner_id"] = f"{lock['pid']}:{lock['nonce']}"
        result["runtime_version"] = owner.get("runtime_version")
        if "workers" in owner:
            result["workers"] = owner["workers"]
    elif starting and startup is not None:
        result["pid"] = startup["pid"]
    return result


def _base_dir(data_dir: str | os.PathLike[str] | None) -> Path:
    try:
        return data_dir_path(data_dir)
    except (OSError, RuntimeError, TypeError, ValueError):
        raise ServiceError("service data directory is unavailable") from None


def _reconcile_observer_usage(base: Path) -> None:
    """Repair a bounded batch of stale accounting receipts, including idle queues."""
    if not (base / "memory.sqlite3").is_file():
        return
    try:
        from .observer_usage_store import reconcile_attempts
        from .store import Store
        with Store(base) as store:
            reconcile_attempts(store, limit=128)
    except Exception:
        # A later accounting pass can retry without interrupting memory work.
        pass


def _eligibility(
    project: str,
    data_dir: str | os.PathLike[str] | None,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]],
) -> tuple[bool, str, bool, bool]:
    if hooks_disabled():
        return False, "disabled", False, False
    try:
        config = config_loader(data_dir)
    except Exception:
        return False, "configuration_unavailable", False, False
    if not isinstance(config, Mapping) or not getattr(config, "valid", True):
        return False, "configuration_unavailable", False, False
    service_enabled = config.get("service_enabled", True)
    processor_enabled = config.get("processor_enabled", True)
    semantic_enabled = config.get("semantic_enabled", True)
    if not all(isinstance(value, bool) for value in (service_enabled, processor_enabled, semantic_enabled)):
        return False, "configuration_unavailable", False, False
    if not service_enabled:
        return False, "service_disabled", False, False
    try:
        if not automatic_capture_enabled(project, config):
            return False, "not_selected", False, False
    except Exception:
        return False, "configuration_unavailable", False, False
    return True, "", processor_enabled, semantic_enabled


def _refresh_queue_gates(
    base: Path,
    data_dir: str | os.PathLike[str] | None,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]],
) -> dict[str, Any]:
    """Refresh parked projects without discovering any new project.

    Scope choices are per project, so a newly excluded record must not pause a
    second selected record.  The queue is capped and contains only explicitly
    enqueued paths, making this bounded local refresh safe.
    """

    if hooks_disabled():
        return {"active": False, "reason": "disabled"}
    try:
        config = config_loader(data_dir)
    except Exception:
        return {"active": False, "reason": "configuration_unavailable"}
    if not isinstance(config, Mapping) or not getattr(config, "valid", True):
        return {"active": False, "reason": "configuration_unavailable"}
    service_enabled = config.get("service_enabled", True)
    processor_enabled = config.get("processor_enabled", True)
    semantic_enabled = config.get("semantic_enabled", True)
    capture_enabled = config.get("capture_enabled", True)
    if not all(
        isinstance(value, bool)
        for value in (service_enabled, processor_enabled, semantic_enabled, capture_enabled)
    ):
        return {"active": False, "reason": "configuration_unavailable"}
    if not service_enabled:
        return {"active": False, "reason": "service_disabled"}
    if not capture_enabled:
        return {"active": False, "reason": "disabled"}

    with _state_lock(base):
        state = _load_state(base)
        changed = False
        for project, record in state["projects"].items():
            try:
                selected = automatic_capture_enabled(project, config)
            except Exception:
                selected = False
            parked = record["parked"]
            if not selected:
                if parked != "not_selected":
                    record["parked"] = "not_selected"
                    changed = True
                continue
            if parked == "not_selected":
                record["parked"] = None
                changed = True
            elif processor_enabled and parked in {"processor_disabled", "semantic_disabled"}:
                record["parked"] = None
                changed = True
            elif not processor_enabled and semantic_enabled and parked == "semantic_disabled":
                record["parked"] = None
                changed = True
        if changed:
            _write_state(base, state)
    return {
        "active": True,
        "reason": "",
        "processor_enabled": processor_enabled,
        "semantic_enabled": semantic_enabled,
    }


def _new_state() -> dict[str, Any]:
    return {
        "version": STATE_VERSION,
        "cursor": None,
        "stop_requested": False,
        "stop_requested_at": None,
        "owner": None,
        "projects": {},
    }


def _new_record(now: float, *, retry_requested: bool = False) -> dict[str, Any]:
    return {
        "generation": 1,
        "due_at": now,
        "capture_due_at": None,
        "storage_attempts": 0,
        "attempts": 0,
        "retry_requested": retry_requested,
        "retry_generation": 1 if retry_requested else None,
        "retry_job_id": None,
        "retry_error_code": None,
        "retry_attempt_count": None,
        "pending_retries": [],
        "fresh_work_due": False,
        "last_code": None,
        "last_failure_at": None,
        "last_failure_detail": None,
        "last_failure_job": None,
        "runner_recovery_checked": True,
        "rejected_batches": 0,
        "last_rejected_job": None,
        "last_rejected_reason": None,
        "blocked": False,
        "parked": None,
        "inflight_generation": None,
        "inflight_until": None,
    }


class _StateLock:
    def __init__(self, base: Path) -> None:
        self.base = base
        self.handle: Any | None = None

    def __enter__(self) -> "_StateLock":
        _ensure_base_dir(self.base)
        target = self.base / SERVICE_STATE_LOCK_FILENAME
        _reject_link_or_nonfile(target)
        flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
        try:
            descriptor = os.open(target, flags, 0o600)
            os.chmod(target, 0o600)
            self.handle = os.fdopen(descriptor, "a+", encoding="utf-8")
            if fcntl is not None:
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_EX)
            return self
        except OSError:
            if self.handle is not None:
                self.handle.close()
            raise ServiceStateError("service state is unavailable") from None

    def __exit__(self, exc_type: Any, exc: Any, traceback: Any) -> None:
        if self.handle is None:
            return
        try:
            if fcntl is not None:
                fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
        finally:
            self.handle.close()
            self.handle = None


def _state_lock(base: Path) -> _StateLock:
    return _StateLock(base)


def _ensure_base_dir(base: Path) -> None:
    try:
        if base.exists() and base.is_symlink():
            raise ServiceStateError("service state is unavailable")
        base.mkdir(mode=0o700, parents=True, exist_ok=True)
        os.chmod(base, 0o700)
    except ServiceError:
        raise
    except OSError:
        raise ServiceStateError("service state is unavailable") from None


def _reject_link_or_nonfile(path: Path) -> None:
    try:
        mode = path.lstat().st_mode
    except FileNotFoundError:
        return
    except OSError:
        raise ServiceStateError("service state is unavailable") from None
    if stat.S_ISLNK(mode) or not stat.S_ISREG(mode):
        raise ServiceStateError("service state is unavailable")


def _load_state_readonly(base: Path) -> dict[str, Any]:
    destination = base / SERVICE_STATE_FILENAME
    if not destination.exists():
        return _new_state()
    return _read_json_state(destination)


def _load_state(base: Path) -> dict[str, Any]:
    return _load_state_readonly(base)


def _read_json_state(destination: Path) -> dict[str, Any]:
    _reject_link_or_nonfile(destination)
    try:
        if destination.stat().st_size > MAX_STATE_BYTES:
            raise ServiceStateError("service state is unavailable")
        with destination.open("r", encoding="utf-8") as handle:
            raw = json.load(handle)
    except ServiceError:
        raise
    except (OSError, TypeError, ValueError, json.JSONDecodeError):
        raise ServiceStateError("service state is unavailable") from None
    return _validate_state(raw)


def _validate_state(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, Mapping) or raw.get("version") != STATE_VERSION:
        raise ServiceStateError("service state is unavailable")
    projects = raw.get("projects")
    if not isinstance(projects, Mapping) or len(projects) > MAX_QUEUED_PROJECTS:
        raise ServiceStateError("service state is unavailable")
    normalised_projects: dict[str, dict[str, Any]] = {}
    for project, record in projects.items():
        try:
            valid_project = isinstance(project, str) and project_key(project) == project
        except (OSError, RuntimeError, TypeError, ValueError):
            valid_project = False
        if not valid_project:
            raise ServiceStateError("service state is unavailable")
        normalised_projects[project] = _validate_record(record)
    cursor = raw.get("cursor")
    if cursor is not None and (not isinstance(cursor, str) or cursor not in normalised_projects):
        cursor = None
    stop_requested = raw.get("stop_requested")
    if not isinstance(stop_requested, bool):
        raise ServiceStateError("service state is unavailable")
    stop_requested_at = raw.get("stop_requested_at")
    if stop_requested_at is not None and not _is_timestamp(stop_requested_at):
        raise ServiceStateError("service state is unavailable")
    owner = _validate_owner(raw.get("owner"))
    return {
        "version": STATE_VERSION,
        "cursor": cursor,
        "stop_requested": stop_requested,
        "stop_requested_at": stop_requested_at,
        "owner": owner,
        "projects": normalised_projects,
    }


def _validate_record(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, Mapping):
        raise ServiceStateError("service state is unavailable")
    generation = raw.get("generation")
    attempts = raw.get("attempts")
    storage_attempts = raw.get("storage_attempts", 0)
    if (isinstance(storage_attempts, bool) or not isinstance(storage_attempts, int)
            or not 0 <= storage_attempts <= 1_000_000_000):
        raise ServiceStateError("service state is unavailable")
    retry_requested = raw.get("retry_requested")
    # Old queue records get one ordinary probe while an exact retry cools.
    fresh_work_due = raw.get("fresh_work_due", raw.get("retry_job_id") is not None)
    if not isinstance(fresh_work_due, bool):
        raise ServiceStateError("service state is unavailable")
    blocked = raw.get("blocked")
    parked = raw.get("parked")
    due_at = raw.get("due_at")
    capture_due_at = raw.get("capture_due_at")
    if capture_due_at is not None and not _is_timestamp(capture_due_at):
        raise ServiceStateError("service state is unavailable")
    if (
        isinstance(generation, bool)
        or not isinstance(generation, int)
        or not 1 <= generation <= 1_000_000_000
        or isinstance(attempts, bool)
        or not isinstance(attempts, int)
        or not 0 <= attempts <= 1_000_000_000
        or not isinstance(retry_requested, bool)
        or not isinstance(blocked, bool)
        or (parked is not None and (not isinstance(parked, str) or parked not in _PARK_REASONS))
        or not _is_timestamp(due_at)
    ):
        raise ServiceStateError("service state is unavailable")
    last_code = raw.get("last_code")
    last_failure_at = raw.get("last_failure_at")
    if last_failure_at is not None and not _is_timestamp(last_failure_at):
        raise ServiceStateError("service state is unavailable")
    last_failure_detail = _safe_failure_detail(raw.get("last_failure_detail"))
    last_failure_job = raw.get("last_failure_job")
    if last_failure_job is not None and not _valid_job_id(last_failure_job):
        raise ServiceStateError("service state is unavailable")
    runner_recovery_checked = raw.get("runner_recovery_checked", False)
    if not isinstance(runner_recovery_checked, bool):
        raise ServiceStateError("service state is unavailable")
    retry_generation = raw.get("retry_generation", generation if retry_requested else None)
    retry_job_id = raw.get("retry_job_id")
    retry_error_code = raw.get("retry_error_code")
    retry_attempt_count = raw.get("retry_attempt_count")
    if ((retry_generation is None) != (not retry_requested)
            or (retry_generation is not None and (
                isinstance(retry_generation, bool) or not isinstance(retry_generation, int)
                or not 1 <= retry_generation <= generation))
            or (retry_job_id is not None and not _valid_job_id(retry_job_id))):
        raise ServiceStateError("service state is unavailable")
    if ((retry_error_code is None) != (retry_attempt_count is None)
            or (retry_error_code is not None and (
                retry_error_code not in {"runner_failure", *_TRANSPORT_FAILURE_CODES} or retry_job_id is None
                or isinstance(retry_attempt_count, bool) or not isinstance(retry_attempt_count, int)
                or not 1 <= retry_attempt_count <= 1_000_000_000))):
        raise ServiceStateError("service state is unavailable")
    pending_retries = _validate_pending_retries(raw.get("pending_retries", []))
    if last_code is not None and not _safe_code(last_code):
        raise ServiceStateError("service state is unavailable")
    rejected_batches = raw.get("rejected_batches", 0)
    last_rejected_job = raw.get("last_rejected_job")
    last_rejected_reason = raw.get("last_rejected_reason")
    if (isinstance(rejected_batches, bool) or not isinstance(rejected_batches, int)
            or not 0 <= rejected_batches <= 1_000_000_000
            or (rejected_batches == 0) != (last_rejected_job is None)
            or (last_rejected_job is not None and not _valid_job_id(last_rejected_job))):
        raise ServiceStateError("service state is unavailable")
    if last_rejected_reason is not None and (
        not rejected_batches or not isinstance(last_rejected_reason, str)
        or last_rejected_reason not in INVALID_RESPONSE_REASONS
    ):
        raise ServiceStateError("service state is unavailable")
    inflight_generation = raw.get("inflight_generation")
    inflight_until = raw.get("inflight_until")
    if inflight_generation is not None and (
        isinstance(inflight_generation, bool)
        or not isinstance(inflight_generation, int)
        or not 1 <= inflight_generation <= generation
    ):
        raise ServiceStateError("service state is unavailable")
    if inflight_until is not None and not _is_timestamp(inflight_until):
        raise ServiceStateError("service state is unavailable")
    if (inflight_generation is None) != (inflight_until is None):
        raise ServiceStateError("service state is unavailable")
    return {
        "generation": generation,
        "due_at": float(due_at),
        "capture_due_at": None if capture_due_at is None else float(capture_due_at),
        "attempts": attempts,
        "storage_attempts": storage_attempts,
        "retry_requested": retry_requested,
        "retry_generation": retry_generation,
        "retry_job_id": retry_job_id,
        "retry_error_code": retry_error_code,
        "retry_attempt_count": retry_attempt_count,
        "pending_retries": pending_retries,
        "fresh_work_due": fresh_work_due,
        "last_code": last_code,
        "last_failure_at": None if last_failure_at is None else float(last_failure_at),
        "last_failure_detail": last_failure_detail,
        "last_failure_job": last_failure_job,
        "runner_recovery_checked": runner_recovery_checked,
        "rejected_batches": rejected_batches,
        "last_rejected_job": last_rejected_job,
        "last_rejected_reason": last_rejected_reason,
        "blocked": blocked,
        "parked": parked,
        "inflight_generation": inflight_generation,
        "inflight_until": None if inflight_until is None else float(inflight_until),
    }


def _validate_owner(raw: Any) -> dict[str, Any] | None:
    if raw is None:
        return None
    if not isinstance(raw, Mapping):
        raise ServiceStateError("service state is unavailable")
    pid = raw.get("pid")
    nonce = raw.get("nonce")
    started_at = raw.get("started_at")
    if not _valid_pid(pid) or not _valid_nonce(nonce) or not _is_timestamp(started_at):
        raise ServiceStateError("service state is unavailable")
    result = {"pid": pid, "nonce": nonce, "started_at": float(started_at)}
    version = raw.get("runtime_version")
    if version is not None:
        if (not isinstance(version, str) or not 1 <= len(version) <= 128
                or any(c not in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._+-" for c in version)):
            raise ServiceStateError("service state is unavailable")
        result["runtime_version"] = version
    if "workers" in raw:
        workers = raw["workers"]
        if (not isinstance(workers, Mapping) or set(workers) != {"configured", "effective", "active"}
                or any(isinstance(v, bool) or not isinstance(v, int) for v in workers.values())
                or not 1 <= workers["effective"] <= workers["configured"] <= MAX_PROCESSOR_WORKERS
                or not 0 <= workers["active"] <= workers["configured"]):
            raise ServiceStateError("service state is unavailable")
        result["workers"] = dict(workers)
    return result


def _write_state(base: Path, state: Mapping[str, Any]) -> None:
    _validate_state(state)
    _atomic_write_json(base / SERVICE_STATE_FILENAME, state)


def _atomic_write_json(destination: Path, value: Mapping[str, Any]) -> None:
    _reject_link_or_nonfile(destination)
    temporary_name: str | None = None
    try:
        with tempfile.NamedTemporaryFile(
            "w",
            encoding="utf-8",
            dir=destination.parent,
            prefix=f".{destination.name}.",
            suffix=".tmp",
            delete=False,
        ) as handle:
            temporary_name = handle.name
            json.dump(value, handle, ensure_ascii=True, sort_keys=True, separators=(",", ":"))
            handle.write("\n")
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temporary_name, 0o600)
        os.replace(temporary_name, destination)
    except ServiceError:
        raise
    except OSError:
        raise ServiceStateError("service state is unavailable") from None
    finally:
        if temporary_name:
            try:
                Path(temporary_name).unlink(missing_ok=True)
            except OSError:
                pass


class _PidLock:
    def __init__(self, base: Path, started_at: float) -> None:
        self.base = base
        self.started_at = started_at
        self.pid = os.getpid()
        self.nonce = secrets.token_hex(16)
        self.acquired = False
        self.handle: Any | None = None

    @property
    def path(self) -> Path:
        return self.base / SERVICE_PID_FILENAME

    def acquire(self) -> None:
        _ensure_base_dir(self.base)
        if fcntl is None:  # A missing cross-process lock must fail closed.
            raise ServiceError("service lock is unavailable")
        _reject_link_or_nonfile(self.path)
        try:
            flags = os.O_CREAT | os.O_RDWR | getattr(os, "O_NOFOLLOW", 0)
            descriptor = os.open(self.path, flags, 0o600)
            os.chmod(self.path, 0o600)
            handle = os.fdopen(descriptor, "r+", encoding="utf-8")
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                handle.close()
                raise ServiceAlreadyRunning("service already running") from None
            payload = {
                "version": STATE_VERSION,
                "pid": self.pid,
                "nonce": self.nonce,
                "started_at": self.started_at,
            }
            handle.seek(0)
            handle.truncate()
            json.dump(payload, handle, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
            self.handle = handle
            self.acquired = True
        except ServiceAlreadyRunning:
            raise
        except (OSError, TypeError, ValueError):
            raise ServiceError("service lock is unavailable") from None

    def release(self) -> None:
        if not self.acquired or self.handle is None:
            return
        try:
            # Keep the inode stable: unlinking a locked file would let another
            # process create a new path and bypass the held flock.  Empty
            # metadata is harmless because status also checks lock ownership.
            self.handle.seek(0)
            self.handle.truncate()
            self.handle.flush()
            os.fsync(self.handle.fileno())
        finally:
            try:
                if fcntl is not None:
                    fcntl.flock(self.handle.fileno(), fcntl.LOCK_UN)
            finally:
                self.handle.close()
                self.handle = None
            self.acquired = False


def _read_pid_lock(base: Path) -> dict[str, Any] | None:
    return _read_lifecycle_file(base / SERVICE_PID_FILENAME)


def _pid_lock_held(base: Path) -> bool | None:
    """Return PID-lock ownership, or ``None`` if read-only inspection is denied."""

    if fcntl is None:
        return None
    path = base / SERVICE_PID_FILENAME
    try:
        _reject_link_or_nonfile(path)
        # Status does not modify the lock; opening read-only avoids requiring
        # write permission merely to observe a worker owned by another host
        # context or sandbox.
        descriptor = os.open(path, os.O_RDONLY | getattr(os, "O_NOFOLLOW", 0))
        with os.fdopen(descriptor, "r", encoding="utf-8") as handle:
            try:
                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                return True
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
    except FileNotFoundError:
        return False
    except (PermissionError, ServiceError):
        return None
    except OSError:
        return None
    return False


def _read_startup_reservation(base: Path) -> dict[str, Any] | None:
    return _read_lifecycle_file(base / SERVICE_STARTUP_FILENAME)


def _read_lifecycle_file(path: Path) -> dict[str, Any] | None:
    try:
        _reject_link_or_nonfile(path)
        if not path.exists() or path.stat().st_size > 4_096:
            return None
        with path.open("r", encoding="utf-8") as handle:
            raw = json.load(handle)
    except (OSError, TypeError, ValueError, json.JSONDecodeError, ServiceError):
        return None
    if not isinstance(raw, Mapping):
        return None
    pid = raw.get("pid")
    nonce = raw.get("nonce")
    started_at = raw.get("started_at")
    if not _valid_pid(pid) or not _valid_nonce(nonce) or not _is_timestamp(started_at):
        return None
    return {"pid": pid, "nonce": nonce, "started_at": float(started_at)}


def _record_owner(base: Path, pid: int, nonce: str, started_at: float) -> None:
    with _state_lock(base):
        state = _load_state(base)
        state["owner"] = {"pid": pid, "nonce": nonce, "started_at": started_at,
                          "runtime_version": __version__}
        _write_state(base, state)


def _clear_owner(base: Path, pid: int, nonce: str) -> None:
    with _state_lock(base):
        state = _load_state(base)
        owner = state["owner"]
        if owner and owner["pid"] == pid and owner["nonce"] == nonce:
            state["owner"] = None
            _write_state(base, state)


def _reserve_startup(base: Path, now: float) -> dict[str, Any]:
    _ensure_base_dir(base)
    path = base / SERVICE_STARTUP_FILENAME
    existing = _read_startup_reservation(base)
    if existing is not None:
        if now - existing["started_at"] <= DEFAULT_STARTUP_TTL and _pid_alive(existing["pid"]):
            raise ServiceAlreadyRunning("service is starting")
        try:
            path.unlink(missing_ok=True)
        except OSError:
            raise ServiceError("service startup is unavailable") from None
    reservation = {
        "version": STATE_VERSION,
        "pid": os.getpid(),
        "nonce": secrets.token_hex(16),
        "started_at": now,
    }
    try:
        flags = os.O_CREAT | os.O_EXCL | os.O_WRONLY | getattr(os, "O_NOFOLLOW", 0)
        descriptor = os.open(path, flags, 0o600)
        try:
            os.write(descriptor, json.dumps(reservation, separators=(",", ":")).encode("utf-8"))
            os.fsync(descriptor)
        finally:
            os.close(descriptor)
        os.chmod(path, 0o600)
    except FileExistsError:
        raise ServiceAlreadyRunning("service is starting") from None
    except OSError:
        raise ServiceError("service startup is unavailable") from None
    return reservation


def _set_startup_child(base: Path, nonce: str, child_pid: int) -> None:
    path = base / SERVICE_STARTUP_FILENAME
    current = _read_startup_reservation(base)
    if current is None or current["nonce"] != nonce:
        raise ServiceError("service startup is unavailable")
    payload = {"version": STATE_VERSION, "pid": child_pid, "nonce": nonce, "started_at": current["started_at"]}
    _atomic_write_json(path, payload)


def _clear_startup_reservation(base: Path, nonce: str) -> None:
    path = base / SERVICE_STARTUP_FILENAME
    current = _read_startup_reservation(base)
    if current is None or current["nonce"] != nonce:
        return
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def _clear_stop_request(base: Path) -> None:
    with _state_lock(base):
        state = _load_state(base)
        if state["stop_requested"]:
            state["stop_requested"] = False
            state["stop_requested_at"] = None
            _write_state(base, state)


def _consume_stop_request(base: Path) -> None:
    with _state_lock(base):
        state = _load_state(base)
        if state["stop_requested"]:
            state["stop_requested"] = False
            state["stop_requested_at"] = None
            _write_state(base, state)


def _has_fresh_retry_work(base: Path, project: str) -> bool:
    """Conservative scheduling hint; Store still atomically owns every claim.

    Never inspect evidence bodies or replay linked jobs here. In particular,
    failed links remain excluded even when their session has other fresh work.
    """
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        return connection.execute(
            "SELECT 1 FROM entries AS e WHERE e.project=? AND e.superseded_by IS NULL "
            "AND (e.source IN ('hook:UserPromptSubmit','hook:Stop','hook:PostToolUse') "
            "OR e.source LIKE 'hook:PostToolUse:%') "
            "AND NOT EXISTS (SELECT 1 FROM observation_job_sources AS links "
            "WHERE links.source_id=e.id) "
            "AND NOT EXISTS (SELECT 1 FROM observation_jobs AS j WHERE j.project=e.project "
            "AND j.status='running' AND (j.session_id IS NULL OR e.session_id IS NULL "
            "OR j.session_id=e.session_id OR COALESCE(j.lease_token,'') NOT LIKE 'session-%')) LIMIT 1",
            (project,),
        ).fetchone() is not None
    except (OSError, sqlite3.Error, ServiceError, ValueError):
        return False
    finally:
        if connection is not None:
            connection.close()


def _fresh_retry_capacity(record: Mapping[str, Any]) -> int:
    """Reserve room for every possible fresh failure without widening the queue."""
    if not record["fresh_work_due"] or record["retry_requested"]:
        return 0
    count = len(record["pending_retries"]) + int(record["retry_job_id"] is not None)
    return max(0, MAX_PROCESSOR_WORKERS - count) if count else 0


def _claim_due_project(
    base: Path, now: float, processor_timeout: float, *, allowed_projects: set[str] | None = None,
) -> dict[str, Any]:
    with _state_lock(base):
        state = _load_state(base)
        if state["stop_requested"]:
            return {"kind": "stop"}
        projects = state["projects"]
        for record in projects.values():
            if record["inflight_until"] is not None and record["inflight_until"] <= now:
                record["inflight_generation"] = None
                record["inflight_until"] = None
                record["due_at"] = min(record["due_at"], now)

        for project, record in projects.items():
            if (not record["blocked"] and record["parked"] is None
                    and record["inflight_generation"] is None and record["due_at"] > now
                    and _fresh_retry_capacity(record) > 0
                    and not _has_fresh_retry_work(base, project)):
                record["fresh_work_due"] = False

        ready = [
            project
            for project, record in projects.items()
            if (allowed_projects is None or project in allowed_projects)
            and not record["blocked"]
            and record["parked"] is None
            and record["inflight_generation"] is None
            and (record["due_at"] <= now or _fresh_retry_capacity(record) > 0)
        ]
        if not ready:
            due_values = [
                record["due_at"]
                for record in projects.values()
                if not record["blocked"]
                and record["parked"] is None
                and record["inflight_generation"] is None
            ]
            _write_state(base, state)
            return {"kind": "wait", "due_at": min(due_values) if due_values else None}

        ordered = sorted(ready)
        cursor = state["cursor"]
        chosen = next((item for item in ordered if cursor is None or item > cursor), ordered[0])
        record = projects[chosen]
        fresh_retry_width = 0
        if record["due_at"] > now and _fresh_retry_capacity(record) > 0:
            fresh_retry_width = _fresh_retry_capacity(record)
            _preserve_retry_target(record)
            _clear_retry_target(record)
            record["attempts"] = 0
        record["fresh_work_due"] = False
        record["capture_due_at"] = None
        record["inflight_generation"] = record["generation"]
        record["inflight_until"] = now + processor_timeout + _INFLIGHT_GRACE_SECONDS
        state["cursor"] = chosen
        _write_state(base, state)
        return {
            "kind": "work",
            "project": chosen,
            "generation": record["generation"],
            "attempts": record["attempts"],
            "storage_attempts": record["storage_attempts"],
            "retry_requested": record["retry_requested"],
            "retry_job_id": record["retry_job_id"],
            "retry_error_code": record["retry_error_code"],
            "retry_attempt_count": record["retry_attempt_count"],
            "pending_retries": record["pending_retries"],
            "fresh_retry_width": fresh_retry_width,
        }


def _park_unprocessed_project(
    base: Path, project: str, generation: int, reason: str, now: float
) -> None:
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if record is None:
            return
        if record["inflight_generation"] == generation:
            record["inflight_generation"] = None
            record["inflight_until"] = None
            record["due_at"] = min(record["due_at"], now)
            if reason == "not_selected":
                record["parked"] = "not_selected"
            _write_state(base, state)


def _has_other_eligible_project(
    base: Path,
    data_dir: str | os.PathLike[str] | None,
    config_loader: Callable[[str | os.PathLike[str] | None], Mapping[str, Any]],
    *,
    excluded_project: str,
) -> bool:
    """Return whether another queued project can still make progress.

    The state read is deliberately separate from claiming work: a failed
    project is already blocked, and the next loop iteration can then use the
    normal fair claim path for whichever eligible record remains.  Projects
    parked for scope/configuration are not considered, while a due time or
    inflight lease is allowed to keep the worker alive until that work is
    ready.
    """

    with _state_lock(base):
        state = _load_state(base)
        candidates = [
            project
            for project, record in state["projects"].items()
            if project != excluded_project
            and not record["blocked"]
            and record["parked"] is None
        ]
    for project in candidates:
        eligible, _, _, _ = _eligibility(project, data_dir, config_loader)
        if eligible:
            return True
    return False


def _clear_consumed_retry(record: dict[str, Any], generation: int) -> None:
    # A retry requested while the worker ran belongs to the next invocation.
    if record["retry_generation"] is not None and record["retry_generation"] <= generation:
        record["retry_requested"] = False
        record["retry_generation"] = None


def _clear_retry_target(record: dict[str, Any]) -> None:
    record["storage_attempts"] = 0
    record["retry_job_id"] = None
    record["retry_error_code"] = None
    record["retry_attempt_count"] = None


def _finish_deferred(base: Path, project: str, generation: int, retry_at: float, now: float) -> None:
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if record is None or record["inflight_generation"] != generation:
            return
        record["inflight_generation"] = None
        record["inflight_until"] = None
        # No batch was claimed, so preserve both explicit and exact retries.
        # Bound untrusted receipt timing, and avoid repeated processor calls
        # while Store's different (usually longer) lease is still active.
        record["due_at"] = (now if record["generation"] != generation else
                            max(now + 1.0, min(retry_at, now + MAX_LEASE_SECONDS)))
        _write_state(base, state)


def _pending_maintenance(base: Path, project: str) -> bool:
    from .quarantine_recovery import STATE_FILENAME, status, RecoveryStateError
    if not (base / STATE_FILENAME).exists():
        return False
    try:
        return any(row["state"] == "scheduled" for row in status(base, project=project))
    except RecoveryStateError:
        return False


def _finish_maintenance(base: Path, project: str, generation: int, now: float) -> None:
    """Release maintenance ownership without granting another model attempt.

    Existing operational retries, blockers and their backoff stay authoritative.
    The terminal job receipt supplies processing counts, not this scheduling hint.
    """
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if record is None or record["inflight_generation"] != generation:
            return
        record["inflight_generation"] = None
        record["inflight_until"] = None
        if record["retry_job_id"] is None and not record["pending_retries"]:
            record["due_at"] = now
        record["fresh_work_due"] = True
        _write_state(base, state)


def _finish_success(
    base: Path,
    project: str,
    generation: int,
    status: str,
    index_pending: bool,
    now: float,
) -> None:
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if record is None or record["inflight_generation"] != generation:
            return
        record["inflight_generation"] = None
        record["inflight_until"] = None
        record["attempts"] = 0
        record["storage_attempts"] = 0
        _clear_consumed_retry(record, generation)
        _clear_retry_target(record)
        _refresh_rejection_count(base, project, record)
        record["last_code"] = "invalid_response" if record["rejected_batches"] else None
        if record["generation"] != generation:
            record["due_at"] = max(now, record["capture_due_at"] or now)
        elif status == "idle" and not index_pending:
            if _pending_maintenance(base, project):
                record["parked"] = None
                record["due_at"] = now
            elif record["rejected_batches"]:
                # Preserve a visible warning while dormant. Ordinary enqueue
                # wakes new work; polling cannot repeatedly invoke the model.
                record["parked"] = "rejected_batches"
            else:
                del state["projects"][project]
                if state["cursor"] == project:
                    state["cursor"] = None
        else:
            # A processed/skipped batch can be followed by more raw entries.
            # Keep draining until one invocation reports idle.
            record["due_at"] = now
        _write_state(base, state)


def _finish_local_only(
    base: Path,
    project: str,
    generation: int,
    index_pending: bool,
    semantic_enabled: bool,
    now: float,
) -> None:
    """Release a local-index-only pass without removing raw observations."""

    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if record is None:
            return
        record["inflight_generation"] = None
        record["inflight_until"] = None
        # An enqueue during the index pass already advanced generation.  In
        # either case the project remains explicitly queued for the future AI
        # worker; only the local indexing work may be considered drained.
        record["due_at"] = now
        if record["generation"] != generation:
            record["parked"] = None
        elif index_pending:
            record["parked"] = None
        elif semantic_enabled:
            record["parked"] = "processor_disabled"
        else:
            record["parked"] = "semantic_disabled"
        _write_state(base, state)


def _valid_job_id(value: Any) -> bool:
    return (isinstance(value, str) and 1 <= len(value) <= 64
            and all(c in "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-" for c in value))


def _persisted_expired_claim(base: Path, project: str, job_id: Any, now: float) -> bool:
    if not _valid_job_id(job_id):
        return False
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        row = connection.execute(
            "SELECT j.lease_expires_at FROM observation_jobs AS j WHERE j.id = ? AND j.project = ? "
            "AND j.processor_id = ? AND j.model = ? AND j.reasoning_effort = ? "
            "AND j.status = 'running' AND j.lease_token IS NOT NULL "
            "AND EXISTS (SELECT 1 FROM observation_job_sources AS links WHERE links.job_id = j.id) "
            "AND NOT EXISTS (SELECT 1 FROM observation_job_sources AS links "
            "LEFT JOIN entries AS e ON e.id = links.source_id AND e.project = j.project "
            "WHERE links.job_id = j.id AND e.id IS NULL)",
            (job_id, project, PROCESSOR_ID, MODEL, REASONING_EFFORT),
        ).fetchone()
        if row is None or not isinstance(row[0], str):
            return False
        expiry = datetime.fromisoformat(row[0].replace("Z", "+00:00"))
        return expiry.tzinfo is not None and expiry <= datetime.fromtimestamp(now, timezone.utc)
    except (OSError, sqlite3.Error, ServiceError, ValueError, OverflowError):
        return False
    finally:
        if connection is not None:
            connection.close()


def _persisted_rejection(base: Path, project: str, job_id: Any) -> bool:
    return _persisted_failed_batch(base, project, job_id, "invalid_response")


def _persisted_failed_batch(base: Path, project: str, job_id: Any, code: str) -> bool:
    """Confirm a durable failed batch before permitting independent work.

    Read job metadata only through a read-only SQLite connection. A missing,
    malformed, foreign-project, or uncommitted receipt remains fail-closed.
    """

    if not _valid_job_id(job_id):
        return False
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        row = connection.execute(
            "SELECT j.id FROM observation_jobs AS j WHERE j.id = ? AND j.project = ? "
            "AND j.processor_id = ? AND j.model = ? AND j.reasoning_effort = ? "
            "AND j.status = 'failed' AND j.error_code = ? "
            "AND j.lease_token IS NULL AND j.lease_expires_at IS NULL "
            "AND EXISTS (SELECT 1 FROM observation_job_sources AS links WHERE links.job_id = j.id) "
            "AND NOT EXISTS (SELECT 1 FROM observation_job_sources AS links "
            "LEFT JOIN entries AS e ON e.id = links.source_id AND e.project = j.project "
            "WHERE links.job_id = j.id AND e.id IS NULL)",
            (job_id, project, PROCESSOR_ID, MODEL, REASONING_EFFORT, code),
        ).fetchone()
        return row is not None
    except (OSError, sqlite3.Error, ServiceError, ValueError):
        return False
    finally:
        if connection is not None:
            connection.close()


def _runner_failure_snapshot(base: Path, project: str, job_id: Any = None, *, code: str = "runner_failure") -> dict[str, Any] | None:
    """Read one durable failed attempt, using no record bodies or model text.

    Legacy blocks lack a job ID. Recover only an unambiguous runner failure
    with no other operational failure or running claim in that project.
    """
    if job_id is not None and not _valid_job_id(job_id):
        return None
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        if job_id is None and connection.execute(
            "SELECT 1 FROM observation_jobs WHERE project=? AND processor_id=? AND model=? "
            "AND reasoning_effort=? AND (status='running' OR (status='failed' "
            "AND error_code NOT IN (?,'invalid_response'))) LIMIT 1",
            (project, PROCESSOR_ID, MODEL, REASONING_EFFORT, code),
        ).fetchone() is not None:
            return None
        rows = connection.execute(
            "SELECT j.id,j.attempt_count,j.worker_thread_id,j.worker_turn_id FROM observation_jobs AS j WHERE j.project=? "
            "AND j.processor_id=? AND j.model=? AND j.reasoning_effort=? "
            "AND j.status='failed' AND j.error_code=? "
            "AND j.lease_token IS NULL AND j.lease_expires_at IS NULL "
            "AND (? IS NULL OR j.id=?) "
            "AND EXISTS (SELECT 1 FROM observation_job_sources AS s WHERE s.job_id=j.id) "
            "AND NOT EXISTS (SELECT 1 FROM observation_job_sources AS s "
            "LEFT JOIN entries AS e ON e.id=s.source_id AND e.project=j.project "
            "WHERE s.job_id=j.id AND e.id IS NULL) LIMIT 2",
            (project, PROCESSOR_ID, MODEL, REASONING_EFFORT, code, job_id, job_id),
        ).fetchall()
        if len(rows) != 1:
            return None
        failed_job_id, attempt_count, worker_thread_id, worker_turn_id = rows[0]
        # A lost turn/start response has a thread ID but no turn ID. Neither
        # may be present when automatically replaying a transport failure.
        if code in _TRANSPORT_FAILURE_CODES and (worker_thread_id is not None or worker_turn_id is not None):
            return None
        if not isinstance(attempt_count, int) or not 1 <= attempt_count <= 1_000_000_000:
            return None
        from .observation_diagnostics import read_failure_receipts
        receipts = read_failure_receipts(connection, failed_job_id)
        current = receipts[-1] if receipts and receipts[-1]["attempt_count"] == attempt_count else None
        reason = current["reason_code"] if current and current["error_code"] == "runner_failure" else None
        return {"job_id": failed_job_id, "attempt_count": attempt_count,
                "reason_code": reason if reason in _RUNNER_REASONS else None, "code": code}
    except (OSError, sqlite3.Error, ServiceError, ValueError):
        return None
    finally:
        if connection is not None:
            connection.close()


def _reconcile_retry_snapshot(base: Path, project: str, job_id: Any, now: float) -> dict[str, Any]:
    """Observe a concurrently changed retry target without widening its claim."""
    unavailable = {"status": "failed", "code": "recovery_unavailable"}
    if not _valid_job_id(job_id):
        return unavailable
    unavailable["job_id"] = job_id
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        row = connection.execute(
            "SELECT status,error_code,attempt_count,lease_expires_at,lease_token IS NOT NULL "
            "FROM observation_jobs WHERE id=? AND project=? AND processor_id=? AND model=? AND reasoning_effort=?",
            (job_id, project, PROCESSOR_ID, MODEL, REASONING_EFFORT),
        ).fetchone()
        if row is None:
            return unavailable
        status, code, attempt_count, lease_expiry, has_lease = row
        if status in {"processed", "skipped"} and not has_lease and lease_expiry is None:
            # Keep the project due for an ordinary pass: a successful repair
            # of this batch says nothing about independent pending evidence.
            return {"status": "processed", "job_id": job_id}
        if status == "failed" and not has_lease and lease_expiry is None:
            if not isinstance(code, str) or not _safe_code(code):
                return unavailable
            from .observation_diagnostics import read_failure_receipts
            receipts = read_failure_receipts(connection, job_id)
            reason = (receipts[-1]["reason_code"] if receipts
                      and receipts[-1]["attempt_count"] == attempt_count
                      and receipts[-1]["error_code"] == code else None)
            return {"status": "failed", "code": code, "job_id": job_id, "reason_code": reason}
        if status == "running" and has_lease and isinstance(lease_expiry, str):
            expires = datetime.fromisoformat(lease_expiry.replace("Z", "+00:00"))
            if expires.tzinfo is None:
                return unavailable
            retry_at = expires.timestamp()
            if not _is_timestamp(retry_at):
                return unavailable
            if retry_at > now:
                return {"status": "deferred", "retry_at": retry_at, "job_id": job_id}
            return {"status": "failed", "code": "lease_expired", "job_id": job_id}
        return unavailable
    except (OSError, sqlite3.Error, ServiceError, ValueError, OverflowError):
        return unavailable
    finally:
        if connection is not None:
            connection.close()


def _runner_retry_limit(reason_code: Any) -> int:
    if isinstance(reason_code, str) and reason_code in _TRANSIENT_RUNNER_REASONS:
        return MAX_RUNNER_FAILURE_RETRIES
    if reason_code is None or reason_code == "native_turn_failed":
        return MAX_UNKNOWN_RUNNER_FAILURE_RETRIES
    return 0


def _schedule_runner_retry(
    record: dict[str, Any], snapshot: Mapping[str, Any], now: float, retry_backoff: float,
) -> bool:
    code = snapshot.get("code", "runner_failure")
    limit = _runner_retry_limit(snapshot["reason_code"]) if code == "runner_failure" else 0
    attempts = max(record["attempts"], snapshot["attempt_count"])
    cooldown = (code in _TRANSPORT_FAILURE_CODES
                or snapshot["reason_code"] in _TRANSIENT_RUNNER_REASONS)
    if attempts > limit:
        if not cooldown:
            return False
        # Keep demonstrated transient outages recoverable without a hot loop.
        # Cap the exponent too: attempts is durable, externally validated data.
        delay = min(MAX_COOLDOWN_BACKOFF_SECONDS,
                    COOLDOWN_BACKOFF_SECONDS * (2 ** min(3, attempts - limit - 1)))
    else:
        delay = min(MAX_BACKOFF_SECONDS, retry_backoff * (2 ** max(0, attempts - 1)))
    record["retry_job_id"] = snapshot["job_id"]
    record["retry_error_code"] = code
    record["retry_attempt_count"] = snapshot["attempt_count"]
    record["blocked"] = False
    record["due_at"] = now + delay
    record["fresh_work_due"] = True
    return True


def _only_retired_operational_failures(base: Path, project: str, code: str) -> bool:
    """Permit fresh work after a profile upgrade without replaying old batches."""
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        # A running claim under any profile or a current operational failure
        # keeps the project blocked. Content rejections stay quarantined.
        if connection.execute(
            "SELECT 1 FROM observation_jobs WHERE project=? AND (status='running' OR "
            "(status='failed' AND error_code<>'invalid_response' AND "
            "processor_id=? AND model=? AND reasoning_effort=?)) LIMIT 1",
            (project, PROCESSOR_ID, MODEL, REASONING_EFFORT),
        ).fetchone() is not None:
            return False
        return connection.execute(
            "SELECT 1 FROM observation_jobs WHERE project=? AND status='failed' AND error_code=? "
            "AND processor_id=? AND (model<>? OR reasoning_effort<>?) "
            "AND lease_token IS NULL AND lease_expires_at IS NULL LIMIT 1",
            (project, code, PROCESSOR_ID, MODEL, REASONING_EFFORT),
        ).fetchone() is not None
    except (OSError, sqlite3.Error, ServiceError, ValueError):
        return False
    finally:
        if connection is not None:
            connection.close()


def _recover_legacy_runner_blocks(base: Path, now: float, retry_backoff: float) -> None:
    """Reconcile blocked records against the current durable retry policy."""
    with _state_lock(base):
        state = _load_state(base)
        changed = False
        for project, record in state["projects"].items():
            if (state["stop_requested"] or not record["blocked"]
                    or record["last_code"] not in {"runner_failure", *_TRANSPORT_FAILURE_CODES}
                    or record["parked"] is not None
                    or record["inflight_generation"] is not None or record["retry_requested"]):
                continue
            record["runner_recovery_checked"] = True
            changed = True
            snapshot = _runner_failure_snapshot(base, project, record["last_failure_job"], code=record["last_code"])
            if snapshot is None:
                if _only_retired_operational_failures(base, project, record["last_code"]):
                    # Ordinary claims exclude every old failed source. The new
                    # profile can drain independent captures without retry_failed.
                    record["blocked"] = False
                    record["attempts"] = 0
                    record["due_at"] = now
                    _clear_retry_target(record)
                continue
            record["last_failure_job"] = snapshot["job_id"]
            record["last_failure_detail"] = _runner_failure_detail(snapshot["reason_code"])
            record["attempts"] = max(record["attempts"], snapshot["attempt_count"])
            _schedule_runner_retry(record, snapshot, now, retry_backoff)
        if changed:
            _write_state(base, state)


def _rejection_counts(base: Path, projects: list[str]) -> dict[str, int] | None:
    """Read unresolved failures, so a later explicit repair clears warnings."""

    if not projects:
        return {}
    connection = None
    try:
        database = base / "memory.sqlite3"
        _reject_link_or_nonfile(database)
        connection = sqlite3.connect(database.as_uri() + "?mode=ro", uri=True, timeout=2.0)
        placeholders = ",".join("?" for _ in projects)
        rows = connection.execute(
            "SELECT project, COUNT(*) FROM observation_jobs "
            f"WHERE project IN ({placeholders}) AND processor_id = ? AND model = ? "
            "AND reasoning_effort = ? AND status = 'failed' AND error_code = 'invalid_response' "
            "GROUP BY project", (*projects, PROCESSOR_ID, MODEL, REASONING_EFFORT),
        ).fetchall()
        return {project: count for project, count in rows}
    except (OSError, sqlite3.Error, ServiceError, ValueError):
        return None
    finally:
        if connection is not None:
            connection.close()


def _refresh_rejection_count(base: Path, project: str, record: dict[str, Any]) -> None:
    """Reconcile repaired batches before deciding whether an idle queue parks."""
    if not record["rejected_batches"]:
        return
    counts = _rejection_counts(base, [project])
    if counts is None:
        return
    record["rejected_batches"] = counts.get(project, 0)
    if not record["rejected_batches"]:
        record["last_rejected_job"] = None
        record["last_rejected_reason"] = None


def _record_rejection(record: dict[str, Any], job_id: str, reason_code: Any = None) -> None:
    if record["last_rejected_job"] != job_id:
        record["rejected_batches"] += 1
        record["last_rejected_reason"] = None
    record["last_rejected_job"] = job_id
    if isinstance(reason_code, str) and reason_code in INVALID_RESPONSE_REASONS:
        record["last_rejected_reason"] = reason_code
    record["last_code"] = "invalid_response"


def _quarantine_rejection(
    base: Path, project: str, generation: int, job_id: Any, now: float, *, reason_code: Any = None,
) -> bool:
    # Unknown historic reasons require explicit resume_pending after review.
    # Runner envelopes, lifecycle, and internal source corruption may signal
    # infrastructure failures and cannot be treated as bad model content.
    if not isinstance(reason_code, str) or reason_code not in _CONTENT_REJECTION_REASONS:
        return False
    if not _persisted_rejection(base, project, job_id):
        return False
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if (record is None or record["inflight_generation"] != generation
                or record["last_rejected_job"] == job_id):
            # Repeated identical receipts are not progress. Do not spin on a
            # broken adapter that keeps returning a previously rejected job.
            return False
        _record_rejection(record, job_id, reason_code)
        record["inflight_generation"] = None
        record["inflight_until"] = None
        _clear_consumed_retry(record, generation)
        _clear_retry_target(record)
        record["attempts"] = 0
        record["blocked"] = False
        record["due_at"] = now
        _write_state(base, state)
    return True


def _finish_failure(
    base: Path,
    project: str,
    generation: int,
    code: str,
    *,
    now: float,
    max_timeout_retries: int,
    retry_backoff: float,
    rejected_job_id: Any = None,
    reason_code: Any = None,
    failure_detail: Mapping[str, Any] | None = None,
    automatic_retry_allowed: bool = True,
) -> bool:
    safe_code = _normalise_code(code)
    rejected = safe_code == "invalid_response" and _persisted_rejection(base, project, rejected_job_id)
    runner_failure = (_runner_failure_snapshot(base, project, rejected_job_id, code=safe_code)
                      if safe_code in {"runner_failure", *_TRANSPORT_FAILURE_CODES} and _valid_job_id(rejected_job_id) else None)
    if (runner_failure is not None and runner_failure["reason_code"] is None
            and isinstance(reason_code, str) and reason_code in _RUNNER_REASONS
            and _runner_retry_limit(reason_code) == 0):
        # A receipt can narrow recovery, never grant broader permission than
        # the durable diagnostic. Mixed-version storage must not turn an
        # observed authentication or cancellation failure into an unknown retry.
        runner_failure["reason_code"] = reason_code
    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if record is None or record["inflight_generation"] != generation:
            return False
        record["inflight_generation"] = None
        record["inflight_until"] = None
        preclaim = (safe_code == "storage_failure" and rejected_job_id is None
                    and _safe_preclaim_retry(failure_detail))
        if not preclaim:
            _clear_consumed_retry(record, generation)
            _clear_retry_target(record)
        if rejected:
            _record_rejection(record, rejected_job_id, reason_code)
        record["last_code"] = safe_code
        record["last_failure_at"] = now
        record["last_failure_detail"] = (
            _runner_failure_detail(runner_failure["reason_code"] if runner_failure else reason_code)
            if safe_code == "runner_failure" else _safe_failure_detail(failure_detail)
        )
        record["last_failure_job"] = rejected_job_id if _valid_job_id(rejected_job_id) else None
        record["runner_recovery_checked"] = True
        if preclaim:
            retrying = automatic_retry_allowed and _schedule_preclaim_storage_retry(
                record, record["last_failure_detail"], now, retry_backoff)
            record["blocked"] = not retrying
            _write_state(base, state)
            return bool(retrying)
        if record["retry_requested"]:
            # An explicit retry arriving during this failed invocation has
            # not been consumed. Honour it before applying the old failure.
            record["blocked"] = False
            record["attempts"] = 0
            record["due_at"] = now
            _write_state(base, state)
            return True
        if runner_failure is not None:
            record["attempts"] = max(record["attempts"] + 1, runner_failure["attempt_count"])
            if automatic_retry_allowed and _schedule_runner_retry(record, runner_failure, now, retry_backoff):
                _write_state(base, state)
                return True
        if (automatic_retry_allowed and safe_code == "storage_failure" and rejected_job_id is None
                and _schedule_preclaim_storage_retry(record, record["last_failure_detail"], now, retry_backoff)):
            _write_state(base, state)
            return True
        if automatic_retry_allowed and safe_code in {"timeout", "lease_expired"}:
            record["attempts"] += 1
            retry_limit = (MAX_LEASE_RECOVERY_RETRIES if safe_code == "lease_expired"
                           else max_timeout_retries)
            if record["attempts"] <= retry_limit and (
                safe_code != "timeout" or _persisted_failed_batch(base, project, rejected_job_id, "timeout")
            ):
                # Expired running jobs are reclaimed normally; never opt into
                # retrying unrelated quarantined model responses.
                record["retry_job_id"] = rejected_job_id if safe_code == "timeout" else None
                delay = min(MAX_BACKOFF_SECONDS, retry_backoff * (2 ** (record["attempts"] - 1)))
                record["due_at"] = now + delay
                _write_state(base, state)
                return True
        record["blocked"] = True
        record["due_at"] = now
        _write_state(base, state)
        return False


def _safe_preclaim_retry(detail: Any) -> bool:
    checked = safe_storage_failure_detail(detail)
    return bool(checked is not None and checked["retry_safe"])


def _schedule_preclaim_storage_retry(
    record: dict[str, Any], detail: Any, now: float, retry_backoff: float,
) -> bool:
    if not _safe_preclaim_retry(detail):
        return False
    record["storage_attempts"] = record.get("storage_attempts", 0) + 1
    if record["retry_job_id"] is None and not record["retry_requested"]:
        record["attempts"] = record["storage_attempts"]
    if record["storage_attempts"] > MAX_PRECLAIM_STORAGE_RETRIES:
        return False
    record["blocked"] = False
    record["due_at"] = now + min(MAX_BACKOFF_SECONDS, retry_backoff * 2 ** (record["storage_attempts"] - 1))
    return True


def _validate_workers(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= MAX_PROCESSOR_WORKERS:
        raise ValueError("processor_workers must be an integer from 1 to 4")
    return value


def _record_workers(base: Path, configured: int, effective: int, active: int) -> None:
    with _state_lock(base):
        state = _load_state(base)
        if state["owner"] is not None:
            state["owner"]["workers"] = {"configured": configured, "effective": effective, "active": active}
            _write_state(base, state)


def _validate_pending_retries(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list) or len(value) > MAX_PROCESSOR_WORKERS:
        raise ServiceStateError("service state is unavailable")
    result = []
    for target in value:
        if (not isinstance(target, Mapping)
                or set(target) - {"storage_attempts"} != {"job_id", "error_code", "attempt_count", "attempts", "due_at"}
                or isinstance(target.get("storage_attempts", 0), bool)
                or not isinstance(target.get("storage_attempts", 0), int)
                or not 0 <= target.get("storage_attempts", 0) <= 1_000_000_000
                or (target["job_id"] is not None and not _valid_job_id(target["job_id"]))
                or not _is_timestamp(target["due_at"])
                or isinstance(target["attempts"], bool) or not isinstance(target["attempts"], int)
                or not 0 <= target["attempts"] <= 1_000_000_000
                or ((target["error_code"] is None) != (target["attempt_count"] is None))
                or (target["error_code"] is not None and (
                    target["error_code"] not in {"runner_failure", *_TRANSPORT_FAILURE_CODES}
                    or target["job_id"] is None or isinstance(target["attempt_count"], bool)
                    or not isinstance(target["attempt_count"], int)
                    or not 1 <= target["attempt_count"] <= 1_000_000_000))):
            raise ServiceStateError("service state is unavailable")
        result.append(dict(target))
    return result


def _retry_target(record: Mapping[str, Any]) -> dict[str, Any]:
    return {"job_id": record["retry_job_id"], "error_code": record["retry_error_code"],
            "attempt_count": record["retry_attempt_count"], "attempts": record["attempts"],
            "due_at": record["due_at"],
            **({"storage_attempts": record["storage_attempts"]} if record.get("storage_attempts") else {})}


def _preserve_retry_target(record: dict[str, Any]) -> None:
    """Do not lose another lane's retry when explicit recovery takes priority."""
    if record["retry_job_id"] is not None and all(
            target["job_id"] != record["retry_job_id"] for target in record["pending_retries"]):
        record["pending_retries"].append(_retry_target(record))


def _activate_retry(record: dict[str, Any], targets: list[dict[str, Any]]) -> None:
    # A reconciled retry may refer to a target already waiting in the queue.
    # Keep one permission per job and never accelerate its durable backoff.
    unique: dict[str | None, dict[str, Any]] = {}
    for candidate in targets:
        previous = unique.get(candidate["job_id"])
        if previous is None:
            unique[candidate["job_id"]] = dict(candidate)
        else:
            newer = candidate if (candidate["attempt_count"] or 0) > (previous["attempt_count"] or 0) else previous
            merged = dict(newer, due_at=max(previous["due_at"], candidate["due_at"]))
            if (candidate["attempt_count"], candidate["error_code"]) == (previous["attempt_count"], previous["error_code"]):
                storage_attempts = max(previous.get("storage_attempts", 0), candidate.get("storage_attempts", 0))
                if storage_attempts:
                    merged["storage_attempts"] = storage_attempts
            unique[candidate["job_id"]] = merged
    ordered = sorted(unique.values(), key=lambda target: target["due_at"])
    target, *remaining = ordered
    record["retry_job_id"] = target["job_id"]
    record["retry_error_code"] = target["error_code"]
    record["retry_attempt_count"] = target["attempt_count"]
    record["attempts"] = target["attempts"]
    record["storage_attempts"] = target.get("storage_attempts", 0)
    record["due_at"] = target["due_at"]
    record["pending_retries"] = remaining


def _finish_cohort(
    base: Path, project: str, generation: int, choice: Mapping[str, Any],
    results: list[Mapping[str, Any]], *, data_dir: str | os.PathLike[str] | None,
    semantic_enabled: bool, indexer: Callable[..., Any] | None, now: float,
    max_timeout_retries: int, retry_backoff: float,
) -> dict[str, Any]:
    """Commit every result once, before releasing the project generation.

    Retry cohorts contain a single exact target. Fresh cohorts can produce up
    to four independent failures; each retry permission stays bound to its job
    and attempt. Local indexing runs only here, on the owning coordinator.
    """
    prepared = []
    for original in results:
        result = original
        automatic_retry_allowed = True
        if (result.get("status") == "blocked" and result.get("code") == "recovery_unavailable"
                and choice["retry_error_code"] in {"runner_failure", *_TRANSPORT_FAILURE_CODES}
                and not choice["retry_requested"]):
            result = _reconcile_retry_snapshot(base, project, choice["retry_job_id"], now)
            automatic_retry_allowed = result.get("code") == "lease_expired"
        status, code = _processor_outcome(result)
        job_id = result.get("job_id")
        reason = result.get("reason_code")
        rejected = code == "invalid_response" and _persisted_rejection(base, project, job_id)
        snapshot = (_runner_failure_snapshot(base, project, job_id, code=code)
                    if code in {"runner_failure", *_TRANSPORT_FAILURE_CODES} and _valid_job_id(job_id) else None)
        if (snapshot is not None and snapshot["reason_code"] is None
                and isinstance(reason, str) and reason in _RUNNER_REASONS and _runner_retry_limit(reason) == 0):
            snapshot["reason_code"] = reason
        timeout_persisted = (code == "timeout" and _persisted_failed_batch(base, project, job_id, "timeout"))
        prepared.append((result, status, code, rejected, snapshot, timeout_persisted, automatic_retry_allowed))
    index_pending = False
    index_detail = None
    try:
        if semantic_enabled:
            index_pending = _run_indexer(indexer, project, data_dir, bool(choice["retry_requested"]))
    except _IndexFailure as exc:
        index_detail = exc.detail
    except Exception:
        index_detail = _index_failure_detail({})

    with _state_lock(base):
        state = _load_state(base)
        record = state["projects"].get(project)
        if record is None or record["inflight_generation"] != generation:
            return {"status": "deferred"}
        unconsumed_preclaim = any(code == "storage_failure" and result.get("job_id") is None
                                  and _safe_preclaim_retry(result.get("failure_detail"))
                                  for result, _, code, *_ in prepared)
        targets = list(record["pending_retries"])
        record["pending_retries"] = []
        if not unconsumed_preclaim:
            _clear_consumed_retry(record, generation)
        _clear_retry_target(record)
        blocker = None
        blocker_failure = None
        latest_failure = None
        progress = False
        finished_batch = False
        retry_times = []
        last_code = None
        for result, status, code, rejected, snapshot, timeout_persisted, automatic in prepared:
            job_id, reason = result.get("job_id"), result.get("reason_code")
            if status == "deferred":
                retry_times.append(max(now + 1, min(result["retry_at"], now + MAX_LEASE_SECONDS)))
                if choice["retry_job_id"] is not None:
                    target = {"job_id": choice["retry_job_id"], "error_code": choice["retry_error_code"],
                              "attempt_count": choice["retry_attempt_count"], "attempts": choice["attempts"],
                              "due_at": retry_times[-1]}
                    targets.append(target)
                # A deferred explicit retry has not consumed authorization.
                if choice["retry_requested"] and not record["retry_requested"]:
                    record["retry_requested"] = True
                    record["retry_generation"] = generation
                continue
            if status != "failed":
                if _valid_job_id(job_id):
                    targets = [target for target in targets if target["job_id"] != job_id]
                progress = progress or status in {"processed", "skipped"}
                continue
            last_code = code
            finished_batch = finished_batch or rejected or snapshot is not None or timeout_persisted
            if rejected and isinstance(reason, str) and reason in _CONTENT_REJECTION_REASONS and record["last_rejected_job"] != job_id:
                _record_rejection(record, job_id, reason)
                progress = True
                continue
            if rejected:
                _record_rejection(record, job_id, reason)
            latest_failure = {
                "last_failure_at": now,
                "last_failure_job": job_id if _valid_job_id(job_id) else None,
                "last_failure_detail": (_safe_failure_detail(result.get("failure_detail")) if code == "storage_failure"
                                        else _runner_failure_detail(snapshot["reason_code"] if snapshot else reason)),
                "runner_recovery_checked": True,
            }
            # Per-job counters prevent another lane's attempt from consuming
            # this job's retry budget. A normal fresh batch starts at zero.
            candidate = _new_record(now)
            candidate["attempts"] = choice["attempts"] if choice["retry_job_id"] == job_id or code == "lease_expired" else 0
            if snapshot is not None:
                candidate["attempts"] = max(candidate["attempts"] + 1, snapshot["attempt_count"])
                if automatic and _schedule_runner_retry(candidate, snapshot, now, retry_backoff):
                    targets.append(_retry_target(candidate))
                    continue
            if code == "storage_failure" and job_id is None and _safe_preclaim_retry(latest_failure["last_failure_detail"]):
                candidate["retry_job_id"] = choice["retry_job_id"]
                candidate["retry_error_code"] = choice["retry_error_code"]
                candidate["retry_attempt_count"] = choice["retry_attempt_count"]
                candidate["retry_requested"] = choice["retry_requested"]
                candidate["attempts"] = choice["attempts"]
                candidate["storage_attempts"] = choice.get("storage_attempts", 0)
                if automatic and _schedule_preclaim_storage_retry(candidate, latest_failure["last_failure_detail"], now, retry_backoff):
                    targets.append(_retry_target(candidate))
                    continue
                # Exhaustion blocks further dispatch but retains the exact
                # unconsumed permission for a later explicit repair.
                targets.append(_retry_target(candidate))
            if automatic and code in {"timeout", "lease_expired"}:
                candidate["attempts"] += 1
                limit = MAX_LEASE_RECOVERY_RETRIES if code == "lease_expired" else max_timeout_retries
                if candidate["attempts"] <= limit and (code != "timeout" or timeout_persisted):
                    candidate["retry_job_id"] = job_id if code == "timeout" else None
                    candidate["due_at"] = now + min(MAX_BACKOFF_SECONDS, retry_backoff * 2 ** (candidate["attempts"] - 1))
                    targets.append(_retry_target(candidate))
                    continue
            # Keep the blocking code and its job/detail together. Otherwise a
            # later transient failure could make startup reconciliation retry
            # that transient and silently release a non-retryable blocker.
            blocker = code or "invalid_result"
            blocker_failure = latest_failure
        if index_detail is not None and blocker is None:
            blocker = last_code = "index_failure"
            blocker_failure = {"last_failure_at": now, "last_failure_job": None,
                               "last_failure_detail": index_detail, "runner_recovery_checked": True}
        if blocker_failure is not None or latest_failure is not None:
            record.update(blocker_failure or latest_failure)
        record["inflight_generation"] = None
        record["inflight_until"] = None
        record["blocked"] = blocker is not None and (not record["retry_requested"]
                            or (unconsumed_preclaim and record["retry_generation"] <= generation))
        _refresh_rejection_count(base, project, record)
        record["last_code"] = blocker or last_code or ("invalid_response" if record["rejected_batches"] else None)
        if targets:
            _activate_retry(record, targets)
            record["fresh_work_due"] = (progress or finished_batch
                                        or record["generation"] != generation)
        else:
            record["fresh_work_due"] = False
            record["storage_attempts"] = 0
            record["attempts"] = choice["attempts"] if retry_times and not progress else 0
            record["due_at"] = min(retry_times) if retry_times and not progress else now
        if record["generation"] != generation and (record["retry_requested"] or not targets):
            record["due_at"] = (now if record["retry_requested"]
                                else max(now, record["capture_due_at"] or now))
        if (not record["blocked"] and not targets and not record["retry_requested"]
                and not progress and not retry_times and not index_pending and record["generation"] == generation):
            if _pending_maintenance(base, project):
                record["parked"] = None
            elif record["rejected_batches"]:
                record["parked"] = "rejected_batches"
            else:
                del state["projects"][project]
                if state["cursor"] == project:
                    state["cursor"] = None
        _write_state(base, state)
        return {"status": "halted" if record["blocked"] else "continue", "code": record["last_code"]}


def _choose_processor(
    processor: Callable[..., Mapping[str, Any]] | None,
    runner: Callable[..., Mapping[str, Any]] | None,
) -> Callable[..., Mapping[str, Any]]:
    if processor is not None and runner is not None:
        raise ValueError("pass only one processor or runner")
    active = processor if processor is not None else runner
    if active is None:
        return process_pending
    if not callable(active):
        raise ValueError("processor must be callable")
    return active


def _call_processor(
    processor: Callable[..., Mapping[str, Any]],
    project: str,
    data_dir: str | os.PathLike[str] | None,
    retry_failed: bool,
    timeout: float,
    *,
    retry_job_id: str | None = None,
    retry_error_code: str | None = None,
    retry_attempt_count: int | None = None,
    parallel_sessions: bool = False,
) -> Mapping[str, Any]:
    try:
        arguments = {"data_dir": data_dir, "retry_failed": retry_failed, "timeout": timeout}
        if parallel_sessions:
            arguments["parallel_sessions"] = True
        if retry_job_id is not None:
            arguments["retry_job_id"] = retry_job_id
        if retry_error_code is not None:
            arguments["retry_error_code"] = retry_error_code
            arguments["retry_attempt_count"] = retry_attempt_count
        value = processor(project, **arguments)
    except Exception:
        return {"status": "failed", "code": "runner_failure"}
    return value if isinstance(value, Mapping) else {"status": "failed", "code": "invalid_result"}


def _processor_outcome(value: Mapping[str, Any]) -> tuple[str, str | None]:
    status = value.get("status")
    if status in {"processed", "skipped", "idle"}:
        return str(status), None
    if status == "deferred" and _is_timestamp(value.get("retry_at")):
        return "deferred", None
    if status == "failed":
        code = value.get("code")
        return "failed", _normalise_code(code) if isinstance(code, str) else "invalid_result"
    return "failed", "invalid_result"


def _run_indexer(
    indexer: Callable[..., Any] | None,
    project: str,
    data_dir: str | os.PathLike[str] | None,
    retry_failed: bool,
) -> bool:
    if indexer is None:
        return False
    if retry_failed:
        return _index_pending(indexer(project, data_dir, retry_failed=True))
    return _index_pending(indexer(project, data_dir))


def _index_pending(value: Any) -> bool:
    if value is None:
        return False
    if isinstance(value, bool):
        return value
    if isinstance(value, int) and not isinstance(value, bool) and value >= 0:
        return value > 0
    if isinstance(value, Mapping):
        status = value.get("status")
        if status in {"failed", "error"}:
            raise _IndexFailure(value)
        if "pending" in value:
            return _index_pending(value["pending"])
        if "remaining" in value:
            return _index_pending(value["remaining"])
    raise ServiceError("indexer returned an invalid result")


def _index_failure_detail(receipt: Mapping[str, Any]) -> dict[str, Any]:
    status = receipt.get("status")
    code = receipt.get("code")
    return {
        "stage": "index",
        "status": status if isinstance(status, str) and status in {"failed", "error"} else None,
        "code": code if isinstance(code, str) and code in _INDEX_FAILURE_CODES else None,
    }


def _safe_failure_detail(value: Any) -> dict[str, Any] | None:
    if not isinstance(value, Mapping):
        return None
    if value.get("stage") == "index":
        return _index_failure_detail(value)
    if value.get("stage") == "processor" and value.get("code") == "runner_failure":
        return _runner_failure_detail(value.get("reason_code"))
    if value.get("stage") == "storage":
        return safe_storage_failure_detail(value)
    return None


def _runner_failure_detail(reason_code: Any) -> dict[str, Any] | None:
    if not isinstance(reason_code, str) or reason_code not in _RUNNER_REASONS:
        return None
    return {"stage": "processor", "status": "failed", "code": "runner_failure", "reason_code": reason_code}


def _spawn_service_child(command: list[str], environment: Mapping[str, str]) -> subprocess.Popen[bytes]:
    return subprocess.Popen(
        command,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        close_fds=True,
        start_new_session=True,
        env=dict(environment),
    )


def _child_pid(child: Any) -> int:
    pid = getattr(child, "pid", None)
    if not _valid_pid(pid):
        raise ServiceError("service startup is unavailable")
    return pid


def _child_exited(child: Any) -> bool:
    poll = getattr(child, "poll", None)
    if not callable(poll):
        return False
    try:
        return poll() is not None
    except Exception:
        return True


def _service_receipt(status: str, *, jobs: int, code: str | None = None) -> dict[str, Any]:
    result: dict[str, Any] = {"status": status, "jobs": jobs}
    if code:
        result["code"] = _normalise_code(code)
    return result


def _valid_pid(value: Any) -> bool:
    return isinstance(value, int) and not isinstance(value, bool) and 1 <= value <= 2_147_483_647


def _valid_nonce(value: Any) -> bool:
    return isinstance(value, str) and len(value) == 32 and all(char in "0123456789abcdef" for char in value)


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    except OSError as exc:
        return exc.errno == errno.EPERM
    return True


def _safe_code(value: Any) -> bool:
    return isinstance(value, str) and 1 <= len(value) <= 64 and all(char in _SAFE_CODE_CHARS for char in value)


def _normalise_code(value: str) -> str:
    if _safe_code(value):
        return value
    return "invalid_result"


def _is_timestamp(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(float(value)) and float(value) >= 0


def _checked_now(clock: Callable[[], float]) -> float:
    try:
        value = clock()
    except Exception:
        raise ServiceError("service clock is unavailable") from None
    if not _is_timestamp(value):
        raise ServiceError("service clock is unavailable")
    return float(value)


def _validate_timeout(value: Any) -> float:
    checked = _validate_positive_number(value, "processor_timeout")
    if checked > 600:
        raise ValueError("processor_timeout must be between 1 and 600")
    return checked


def _validate_positive_number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)) or float(value) <= 0:
        raise ValueError(f"{field} must be positive")
    return float(value)


def _validate_nonnegative_number(value: Any, field: str) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(float(value)) or float(value) < 0:
        raise ValueError(f"{field} must be non-negative")
    return float(value)


def _validate_retries(value: Any) -> int:
    if isinstance(value, bool) or not isinstance(value, int) or not 0 <= value <= MAX_TIMEOUT_RETRIES:
        raise ValueError(f"max_timeout_retries must be between 0 and {MAX_TIMEOUT_RETRIES}")
    return value


def _validate_cycles(value: Any) -> int | None:
    if value is None:
        return None
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ValueError("max_cycles must be a non-negative integer")
    return value


def _validate_stop_event(value: Any) -> None:
    if value is not None and not callable(getattr(value, "is_set", None)):
        raise ValueError("stop_event must provide is_set")


def _event_is_set(event: Any | None) -> bool:
    return bool(event is not None and event.is_set())


def _sleep_delay(due_at: Any, now: float, poll_interval: float) -> float:
    if due_at is None:
        return poll_interval
    if not _is_timestamp(due_at):
        return poll_interval
    return min(poll_interval, max(0.0, float(due_at) - now))


def _bounded_sleep(sleeper: Callable[[float], Any], delay: float) -> None:
    # A zero delay is useful for deterministic tests and never blocks a normal
    # service because the default polling interval is one second.
    try:
        sleeper(delay)
    except Exception:
        raise ServiceError("service wait is unavailable") from None
