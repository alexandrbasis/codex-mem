from pathlib import Path
import json,hashlib,re,subprocess,sys,tarfile
BASE=Path(__file__).resolve().parent
PUBLIC=Path('/Users/alexandrbasis/Desktop/Coding/codex-mem-public/docs/evidence/project-memory-quality-2026-10-21-r17')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_text())
def dump(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def schema(v,s):
    types={'object':dict,'array':list,'string':str,'integer':int,'boolean':bool}
    if 'type' in s:assert type(v) is types[s['type']]
    if 'const' in s:assert v==s['const']
    if 'enum' in s:assert v in s['enum']
    if 'minimum' in s:assert v>=s['minimum']
    if 'minLength' in s:assert len(v)>=s['minLength']
    if 'pattern' in s:assert re.fullmatch(s['pattern'],v)
    if isinstance(v,dict):
        assert set(s.get('required',[]))<=set(v)
        if s.get('additionalProperties') is False:assert set(v)<=set(s['properties'])
        for k,z in v.items():
            if k in s.get('properties',{}):schema(z,s['properties'][k])
    if isinstance(v,list):
        assert len(v)>=s.get('minItems',0)
        assert len(v)<=s.get('maxItems',len(v))
        for z in v:schema(z,s.get('items',{}))
contracts={'public-fixture-contract.py':'96b9bcfdf12c4654243c2e57f54cba8fdbf6ae21d644849282aa9a57bf9c8877','prospective-gold-semantics-contract.json':'a3ceb608bc9d336cc0dd1d611f1294063f58f86cd651cf7e421a596510f6795e','sealed-semantic-review-metadata.schema.json':'8df15b220de0b83be4b6d280ece4289f10312677ae2bd943da21174d09d84d59','sealed-semantic-review-findings.schema.json':'1f179454dd4772956c0ab0d4bd9e9303fc14b071a83f830a16eb36b04d0767e8'}
for n,h in contracts.items():assert sha(PUBLIC/n)==h
pins={'holdout-fixture.json':'470f4382d6cc81e60e5a0511d1d3987dbd2534e3e6880843a3e73f00c7c83f45','holdout-gold.json':'2795b4afc4dd58c29ba17455bab9edc980ddd448d3dd453dc3de7beb1905be68','author-fact-rationale.json':'04363b14d63dbb74085190b2673f88a964c8c61e8575857f0e5c056d9f51752b','sealed-semantic-review.json':'d2f28eb7f85426070140285a965d6bb6dcf3425a1204de50ba10e3acbe28ac90','sealed-semantic-review-metadata.json':'19899664708d358240619ef7fac6d6b35fbaad383b4513ee75f27d887af401a1'}
for n,h in pins.items():assert sha(BASE/n)==h
f=read(BASE/'holdout-fixture.json');g=read(BASE/'holdout-gold.json');r=read(BASE/'author-fact-rationale.json');m=read(BASE/'sealed-semantic-review-metadata.json');review=read(BASE/'sealed-semantic-review.json')
schema(m,read(PUBLIC/'sealed-semantic-review-metadata.schema.json'));schema(review,read(PUBLIC/'sealed-semantic-review-findings.schema.json'))
for v in [m,review]:assert v['status']=='accepted' and v['unresolved_findings']==0
for key,name in [('fixture_sha256','holdout-fixture.json'),('gold_sha256','holdout-gold.json')]:assert m[key]==review['input_hashes'][key]==sha(BASE/name)
for key,name in [('mechanical_contract_sha256','public-fixture-contract.py'),('semantic_guidance_sha256','prospective-gold-semantics-contract.json')]:assert m[key]==review['input_hashes'][key]==contracts[name]
assert review['input_hashes']['author_fact_rationale_sha256']==sha(BASE/'author-fact-rationale.json')
assert m['sealed_review_receipt_sha256']==sha(BASE/'sealed-semantic-review.json')
expected={h['id']+'/'+q['id'] for h in f['histories'] for q in h['questions']}
assert expected==set(g['questions'])==set(r['facts'])
assert len(review['question_reviews'])==len(expected)==96
assert {q['case'] for q in review['question_reviews']}==expected
for q in review['question_reviews']:
    assert q['question_requirements_complete'] and q['difficult_scenarios_preserved']
    gf=g['questions'][q['case']]['required_facts'];assert len(q['required_facts'])==len(gf)
    assert [ff['fact_index'] for ff in q['required_facts']]==list(range(len(gf)))
    for ff,gg,rr in zip(q['required_facts'],gf,r['facts'][q['case']]):
        assert all(ff['checks'].values())
        assert ff['proposition']==gg['text']==rr['responsive_proposition']
        assert ff['question_clause']==rr['question_clause']
        canonical=[dict(s,source_field=s.get('source_field','body')) for s in gg['support']]
        assert ff['support']==canonical
        assert rr['support']==gg['support']
command=[sys.executable,str(PUBLIC/'public-fixture-contract.py'),str(BASE/'holdout-fixture.json'),str(BASE/'holdout-gold.json')]
run=subprocess.run(command,capture_output=True,text=True);assert run.returncode==0
mechanical=json.loads(run.stdout);assert mechanical==read(BASE/'mechanical-validation.json')
events=[e for h in f['histories'] for s in h['sessions'] for e in s['events']]
neg={t:sum(n['error_type']==t for q in g['questions'].values() for n in q['forbidden_inferences']) for t in ['false_merge','false_closure','project_mixing','deleted_resurrection']}
counts={'histories':len(f['histories']),'questions':len(expected),'required_facts':sum(len(q['required_facts']) for q in g['questions'].values()),'positive_anchors':len(mechanical['anchors']),'tool_captures':sum('tool_capture' in e for e in events),'checkpoints':sum(len(s['checkpoints']) for h in f['histories'] for s in h['sessions']),'deletions':sum(e['type']=='delete_observation' for e in events),'two_project_histories':sum(len(h['project_keys'])==2 for h in f['histories']),'one_project_histories':sum(len(h['project_keys'])==1 for h in f['histories']),'typed_negatives':sum(neg.values()),'typed_negative_counts':neg}
assert (counts['questions'],counts['required_facts'],counts['positive_anchors'],counts['tool_captures'],counts['checkpoints'],counts['deletions'],counts['two_project_histories'],counts['one_project_histories'],counts['typed_negatives'])==(96,210,216,48,32,16,12,4,71)
assert m['coverage']['questions']==counts['questions'] and m['coverage']['required_facts']==counts['required_facts']
assert all(m['coverage'][k] for k in ['all_questions_reviewed','all_required_facts_reviewed','negative_cases_reviewed'])
selfcheck=read(BASE/'author-selfcheck.json')
for k in ['histories','questions','required_facts','tool_captures','checkpoints','deletions','two_project_histories','one_project_histories']:assert selfcheck[k]==counts[k]
assert selfcheck['mechanical_pass'] and selfcheck['typed_negatives']==neg
ids=[h['id'] for h in f['histories']];assert ids==[f'E{i:02}' for i in range(1,17)]
idnote={'schema_version':1,'status':'HELD_NOT_RELEASED','history_ids':ids,'regen_history_id':'E01','reader_history_id':'E02','regen_member':True,'reader_member':True,'meaning':'Opaque ID membership only.'}
idpath=BASE/'id-only-attestation.json'
if idpath.exists():assert read(idpath)==idnote
else:dump(idpath,idnote)
history=sorted([p for d in ['versions','review-versions'] for p in (BASE/d).rglob('*') if p.is_file()]+[BASE/'review-fixes-v003.txt'],key=lambda p:str(p.relative_to(BASE)))
archive=BASE/'history.tar'
if archive.exists():
    with tarfile.open(archive,'r') as t:
        assert sorted(t.getnames())==sorted(str(p.relative_to(BASE)) for p in history)
        for p in history:assert hashlib.sha256(t.extractfile(str(p.relative_to(BASE))).read()).hexdigest()==sha(p)
else:
    with tarfile.open(archive,'w',format=tarfile.PAX_FORMAT) as t:
        for p in history:
            info=t.gettarinfo(str(p),arcname=str(p.relative_to(BASE)));info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
            with p.open('rb') as data:t.addfile(info,data)
names=['author.py','holdout-fixture.json','holdout-gold.json','author-fact-rationale.json','mechanical-validation.json','author-selfcheck.json','author-attestation.json','sealed-semantic-review.json','sealed-semantic-review-metadata.json','finalize_manifest.py','history.tar','id-only-attestation.json']
files={n:sha(BASE/n) for n in names}
manifest={'schema_version':1,'status':'HELD_NOT_RELEASED','files':files,'counts':counts,'history_archive_file_count':len(history),'review_status':'accepted','unresolved_findings':0,'mechanical_pass':True,'schema_validation':'Both unchanged public schemas validated using all keywords they contain, with standard-library structural checks.','contract_hashes':contracts,'exposure_attestation':'Platform-injected MEMORY_SUMMARY included general historical project context and aggregate prior evaluation outcomes. Actual reads limited to four pinned public contracts/schemas, own newly authored files and authorized new sealed review receipts. No product, prior datasets/gold/answers/grades/reports, runtime/helpers, user Store, retrieval algorithms, network or native model calls. Procedural independence is not a security proof.'}
for name,obj in [('manifest.json',manifest),('sealed-input-pins.json',{'schema_version':1,'status':'HELD_NOT_RELEASED','files':dict(files,**{'manifest.json':hashlib.sha256((json.dumps(manifest,indent=2,ensure_ascii=False)+'\n').encode()).hexdigest()}),'counts':counts,'history_archive_file_count':len(history)})]:
    path=BASE/name
    if path.exists():assert read(path)==obj
    else:dump(path,obj)
assert read(BASE/'sealed-input-pins.json')['files']['manifest.json']==sha(BASE/'manifest.json')
print(json.dumps({'status':'HELD_NOT_RELEASED','counts':counts,'history_archive_file_count':len(history),'files':dict(files,**{n:sha(BASE/n) for n in ['manifest.json','sealed-input-pins.json']})},indent=2))
