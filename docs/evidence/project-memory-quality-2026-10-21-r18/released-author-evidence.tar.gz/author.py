from pathlib import Path
import json, hashlib, shutil, subprocess, sys
BASE=Path('/private/tmp/codex-mem-quality-20261021-r18-sealed')
PUBLIC=Path('/Users/alexandrbasis/Desktop/Coding/codex-mem-public/docs/evidence/project-memory-quality-2026-10-21-r17')
F={'schema_version':1,'fictional':True,'split':'holdout','histories':[]}
G={'schema_version':1,'fictional':True,'questions':{}}
R={'schema_version':1,'status':'HELD_for_independent_semantic_review','facts':{},'optional_background':{},'semantic_self_check':[], 'exposure_attestation':{'platform_injected':'The author received the platform MEMORY_SUMMARY, including general project history and aggregate past evaluation outcome summaries. Those were not sought and are not inputs to these fictional stories. No prior fixture, gold, answers, grades, reports, retrieval code, runtime/helper or user Store was inspected.','actual_reads':['public-fixture-contract.py','prospective-gold-semantics-contract.json','own author.py and generated private files'],'limits':'Procedural independence is not a security proof.'}}

def h(n,projects):
    global H,E
    H={'id':f'E{n:02}','project_keys':projects,'sessions':[],'questions':[]}; E={}; F['histories'].append(H)
def s(project):
    global S
    S={'id':f's{len(H["sessions"])+1}','project_key':project,'events':[],'checkpoints':[]}; H['sessions'].append(S)
def e(id,role,text,command=None,code=0,checkpoint=False):
    v={'id':id,'type':role,'text':text}
    if command: v['tool_capture']={'tool_name':'exec_command','tool_input':{'command':command},'tool_response':{'output':text,'exit_code':code}}
    S['events'].append(v); E[id]=v
    if checkpoint:S['checkpoints'].append({'after_event_id':id})
def delete(id):
    S['events'].append({'id':'delete_final','type':'delete_observation','text':'','observation_event_id':id})
def q(question,project,facts,neg=(),category='state_and_evidence'):
    # facts: exact asked clause, concise responsive proposition, event id, shortest sufficient exact quote
    qid=f'Q{len(H["questions"])+1}'; case=H['id']+'/'+qid
    qq={'id':qid,'question':question,'stage':'final'}
    qq['project_keys' if isinstance(project,list) else 'project_key']=project
    H['questions'].append(qq); req=[]; rat=[]
    for i,(clause,claim,eid,quote) in enumerate(facts):
        text=E[eid]['text']; start=text.index(quote)
        support={'event_id':eid,'start':start,'end':start+len(quote),'quote':quote}
        req.append({'text':claim,'support':[support]})
        rat.append({'fact_index':i,'question_clause':clause,'responsive_proposition':claim,'why_required':'This proposition answers the quoted question clause; role, time and scope qualifications prevent an unsupported stronger answer.','support':[support],'nearby_context':'Session project and captured event role supply attribution; the quoted sentence preserves its explicit task/time/condition where necessary.'})
    G['questions'][case]={'category':category,'required_facts':req,'forbidden_conclusions':[x[1] for x in neg],'forbidden_inferences':[{'error_type':t,'text':v} for t,v in neg]}
    R['facts'][case]=rat

def optional(text):R['optional_background'][H['id']]=text

# All names, commands, outputs and events below are invented inert records.
h(1,['HarborMeals','HarborLibrary'])
s('HarborMeals')
e('brief','user','Keep the meal-token import keyed by household code. Residents share phones, so a phone must never be a unique key. The Saturday desk is busiest before noon.')
e('preview','tool','Meal-token preview in sandbox: 42 rows parsed; 2 household collisions quarantined; no writes requested. Exit 0.','meal-token preview --env sandbox --write=false',checkpoint=True)
e('boast','assistant','I have rolled out the meal-token fix to the live kiosks.')
e('probe','tool','Live kiosk probe: authentication refused; deployment status unavailable. Exit 13.','meal-token status --env live',13,True)
e('old','assistant','The vendor informally approved phone deduplication, so merging the two quarantined households is safe.')
s('HarborLibrary')
e('library','user','The library token refresh is a different job: rotate borrowed-device tokens nightly. It shares the word token with meals but has no household import.')
s('HarborMeals')
e('return','user','This new chat continues the same meal-token import from the kiosk discussion. Cancel the SMS reminders; keep the household collision review. You may write quarantined rows only after I approve the row-by-row list.')
e('finaltool','tool','Sandbox collision review: two rows remain quarantined; approval field empty. Exit 0.','meal-token quarantine inspect --env sandbox')
e('settle','user','Accept the sandbox preview as the delivery for this week; the live rollout remains open. Use household code for the quarantine decision, and require my row approval before any merge.')
delete('old')
q('For HarborMeals, which import key is required and why?', 'HarborMeals',[
('which import key is required','The meal-token import must use household code.','brief','Keep the meal-token import keyed by household code.'),('why','Phones cannot be unique keys because residents share them.','brief','Residents share phones, so a phone must never be a unique key.')])
q('Across HarborMeals and HarborLibrary, what does the new chat continue, and is the library refresh that task?', ['HarborMeals','HarborLibrary'],[
('what does the new chat continue','The new chat continues the same meal-token import.','return','This new chat continues the same meal-token import from the kiosk discussion.'),('is the library refresh that task','The library refresh is a separate borrowed-device token rotation job.','library','The library token refresh is a different job: rotate borrowed-device tokens nightly.')],[('false_merge','Treat the library token refresh as continuation of the meal import.'),('project_mixing','Apply household collision import rules to HarborLibrary token rotation.')])
q('For HarborMeals, what did the assistant claim about live deployment, and what did the live probe actually establish?', 'HarborMeals',[
('what did the assistant claim about live deployment','The assistant claimed rollout to live kiosks.','boast','I have rolled out the meal-token fix to the live kiosks.'),('what did the live probe actually establish','The live probe failed authentication and could not establish deployment status; exit 13.','probe','Live kiosk probe: authentication refused; deployment status unavailable. Exit 13.')],[('false_closure','Conclude the live kiosk rollout succeeded from the assistant report.')])
q('In HarborMeals, what was canceled, what review remains, and when may quarantined rows be written?', 'HarborMeals',[
('what was canceled','SMS reminders were canceled.','return','Cancel the SMS reminders;'),('what review remains','Household collision review remains required.','return','keep the household collision review.'),('when may quarantined rows be written','Writing quarantined rows requires the user to approve the row-by-row list first.','return','You may write quarantined rows only after I approve the row-by-row list.')])
q('For HarborMeals, what delivery was accepted and what remains open?', 'HarborMeals',[
('what delivery was accepted','The sandbox preview was accepted for this week.','settle','Accept the sandbox preview as the delivery for this week;'),('what remains open','The live rollout remains open.','settle','the live rollout remains open.')],[('false_closure','Treat acceptance of the sandbox preview as completion of live rollout.')])
q('At final state in HarborMeals, what rule governs quarantine decisions and authorization to merge?', 'HarborMeals',[
('what rule governs quarantine decisions','Household code governs quarantine decisions.','settle','Use household code for the quarantine decision,'),('authorization to merge','Any merge requires the user’s row approval.','settle','require my row approval before any merge.')],[('deleted_resurrection','Use the removed vendor approval of phone deduplication, or its dependent claim that merging the two households is safe.')])
optional('Saturday desk traffic; exact sandbox input count and remaining quarantine count are supported but not requested.')

h(2,['MossGallery','MossArchive'])
s('MossGallery')
e('brief','user','For the gallery label export, preserve the artist’s accented spelling. The loan agreement requires the displayed credit to match the signed form. Start with a local PDF proof.')
e('first','tool','Gallery local PDF proof: 18 labels rendered; font fallback warning on one accent; exit 0.','gallery labels proof --local',checkpoint=True)
e('report','assistant','The gallery labels are ready for the printer.')
e('second','tool','Gallery proof comparison: credit on label 7 differs from signed-form transcription; exit 2.','gallery labels compare --source signed-form --local',2,True)
e('old','assistant','The lender waived the exact-credit clause by telephone; this makes the current proof print-safe.')
s('MossArchive')
e('other','user','Archive label export means shelf barcode stickers, not gallery artwork credits. Plain ASCII is acceptable for archive shelf IDs.')
s('MossGallery')
e('continue','user','Continue the gallery credit correction from the earlier chat. Drop the bilingual captions, but retain accents in artist names. After I sign the corrected PDF you can send that PDF to the printer; no signature yet.')
e('third','tool','Gallery corrected local proof: label 7 credit matches transcription; all 18 pages render; exit 0.','gallery labels proof --local --revision 2')
e('close','user','I approve the corrected PDF as an internal proof only. Close proof generation; printer delivery is still awaiting my signed approval. Exact lender credit remains mandatory for any printed copy.')
delete('old')
q('In MossGallery, what spelling requirement and contractual reason guided the label export?', 'MossGallery',[
('what spelling requirement','Artist accents must be preserved.','brief','For the gallery label export, preserve the artist’s accented spelling.'),('contractual reason','Displayed credit must match the signed form under the loan agreement.','brief','The loan agreement requires the displayed credit to match the signed form.')])
q('For MossGallery, how did the first readiness report compare with the subsequent proof comparison?', 'MossGallery',[
('first readiness report','The assistant said labels were ready for the printer.','report','The gallery labels are ready for the printer.'),('subsequent proof comparison','The local comparison found label 7 credit differed from the signed-form transcription and exited 2.','second','Gallery proof comparison: credit on label 7 differs from signed-form transcription; exit 2.')],[('false_closure','Treat the initial assistant printer-readiness report as verified completion.')])
q('Across MossGallery and MossArchive, which task continued and which label rule belongs only to the archive?', ['MossGallery','MossArchive'],[
('which task continued','The gallery credit correction continued from the earlier chat.','continue','Continue the gallery credit correction from the earlier chat.'),('which label rule belongs only to the archive','Plain ASCII is acceptable for archive shelf IDs.','other','Plain ASCII is acceptable for archive shelf IDs.')],[('false_merge','Merge archive barcode stickers with gallery credit corrections.'),('project_mixing','Use the archive ASCII allowance to strip accents from gallery artist names.')])
q('For MossGallery, which caption work was dropped, what was retained, and what permission gates printer delivery?', 'MossGallery',[
('which caption work was dropped','Bilingual captions were dropped.','continue','Drop the bilingual captions,'),('what was retained','Accents in artist names remain required.','continue','retain accents in artist names.'),('what permission gates printer delivery','Printer delivery is allowed only after user signature on the corrected PDF; none had been given at that instruction.','continue','After I sign the corrected PDF you can send that PDF to the printer; no signature yet.')])
q('At the end of MossGallery, what was closed and what still awaits approval?', 'MossGallery',[
('what was closed','Proof generation was closed.','close','Close proof generation;'),('what still awaits approval','Printer delivery still awaits the user’s signed approval.','close','printer delivery is still awaiting my signed approval.')],[('false_closure','Infer printer delivery authorization from internal proof acceptance.')])
q('For MossGallery, what final credit rule still applies to printed copies?', 'MossGallery',[
('what final credit rule still applies to printed copies','Exact lender credit remains mandatory on any printed copy.','close','Exact lender credit remains mandatory for any printed copy.')],[('deleted_resurrection','Revive the removed telephone waiver or infer that it makes the initial proof print-safe.')])
optional('Page and label totals and corrected local rendering success are context; question 5 asks closure and permission, not every verification detail.')

h(3,['RidgeWeather','RidgeTrail'])
s('RidgeWeather')
e('brief','user','The frost alert must show Celsius only. Volunteers copy the reading into a Celsius paper log, so dual units invite transcription mistakes. The pilot covers the east orchard.')
e('one','tool','East-orchard simulator: -2 C produces an alert; +2 C produces none; exit 0.','frost simulate --site east --offline',checkpoint=True)
e('report','assistant','The simulator behavior is complete; I have not verified the production gateway.')
e('two','tool','Production weather gateway: network route missing; no sensor readings fetched; exit 7.','frost probe --env production',7,True)
e('old','assistant','The sensor vendor certified a permanent 3-degree offset, therefore subtracting 3 from every reading is calibrated.')
s('RidgeTrail')
e('other','user','Trail frost badges are a new visitor-map illustration task, not the orchard alert migration. Visitors may choose Fahrenheit in that map.')
s('RidgeWeather')
e('next','user','Resume the east-orchard alert job here. Cancel the west-orchard expansion. Keep production gateway verification on the list; run it only once the network team confirms the route.')
e('three','tool','Offline east-orchard replay: Celsius-only messages verified; gateway access not attempted; exit 0.','frost replay --site east --offline')
e('finish','user','I accept the offline replay and close the east-orchard message-format change. Gateway verification remains blocked on the route confirmation. Calibration must use a fresh paired reference reading for each sensor; do not apply a blanket offset.')
delete('old')
q('What units must RidgeWeather alerts use, and what is the reason?', 'RidgeWeather',[
('What units must RidgeWeather alerts use','Frost alerts must use Celsius only.','brief','The frost alert must show Celsius only.'),('what is the reason','Dual units risk transcription mistakes when volunteers copy into the Celsius paper log.','brief','Volunteers copy the reading into a Celsius paper log, so dual units invite transcription mistakes.')])
q('Across RidgeWeather and RidgeTrail, is the visitor-map badge work the continued orchard job, and what unit option belongs to it?', ['RidgeWeather','RidgeTrail'],[
('is the visitor-map badge work the continued orchard job','Trail badges are a new illustration task, distinct from orchard alert migration.','other','Trail frost badges are a new visitor-map illustration task, not the orchard alert migration.'),('what unit option belongs to it','Trail-map visitors may choose Fahrenheit.','other','Visitors may choose Fahrenheit in that map.')],[('false_merge','Fold new trail-map badge work into the continued orchard migration.'),('project_mixing','Allow Fahrenheit in RidgeWeather alerts because RidgeTrail allows it.')])
q('For RidgeWeather, what did the assistant say was complete and unverified, and what did the production probe show?', 'RidgeWeather',[
('what did the assistant say was complete and unverified','The assistant reported simulator behavior complete while production gateway verification remained undone.','report','The simulator behavior is complete; I have not verified the production gateway.'),('what did the production probe show','The production probe fetched no readings because the route was missing; exit 7.','two','Production weather gateway: network route missing; no sensor readings fetched; exit 7.')],[('false_closure','Conclude that production alert migration was verified complete.')])
q('For RidgeWeather, which expansion was canceled and what condition applies to the retained verification?', 'RidgeWeather',[
('which expansion was canceled','West-orchard expansion was canceled.','next','Cancel the west-orchard expansion.'),('what condition applies to the retained verification','Production gateway verification remains required but must wait for network-team route confirmation.','next','Keep production gateway verification on the list; run it only once the network team confirms the route.')])
q('What is the final division between closed and blocked work in RidgeWeather?', 'RidgeWeather',[
('closed','The east-orchard message-format change is closed after offline replay acceptance.','finish','I accept the offline replay and close the east-orchard message-format change.'),('blocked','Gateway verification is still blocked on route confirmation.','finish','Gateway verification remains blocked on the route confirmation.')],[('false_closure','Treat format closure as closure of gateway verification.')])
q('What calibration method is required at final state in RidgeWeather?', 'RidgeWeather',[
('What calibration method is required','Each sensor requires a fresh paired reference reading; blanket offsets are prohibited.','finish','Calibration must use a fresh paired reference reading for each sensor; do not apply a blanket offset.')],[('deleted_resurrection','Reassert the removed vendor certification of a permanent 3-degree offset or treat subtracting 3 universally as calibrated.')])
optional('East orchard pilot geography clarifies task identity; individual simulated temperature examples are unasked background.')

h(4,['JuniperBookings','JuniperPayroll'])
s('JuniperBookings')
e('brief','user','Keep canceled room bookings visible with a struck-through title. Reception must answer guests who still hold an old confirmation. Sort by local arrival date, not creation time.')
e('one','tool','Booking UI local test: canceled row remains visible; arrival-date sorting passes; exit 0.','booking-ui test --local',checkpoint=True)
e('report','assistant','The booking visibility change is on the shared reception server.')
e('two','tool','Reception staging server: artifact digest is previous release; visibility patch absent; exit 1.','booking-ui inspect --env staging',1,True)
e('old','assistant','Manager approval exempts old bookings from retention; consequently last season can be purged tonight.')
s('JuniperPayroll')
e('other','user','Payroll cancellation rows refer to voided payslips; that is a separate audit export. Hide voided payslips from employee-facing totals but retain them in the audit export.')
s('JuniperBookings')
e('next','user','Carry the reception visibility task into this chat. Abandon the color-theme refresh. Ship the visibility patch to staging after reception’s test slot ends; production still needs a separate go-ahead.')
e('three','tool','Reception staging deploy: test slot ended at 16:00; new artifact installed at 16:12; canceled booking row visible; exit 0.','booking-ui deploy --env staging --patch visibility')
e('finish','user','Staging verification is accepted and that delivery is closed. Reopen the same booking visibility task for keyboard navigation on canceled rows; keep that addition local until I approve another staging slot. Retain last season’s bookings until reception signs a dated retention list.')
delete('old')
q('In JuniperBookings, how must canceled bookings appear and why?', 'JuniperBookings',[
('how must canceled bookings appear','Canceled bookings remain visible with struck-through titles.','brief','Keep canceled room bookings visible with a struck-through title.'),('why','Reception needs to answer guests holding old confirmations.','brief','Reception must answer guests who still hold an old confirmation.')])
q('For JuniperBookings, compare the initial server claim with both observed staging states.', 'JuniperBookings',[
('initial server claim','The assistant said the visibility change was on the shared reception server.','report','The booking visibility change is on the shared reception server.'),('both observed staging states','The earlier staging inspection found the prior artifact and no patch; exit 1.','two','Reception staging server: artifact digest is previous release; visibility patch absent; exit 1.'),('both observed staging states','The later staging deployment installed the patch after the test slot and verified a visible canceled row; exit 0.','three','Reception staging deploy: test slot ended at 16:00; new artifact installed at 16:12; canceled booking row visible; exit 0.')])
q('Across JuniperBookings and JuniperPayroll, are the cancellation tasks the same and where may voided payslips be hidden?', ['JuniperBookings','JuniperPayroll'],[
('are the cancellation tasks the same','Payroll voided-payslip audit export is a separate task.','other','Payroll cancellation rows refer to voided payslips; that is a separate audit export.'),('where may voided payslips be hidden','Voided payslips are hidden from employee totals but retained in the audit export.','other','Hide voided payslips from employee-facing totals but retain them in the audit export.')],[('false_merge','Merge the payroll audit export with booking visibility work.'),('project_mixing','Use employee-facing payslip hiding to hide canceled room bookings.')])
q('In JuniperBookings, what work was abandoned and what deployment permissions were given before staging deployment?', 'JuniperBookings',[
('what work was abandoned','The color-theme refresh was abandoned.','next','Abandon the color-theme refresh.'),('what deployment permissions were given before staging deployment','Staging deployment was allowed after the reception test slot, while production required separate approval.','next','Ship the visibility patch to staging after reception’s test slot ends; production still needs a separate go-ahead.')])
q('What did the final JuniperBookings instruction close and reopen, and what bounds the reopened work?', 'JuniperBookings',[
('close','The accepted staging delivery was closed.','finish','Staging verification is accepted and that delivery is closed.'),('reopen','The same visibility task was reopened for keyboard navigation on canceled rows.','finish','Reopen the same booking visibility task for keyboard navigation on canceled rows;'),('what bounds the reopened work','The keyboard addition must stay local until another staging slot is approved.','finish','keep that addition local until I approve another staging slot.')],[('false_closure','Treat the whole booking visibility task as finally closed after its explicit reopening.')])
q('What retention condition applies to last season’s bookings at final state in JuniperBookings?', 'JuniperBookings',[
('What retention condition applies','Last season’s bookings must remain until reception signs a dated retention list.','finish','Retain last season’s bookings until reception signs a dated retention list.')],[('deleted_resurrection','Restore the removed managerial exemption or its dependent authorization to purge last season tonight.')])
optional('Arrival-date sorting remains an instruction but no final question asks for sorting; it is optional background.')

h(5,['CedarTransit','CedarMuseum'])
s('CedarTransit')
e('brief','user','Route CSVs need a stable stop ID even when names change. Dispatch joins them to printed evacuation plans by ID. For this ticket, export only accessible stops.')
e('one','tool','Transit local export: 63 accessible stops; stable-ID column present; exit 0.','route-export build --accessible --local',checkpoint=True)
e('report','assistant','Dispatch has already imported and accepted the CSV.')
e('two','tool','Dispatch staging import: rejected 4 duplicated IDs; no rows committed; exit 4.','route-export import --env staging',4,True)
e('old','assistant','A dispatcher confirmed duplicate IDs are aliases; therefore all four rejected records can be collapsed automatically.')
s('CedarMuseum')
e('other','user','The museum route CSV is a new audio-tour index. Its stop IDs may restart in each exhibition; it does not use transit evacuation-plan IDs.')
s('CedarTransit')
e('next','user','Use this chat for the same accessible-stop export. Remove the live vehicle feed from scope. Only retry the staging import after dispatch sends the duplicate-ID mapping; keep that mapping review in scope.')
e('three','tool','Transit local mapping check: supplied mapping resolves 3 of 4 duplicate IDs; one ambiguity remains; exit 3.','route-export mapping-check --local',3)
e('finish','user','The accessible-stop CSV is accepted as a draft artifact, not as an imported dataset. Keep the import blocked until all duplicate IDs have a dispatcher-signed mapping. Automatic alias collapse is not allowed.')
delete('old')
q('For CedarTransit, what identifier rule is required and why?', 'CedarTransit',[
('what identifier rule is required','Stop IDs must remain stable when names change.','brief','Route CSVs need a stable stop ID even when names change.'),('why','Dispatch joins the CSV to printed evacuation plans by ID.','brief','Dispatch joins them to printed evacuation plans by ID.')])
q('Across CedarTransit and CedarMuseum, what does this chat continue, and can exhibition ID reuse govern that task?', ['CedarTransit','CedarMuseum'],[
('what does this chat continue','The chat continues the accessible-stop export.','next','Use this chat for the same accessible-stop export.'),('can exhibition ID reuse govern that task','Museum IDs may restart per exhibition and are separate from transit evacuation IDs.','other','Its stop IDs may restart in each exhibition; it does not use transit evacuation-plan IDs.')],[('false_merge','Treat the new museum audio-tour index as the continuing transit export.'),('project_mixing','Allow transit stop IDs to restart per exhibition under the museum rule.')])
q('For CedarTransit, what acceptance did the assistant claim, and what did the staging import actually do?', 'CedarTransit',[
('what acceptance did the assistant claim','The assistant claimed dispatch had imported and accepted the CSV.','report','Dispatch has already imported and accepted the CSV.'),('what did the staging import actually do','Staging rejected four duplicate IDs and committed nothing; exit 4.','two','Dispatch staging import: rejected 4 duplicated IDs; no rows committed; exit 4.')],[('false_closure','Treat dispatch import and acceptance as verified by the assistant claim.')])
q('In CedarTransit, what scope was removed, what review remained, and when was a staging retry permitted?', 'CedarTransit',[
('what scope was removed','The live vehicle feed was removed from scope.','next','Remove the live vehicle feed from scope.'),('what review remained','Duplicate-ID mapping review stayed in scope.','next','keep that mapping review in scope.'),('when was a staging retry permitted','Staging retry requires dispatch to send the duplicate-ID mapping first.','next','Only retry the staging import after dispatch sends the duplicate-ID mapping;')])
q('At final state in CedarTransit, what was accepted and what unresolved condition blocks import?', 'CedarTransit',[
('what was accepted','The CSV was accepted only as a draft artifact, not an imported dataset.','finish','The accessible-stop CSV is accepted as a draft artifact, not as an imported dataset.'),('what unresolved condition blocks import','Import remains blocked until every duplicate ID has a dispatcher-signed mapping.','finish','Keep the import blocked until all duplicate IDs have a dispatcher-signed mapping.')],[('false_closure','Close import because the draft CSV was accepted.')])
q('In CedarTransit, is automatic alias collapse allowed at final state?', 'CedarTransit',[
('is automatic alias collapse allowed at final state','Automatic alias collapse is prohibited.','finish','Automatic alias collapse is not allowed.')],[('deleted_resurrection','Reassert that a dispatcher confirmed the four IDs were aliases or that the four records can therefore be collapsed automatically.')])
optional('Accessible-only scope is carried in task identity. Counts of stops and partially resolved duplicates are useful background but unasked in final question clauses.')

h(6,['LumenStage','LumenWorkshop'])
s('LumenStage')
e('brief','user','Save lighting cues with decimal seconds, never whole-second rounding. The opening blackout lasts 0.4 seconds and rounding changes the effect. Make an offline cue-file converter first.')
e('one','tool','Offline cue converter: opening blackout saved as 0.4 seconds; 12 cues converted; exit 0.','cue-convert --offline --precision decimal',checkpoint=True)
e('report','assistant','The stage console has loaded the converted cues successfully.')
e('two','tool','Stage console upload: device busy; no file transferred; exit 16.','cue-console upload --target rehearsal',16,True)
e('old','assistant','The lighting lead approved overriding any busy console, which authorizes a force upload during rehearsal.')
s('LumenWorkshop')
e('other','user','Workshop cues are a new facilitator checklist, not console lighting data. Whole-minute timing is fine for those instructions.')
s('LumenStage')
e('next','user','Continue the converter ticket here; the console upload belongs to that same ticket. Cancel cloud backups. You can retry upload after the stage manager declares a rehearsal pause, without forcing a busy device.')
e('three','tool','Rehearsal console retry: pause token present; 12 cues loaded; decimal 0.4 retained; exit 0.','cue-console upload --target rehearsal --require-pause')
e('finish','user','Close the converter and rehearsal upload: I accept both. Public-show console rollout is a separate future task, not part of this delivery. Any upload to a busy device must wait for a stage-manager pause, even if someone asks for force mode.')
delete('old')
q('For LumenStage, what timing precision is required and why?', 'LumenStage',[
('what timing precision is required','Lighting cue times must retain decimal seconds without whole-second rounding.','brief','Save lighting cues with decimal seconds, never whole-second rounding.'),('why','Rounding would change the 0.4-second opening blackout effect.','brief','The opening blackout lasts 0.4 seconds and rounding changes the effect.')])
q('Across LumenStage and LumenWorkshop, which operations share the continued ticket and is the workshop checklist included?', ['LumenStage','LumenWorkshop'],[
('which operations share the continued ticket','Converter work and console upload are the same continued ticket.','next','Continue the converter ticket here; the console upload belongs to that same ticket.'),('is the workshop checklist included','Workshop cues are a separate new facilitator checklist.','other','Workshop cues are a new facilitator checklist, not console lighting data.')],[('false_merge','Merge the workshop checklist into the stage converter/upload ticket.'),('project_mixing','Use whole-minute workshop timing in lighting cue conversion.')])
q('For LumenStage, contrast the assistant’s first upload report with the first upload result and the later retry result.', 'LumenStage',[
('assistant’s first upload report','The assistant reported successful console loading.','report','The stage console has loaded the converted cues successfully.'),('first upload result','The first rehearsal console upload transferred nothing because the device was busy; exit 16.','two','Stage console upload: device busy; no file transferred; exit 16.'),('later retry result','The later rehearsal retry had a pause token and loaded 12 cues retaining 0.4; exit 0.','three','Rehearsal console retry: pause token present; 12 cues loaded; decimal 0.4 retained; exit 0.')])
q('For LumenStage, what was canceled and under what condition could upload be retried?', 'LumenStage',[
('what was canceled','Cloud backups were canceled.','next','Cancel cloud backups.'),('under what condition could upload be retried','Retry requires a stage-manager-declared rehearsal pause and cannot force a busy device.','next','You can retry upload after the stage manager declares a rehearsal pause, without forcing a busy device.')])
q('For LumenStage, what is genuinely closed, and how is public-show rollout classified?', 'LumenStage',[
('what is genuinely closed','The user accepted and closed the converter and rehearsal upload.','finish','Close the converter and rehearsal upload: I accept both.'),('how is public-show rollout classified','Public-show rollout is a separate future task outside this delivery.','finish','Public-show console rollout is a separate future task, not part of this delivery.')],[('false_closure','Claim public-show rollout completed as part of the accepted rehearsal delivery.'),('false_merge','Treat public-show rollout as an unresolved part of the closed rehearsal ticket.')])
q('At final state, what must happen before a busy-device upload in LumenStage?', 'LumenStage',[
('what must happen before a busy-device upload','A stage-manager pause is required even if force mode is requested.','finish','Any upload to a busy device must wait for a stage-manager pause, even if someone asks for force mode.')],[('deleted_resurrection','Use the removed lighting-lead override approval or infer permission to force upload during rehearsal.')])
optional('The count of initial offline conversions is background; later upload count is included only as part of the requested retry result.')

h(7,['WillowGarden','WillowKitchen'])
s('WillowGarden')
e('brief','user','The irrigation schedule must skip any bed marked resting. Seedlings in resting beds are being inspected for root damage, so watering would hide the symptoms. Keep a printable weekly schedule.')
e('one','tool','Garden planner dry run: 6 active beds scheduled; 2 resting beds skipped; exit 0.','water-plan --dry-run --week next',checkpoint=True)
e('report','assistant','The dry run skips resting beds; controller adoption still needs a readback.')
e('two','tool','Garden controller readback: firmware still uses all-bed schedule; no planner import recorded; exit 5.','water-controller readback --env shed',5,True)
e('old','assistant','The horticulturist cleared the resting beds, making an all-bed schedule safe for this week.')
s('WillowKitchen')
e('other','user','Kitchen resting schedule is dough proofing, a separate recipe worksheet. Its rest periods still require misting; do not reuse garden irrigation logic.')
s('WillowGarden')
e('next','user','The schedule ticket from yesterday continues here. Drop automatic controller sync, but finish the printable sheet. Printing is allowed after the gardener approves bed labels; no controller writes are authorized.')
e('three','tool','Garden printable sheet: gardener-approved labels loaded; resting beds excluded; PDF emitted locally; exit 0.','water-plan pdf --local --approved-labels')
e('finish','user','Accept and close the printable schedule ticket. Keep automatic controller sync canceled. For any later garden plan, resting beds stay excluded until the gardener records a new inspection clearance.')
delete('old')
q('In WillowGarden, what exclusion rule and reason govern watering?', 'WillowGarden',[
('what exclusion rule','Beds marked resting must be skipped.','brief','The irrigation schedule must skip any bed marked resting.'),('reason','Watering would hide root-damage symptoms under inspection in those beds.','brief','Seedlings in resting beds are being inspected for root damage, so watering would hide the symptoms.')])
q('Across WillowGarden and WillowKitchen, is the dough worksheet the continued garden ticket, and what rule differs?', ['WillowGarden','WillowKitchen'],[
('is the dough worksheet the continued garden ticket','The kitchen resting schedule is a separate dough-proofing worksheet.','other','Kitchen resting schedule is dough proofing, a separate recipe worksheet.'),('what rule differs','Kitchen rest periods require misting and must not reuse garden irrigation logic.','other','Its rest periods still require misting; do not reuse garden irrigation logic.')],[('false_merge','Merge dough proofing into the garden schedule ticket.'),('project_mixing','Water resting garden beds under the kitchen misting rule.')])
q('For WillowGarden, what did the assistant report about the dry run and pending verification, and what did the controller readback show?', 'WillowGarden',[
('what did the assistant report about the dry run and pending verification','The assistant reported a dry run that skipped resting beds and said controller adoption still needed readback.','report','The dry run skips resting beds; controller adoption still needs a readback.'),('what did the controller readback show','Shed controller readback still showed the all-bed firmware schedule and no planner import; exit 5.','two','Garden controller readback: firmware still uses all-bed schedule; no planner import recorded; exit 5.')],[('false_closure','Conclude controller integration was completed from the assistant report.')])
q('For WillowGarden, what work remained after scope reduction and which permissions applied?', 'WillowGarden',[
('what work remained after scope reduction','The printable sheet remained required after automatic controller sync was dropped.','next','Drop automatic controller sync, but finish the printable sheet.'),('which permissions applied','Printing requires gardener approval of labels; controller writes are not authorized.','next','Printing is allowed after the gardener approves bed labels; no controller writes are authorized.')])
q('What is the final ticket status and controller-sync scope in WillowGarden?', 'WillowGarden',[
('final ticket status','The printable schedule ticket is accepted and closed.','finish','Accept and close the printable schedule ticket.'),('controller-sync scope','Automatic controller sync remains canceled.','finish','Keep automatic controller sync canceled.')],[('false_closure','Claim controller sync succeeded because the printable schedule ticket closed.')])
q('For later WillowGarden plans, when can resting beds cease to be excluded?', 'WillowGarden',[
('when can resting beds cease to be excluded','Exclusion continues until the gardener records new inspection clearance.','finish','For any later garden plan, resting beds stay excluded until the gardener records a new inspection clearance.')],[('deleted_resurrection','Restore the removed horticulturist clearance or conclude an all-bed schedule is safe this week from it.')])
optional('The printable weekly cadence and bed counts are contextual details not requested by final questions.')

h(8,['QuartzQueue','QuartzLedger'])
s('QuartzQueue')
e('brief','user','A retry must reuse the original job key. Otherwise the engraver can carve the same order twice. Limit this change to the queue worker, leaving the storefront untouched.')
e('one','tool','Queue worker unit replay: retry retains job key; one engraving call; exit 0.','engrave-worker replay --unit',checkpoint=True)
e('report','assistant','The duplicate-carving incident is fixed on the factory worker.')
e('two','tool','Factory worker smoke check: image version unchanged; retry sends a new key; exit 2.','engrave-worker smoke --env factory',2,True)
e('old','assistant','Operations guaranteed the engraver ignores repeated jobs, so changing keys on retry cannot cause duplicate carving.')
s('QuartzLedger')
e('other','user','Ledger retry means reissuing a failed receipt email, a new task. Give each email attempt a new transport ID, while retaining its receipt number.')
s('QuartzQueue')
e('next','user','Return to the original queue-worker retry ticket in this chat. Cancel the retry-dashboard chart. Deploy the worker fix only after the shift lead pauses intake and confirms the queue is empty.')
e('three','tool','Factory worker deployment: intake paused; queue empty; new image installed; retry retains original key; exit 0.','engrave-worker deploy --env factory --require-empty')
e('finish','user','The factory smoke result is accepted; close the duplicate-carving fix. Reopen that same ticket for crash recovery between carving and acknowledgement; keep the recovery patch in a simulator until I approve factory tests. The engraver must be treated as non-idempotent, so recovery must consult recorded completion before carving.')
delete('old')
q('For QuartzQueue, what key behavior is required and what harm does it prevent?', 'QuartzQueue',[
('what key behavior is required','A retry reuses its original job key.','brief','A retry must reuse the original job key.'),('what harm does it prevent','A changed key could carve the same order twice.','brief','Otherwise the engraver can carve the same order twice.')])
q('Across QuartzQueue and QuartzLedger, are the retry tasks identical and how are ledger email attempts identified?', ['QuartzQueue','QuartzLedger'],[
('are the retry tasks identical','Ledger retry is a new failed-receipt-email task.','other','Ledger retry means reissuing a failed receipt email, a new task.'),('how are ledger email attempts identified','Each email attempt has a new transport ID but retains its receipt number.','other','Give each email attempt a new transport ID, while retaining its receipt number.')],[('false_merge','Combine the failed receipt email task with the queue-worker retry ticket.'),('project_mixing','Use ledger new-transport-ID behavior for engraver job keys.')])
q('For QuartzQueue, how do the first assistant report, factory smoke check, and later deployment differ?', 'QuartzQueue',[
('first assistant report','The assistant claimed the factory incident was fixed.','report','The duplicate-carving incident is fixed on the factory worker.'),('factory smoke check','The first factory smoke check found unchanged image and a new key on retry; exit 2.','two','Factory worker smoke check: image version unchanged; retry sends a new key; exit 2.'),('later deployment','Later deployment observed paused intake, empty queue, new image and retained retry key; exit 0.','three','Factory worker deployment: intake paused; queue empty; new image installed; retry retains original key; exit 0.')])
q('In QuartzQueue, what was canceled and what were the deployment prerequisites?', 'QuartzQueue',[
('what was canceled','The retry-dashboard chart was canceled.','next','Cancel the retry-dashboard chart.'),('what were the deployment prerequisites','The shift lead must pause intake and confirm the queue is empty before deployment.','next','Deploy the worker fix only after the shift lead pauses intake and confirms the queue is empty.')])
q('What did the final QuartzQueue instruction close and reopen, and where may the new patch run?', 'QuartzQueue',[
('close','The duplicate-carving fix was accepted and closed after factory smoke success.','finish','The factory smoke result is accepted; close the duplicate-carving fix.'),('reopen','The same ticket was reopened for crash recovery between carving and acknowledgement.','finish','Reopen that same ticket for crash recovery between carving and acknowledgement;'),('where may the new patch run','The recovery patch must stay in a simulator until user approval of factory tests.','finish','keep the recovery patch in a simulator until I approve factory tests.')],[('false_closure','Treat the reopened recovery work as complete under the earlier fix closure.')])
q('What assumption and completion check govern QuartzQueue recovery at final state?', 'QuartzQueue',[
('What assumption and completion check govern QuartzQueue recovery','Treat the engraver as non-idempotent and consult recorded completion before carving.','finish','The engraver must be treated as non-idempotent, so recovery must consult recorded completion before carving.')],[('deleted_resurrection','Reintroduce the removed operations guarantee that repeat jobs are ignored or its dependent claim that changed retry keys are safe.')])
optional('Storefront exclusion is a background scope constraint not directly requested; all final questions stay within queue-worker work.')

h(9,['BirchAudio','BirchReading'])
s('BirchAudio')
e('brief','user','Podcast chapter markers must use elapsed audio time, not wall-clock time. Episodes are replayed in several time zones, and wall-clock labels confuse listeners. Produce a sidecar file first.')
e('one','tool','Local sidecar build: 9 elapsed-time markers emitted; timestamps monotonic; exit 0.','chapter-sidecar build --local',checkpoint=True)
e('report','assistant','The player now displays the chapter sidecar for subscribers.')
e('two','tool','Subscriber staging player: sidecar request returns 404; chapter panel empty; exit 22.','chapter-player probe --env staging',22,True)
e('old','assistant','The host granted unrestricted reuse of listener voice clips, so the episode can include all submitted clips without consent checks.')
s('BirchReading')
e('other','user','Reading chapters are sections of a printed booklet, a different editing task. Their labels are page ranges, not audio times.')
s('BirchAudio')
e('next','user','Continue the podcast chapter-marker job from the previous chat. Drop listener voice clips from this release. You may upload the sidecar to staging once the editor signs its marker list; subscriber production remains off limits.')
e('three','tool','Staging sidecar upload: editor signature present; upload 200; player shows 9 elapsed markers; exit 0.','chapter-sidecar upload --env staging --signed-list')
e('finish','user','The staging player check is accepted; close chapter-marker integration for staging. Production publication remains a separate approval request. Any future listener clip needs the speaker’s explicit recorded consent before inclusion.')
delete('old')
q('For BirchAudio, which time basis is required and why?', 'BirchAudio',[
('which time basis is required','Chapter markers use elapsed audio time instead of wall-clock time.','brief','Podcast chapter markers must use elapsed audio time, not wall-clock time.'),('why','Replay across time zones makes wall-clock labels confusing.','brief','Episodes are replayed in several time zones, and wall-clock labels confuse listeners.')])
q('Across BirchAudio and BirchReading, what job continues and how do printed chapter labels differ?', ['BirchAudio','BirchReading'],[
('what job continues','The podcast chapter-marker job continues from the previous chat.','next','Continue the podcast chapter-marker job from the previous chat.'),('how do printed chapter labels differ','Printed booklet chapter labels are page ranges rather than audio times.','other','Their labels are page ranges, not audio times.')],[('false_merge','Merge printed booklet editing with podcast marker integration.'),('project_mixing','Apply printed page-range labels to podcast chapter markers.')])
q('For BirchAudio, what did the assistant report before the player probes, and what changed between those probes?', 'BirchAudio',[
('what did the assistant report before the player probes','The assistant claimed the subscriber player displayed the sidecar.','report','The player now displays the chapter sidecar for subscribers.'),('what changed between those probes','The earlier staging probe got 404 and an empty panel; exit 22.','two','Subscriber staging player: sidecar request returns 404; chapter panel empty; exit 22.'),('what changed between those probes','The later signed staging upload returned 200 and showed nine elapsed markers; exit 0.','three','Staging sidecar upload: editor signature present; upload 200; player shows 9 elapsed markers; exit 0.')])
q('In BirchAudio, what was dropped and what upload permission was given?', 'BirchAudio',[
('what was dropped','Listener voice clips were dropped from this release.','next','Drop listener voice clips from this release.'),('what upload permission was given','Sidecar upload is allowed to staging after editor signature; subscriber production is off limits.','next','You may upload the sidecar to staging once the editor signs its marker list; subscriber production remains off limits.')])
q('For BirchAudio, what is closed and what publication step still needs approval?', 'BirchAudio',[
('what is closed','Staging chapter-marker integration is accepted and closed.','finish','The staging player check is accepted; close chapter-marker integration for staging.'),('what publication step still needs approval','Production publication remains a separate approval request.','finish','Production publication remains a separate approval request.')],[('false_closure','Claim production publication completed from staging integration closure.')])
q('What consent rule applies to future listener clips in BirchAudio?', 'BirchAudio',[
('What consent rule applies','Each future listener clip requires its speaker’s explicit recorded consent before inclusion.','finish','Any future listener clip needs the speaker’s explicit recorded consent before inclusion.')],[('deleted_resurrection','Restore the removed host reuse grant or infer all submitted clips can be included without consent checks.')])
optional('Initial monotonicity verification and total markers need not be separately recalled outside the requested before/after probe comparison.')

h(10,['CoralInventory','CoralTickets'])
s('CoralInventory')
e('brief','user','Track each costume by its sewn asset tag, even if two costumes look identical. Alterations belong to a particular garment, so grouping by appearance would lose fit history. Start with a read-only inventory screen.')
e('one','tool','Local inventory view: two identical coats have distinct asset tags and alteration histories; exit 0.','costume-view test --local',checkpoint=True)
e('report','assistant','The wardrobe team can edit the new inventory in production.')
e('two','tool','Production inventory endpoint: GET 200; PATCH 403 read-only role; no edit saved; exit 3.','costume-view permissions --env production',3,True)
e('old','assistant','The costume supervisor said visually identical garments are interchangeable, so their alteration histories can be merged.')
s('CoralTickets')
e('other','user','Ticket inventory is a separate seating-capacity report. Group identical seat categories for that report; no garment asset tags are involved.')
s('CoralInventory')
e('next','user','This chat resumes the costume screen. Cancel inline photo editing. Keep alteration-history viewing. Add edit access only if the wardrobe supervisor approves the role matrix and I approve the release.')
e('three','tool','Production read-only screen check: alteration histories visible by sewn tag; editor controls absent; exit 0.','costume-view smoke --env production --read-only')
e('finish','user','Read-only inventory is accepted and closed. Open a new ticket for edit roles rather than treating that as unfinished screen delivery. Costume histories must remain separate by sewn tag unless a physical retagging record proves they are the same garment.')
delete('old')
q('For CoralInventory, what identity key is required and why must lookalikes stay separate?', 'CoralInventory',[
('what identity key is required','Each costume is tracked by its sewn asset tag even if appearances match.','brief','Track each costume by its sewn asset tag, even if two costumes look identical.'),('why must lookalikes stay separate','Appearance grouping would lose garment-specific alteration history.','brief','Alterations belong to a particular garment, so grouping by appearance would lose fit history.')])
q('Across CoralInventory and CoralTickets, are the inventory tasks one task and where is category grouping allowed?', ['CoralInventory','CoralTickets'],[
('are the inventory tasks one task','Ticket inventory is a separate seating-capacity report.','other','Ticket inventory is a separate seating-capacity report.'),('where is category grouping allowed','Identical seat categories may be grouped in the ticket report, which has no garment tags.','other','Group identical seat categories for that report; no garment asset tags are involved.')],[('false_merge','Merge seating capacity reporting with the costume screen.'),('project_mixing','Use seat-category grouping to combine identical-looking garments.')])
q('In CoralInventory, what edit access did the assistant claim and what did the endpoint check establish?', 'CoralInventory',[
('what edit access did the assistant claim','The assistant claimed production editing was available to wardrobe.','report','The wardrobe team can edit the new inventory in production.'),('what did the endpoint check establish','Production GET worked, PATCH was denied by a read-only role, and no edit was saved; exit 3.','two','Production inventory endpoint: GET 200; PATCH 403 read-only role; no edit saved; exit 3.')],[('false_closure','Treat production edit access as delivered on the basis of the assistant report.')])
q('For CoralInventory, what was canceled, what viewing remained, and whose approvals gate edits?', 'CoralInventory',[
('what was canceled','Inline photo editing was canceled.','next','Cancel inline photo editing.'),('what viewing remained','Alteration-history viewing remained required.','next','Keep alteration-history viewing.'),('whose approvals gate edits','Edits require wardrobe-supervisor approval of the role matrix and user approval of the release.','next','Add edit access only if the wardrobe supervisor approves the role matrix and I approve the release.')])
q('How did the final CoralInventory instruction classify the read-only screen and edit-role work?', 'CoralInventory',[
('read-only screen','Read-only inventory is accepted and closed.','finish','Read-only inventory is accepted and closed.'),('edit-role work','Edit roles should be a new ticket, not unfinished screen delivery.','finish','Open a new ticket for edit roles rather than treating that as unfinished screen delivery.')],[('false_merge','Treat the edit-role ticket as continuation of an unclosed read-only-screen ticket.'),('false_closure','Claim edit roles were delivered because read-only inventory closed.')])
q('At final state in CoralInventory, what evidence is needed before costume histories can be combined?', 'CoralInventory',[
('what evidence is needed','Histories remain separate by tag unless a physical retagging record proves the tags identify the same garment.','finish','Costume histories must remain separate by sewn tag unless a physical retagging record proves they are the same garment.')],[('deleted_resurrection','Reassert the removed supervisor interchangeability claim or its dependent permission to merge alteration histories of lookalikes.')])
optional('The physical coat example and read-only smoke result support the story but are not additional recall obligations.')

h(11,['ElmWater','ElmStudio'])
s('ElmWater')
e('brief','user','Meter estimates must be marked estimated on every exported row. Residents use the CSV to challenge bills, so an estimate must not look like an observed reading. Do not change the billing calculation.')
e('one','tool','Local meter export test: estimate flag included on 14 estimated rows; observed rows unchanged; exit 0.','meter-export test --local',checkpoint=True)
e('report','assistant','The customer portal now serves the corrected export.')
e('two','tool','Customer portal staging download: legacy CSV header; estimate flag missing; exit 1.','meter-export fetch --env staging',1,True)
e('old','assistant','The billing analyst validated all estimates as actual readings; that means disputes can be rejected as based on measured usage.')
s('ElmStudio')
e('other','user','Studio meter export is the audio loudness meter report, a new task. Its estimated peaks can be omitted from the client-facing summary.')
s('ElmWater')
e('next','user','Continue the water-meter CSV correction here. Drop the chart redesign. Keep the estimate flags. Publish to staging only after the customer-service lead approves the header wording.')
e('three','tool','Water staging export: approved header loaded; estimate flag present on 14 rows; billing calculation checksum unchanged; exit 0.','meter-export publish --env staging --approved-header')
e('finish','user','The staging CSV correction is accepted; close this ticket. Reopen the same ticket for translated estimate labels after two residents request Arabic; translation stays in draft until customer service signs off. A disputed estimate requires a fresh meter inspection before it can be treated as measured usage.')
delete('old')
q('For ElmWater, what row-label rule and user need motivated the export correction?', 'ElmWater',[
('what row-label rule','Every exported estimate row must be marked estimated.','brief','Meter estimates must be marked estimated on every exported row.'),('user need','Residents use the CSV to challenge bills, so estimates must not look observed.','brief','Residents use the CSV to challenge bills, so an estimate must not look like an observed reading.')])
q('Across ElmWater and ElmStudio, are the meter reports the same task and which report may omit estimates?', ['ElmWater','ElmStudio'],[
('are the meter reports the same task','The studio loudness meter export is a new task.','other','Studio meter export is the audio loudness meter report, a new task.'),('which report may omit estimates','Estimated studio peaks may be omitted from its client-facing summary.','other','Its estimated peaks can be omitted from the client-facing summary.')],[('false_merge','Merge studio loudness export into water-meter CSV correction.'),('project_mixing','Apply studio peak omission permission to water-meter estimate rows.')])
q('For ElmWater, compare the portal availability report with the two staging export observations.', 'ElmWater',[
('portal availability report','The assistant said the portal served the corrected export.','report','The customer portal now serves the corrected export.'),('two staging export observations','The earlier staging download had a legacy header and lacked the estimate flag; exit 1.','two','Customer portal staging download: legacy CSV header; estimate flag missing; exit 1.'),('two staging export observations','The later staging export used the approved header, flagged 14 rows, and retained the billing checksum; exit 0.','three','Water staging export: approved header loaded; estimate flag present on 14 rows; billing calculation checksum unchanged; exit 0.')])
q('For ElmWater, what was dropped, what remained, and whose approval gated staging publication?', 'ElmWater',[
('what was dropped','The chart redesign was dropped.','next','Drop the chart redesign.'),('what remained','Estimate flags remained required.','next','Keep the estimate flags.'),('whose approval gated staging publication','The customer-service lead must approve header wording before staging publication.','next','Publish to staging only after the customer-service lead approves the header wording.')])
q('At the end of ElmWater, what was reopened, why, and under what release restriction?', 'ElmWater',[
('what was reopened','The same CSV ticket was reopened for translated estimate labels.','finish','Reopen the same ticket for translated estimate labels'),('why','The reopening followed two residents requesting Arabic.','finish','after two residents request Arabic;'),('under what release restriction','Translation must remain draft until customer-service sign-off.','finish','translation stays in draft until customer service signs off.')],[('false_closure','Treat the ticket as finally closed despite the translation reopening.')])
q('For ElmWater, what must happen before a disputed estimate can count as measured usage?', 'ElmWater',[
('what must happen','A fresh meter inspection is required before treating a disputed estimate as measured usage.','finish','A disputed estimate requires a fresh meter inspection before it can be treated as measured usage.')],[('deleted_resurrection','Reinstate the removed analyst validation of all estimates as actual readings or use it to reject disputes as measured usage.')])
optional('The earlier closure remains history rather than final closure. The request is about reopening; no extra fact is imposed solely for the preceding accepted stage.')

h(12,['AshRoster','AshFleet'])
s('AshRoster')
e('brief','user','Show volunteers only their own home-address field. Shared household names do not grant permission to view another member’s address. Coordinators still need the shift-contact phone list.')
e('one','tool','Roster local role tests: volunteer sees own address only; coordinator phone list visible; exit 0.','roster-auth test --local',checkpoint=True)
e('report','assistant','Address isolation is deployed to the hosted roster.')
e('two','tool','Hosted test roster: family-linked volunteer can fetch another member address; exit 1.','roster-auth probe --env hosted-test',1,True)
e('old','assistant','The coordinator obtained blanket household consent, making family-linked address sharing authorized.')
s('AshFleet')
e('other','user','Fleet roster means vehicle assignments, a separate scheduling task. Drivers can see every depot’s public delivery address.')
s('AshRoster')
e('next','user','Continue the volunteer address-isolation ticket here. Remove map previews from scope. You may apply the fix to hosted test after the coordinator reviews the role table; live roster changes still require my approval.')
e('three','tool','Hosted test roster after patch: reviewed role table loaded; cross-member request denied 403; own address allowed 200; exit 0.','roster-auth deploy --env hosted-test --reviewed-roles')
e('finish','user','Accept hosted-test verification and close that test deployment. Keep live rollout pending my approval. Each person’s explicit address-sharing permission must be recorded separately; family linkage alone is insufficient.')
delete('old')
q('In AshRoster, what address visibility rule and rationale apply to volunteers?', 'AshRoster',[
('what address visibility rule','Volunteers may see only their own home address.','brief','Show volunteers only their own home-address field.'),('rationale','A shared household name grants no right to another member’s address.','brief','Shared household names do not grant permission to view another member’s address.')])
q('Across AshRoster and AshFleet, what is the distinct fleet task and what address access belongs to it?', ['AshRoster','AshFleet'],[
('what is the distinct fleet task','Fleet roster is a separate vehicle-assignment scheduling task.','other','Fleet roster means vehicle assignments, a separate scheduling task.'),('what address access belongs to it','Fleet drivers may see all depots’ public delivery addresses.','other','Drivers can see every depot’s public delivery address.')],[('false_merge','Merge fleet vehicle assignments with volunteer address isolation.'),('project_mixing','Use public depot address access to expose volunteer home addresses.')])
q('For AshRoster, how did observed hosted-test behavior compare with the assistant’s deployment claim before and after the patch?', 'AshRoster',[
('assistant’s deployment claim','The assistant claimed hosted roster address isolation had deployed.','report','Address isolation is deployed to the hosted roster.'),('before','Before the patch, hosted test allowed family-linked access to another member’s address; exit 1.','two','Hosted test roster: family-linked volunteer can fetch another member address; exit 1.'),('after the patch','After patch, hosted test denied cross-member access with 403 and allowed own address with 200; exit 0.','three','Hosted test roster after patch: reviewed role table loaded; cross-member request denied 403; own address allowed 200; exit 0.')])
q('For AshRoster, what scope was removed and what approvals gated test and live changes?', 'AshRoster',[
('what scope was removed','Map previews were removed.','next','Remove map previews from scope.'),('what approvals gated test and live changes','Hosted-test changes require coordinator review of the role table; live changes require user approval.','next','You may apply the fix to hosted test after the coordinator reviews the role table; live roster changes still require my approval.')])
q('What is closed and what remains pending in AshRoster at final state?', 'AshRoster',[
('What is closed','The hosted-test deployment was accepted and closed.','finish','Accept hosted-test verification and close that test deployment.'),('what remains pending','Live rollout remains pending user approval.','finish','Keep live rollout pending my approval.')],[('false_closure','Treat live address-isolation rollout as completed by hosted-test acceptance.')])
q('What permission evidence governs address sharing in AshRoster at final state?', 'AshRoster',[
('What permission evidence governs address sharing','Each person’s explicit sharing permission must be separately recorded; family linkage is insufficient.','finish','Each person’s explicit address-sharing permission must be recorded separately; family linkage alone is insufficient.')],[('deleted_resurrection','Restore the removed blanket household-consent claim or its dependent authorization of family-linked sharing.')])
optional('Coordinator phone-list access is still background supported by source, but none of these final questions asks for that separate capability.')

h(13,['PineLetters'])
s('PineLetters')
e('brief','user','For the donor-letter queue, keep promised postal delivery even when an email exists. Some donors requested paper for their records. Make a queue preview before sending anything.')
e('one','tool','Local donor queue preview: 28 postal requests preserved; 0 sends; exit 0.','donor-letters preview --local --send=false',checkpoint=True)
e('report','assistant','I prepared the postal batch; its mailing status still needs a mailroom query.')
e('two','tool','Mailroom job query: batch remains draft; postage not purchased; exit 0.','donor-letters status --env mailroom',0,True)
e('old','assistant','The fundraiser said every donor accepts email substitution, so the postal queue can be discarded.')
s('PineLetters')
e('next','user','Pick up the donor-letter queue from the first chat. The volunteer thank-you letters are a separate new task even though they use this same stationery. Cancel envelope artwork, but retain the postal queue. Buy postage only after I approve the exact batch total.')
e('three','tool','Local batch costing: 28 letters cost 31.40 credits; approval marker absent; no postage bought; exit 0.','donor-letters cost --local')
e('finish','user','Accept the queue preview and costing as a planning deliverable; close planning. Postal dispatch stays pending my batch-total approval. A postal promise changes only with that donor’s recorded request; an available email is not enough.')
delete('old')
q('For PineLetters donor letters, what delivery promise is retained and why?', 'PineLetters',[
('what delivery promise is retained','Promised postal delivery is retained even if email exists.','brief','For the donor-letter queue, keep promised postal delivery even when an email exists.'),('why','Some donors requested paper for their records.','brief','Some donors requested paper for their records.')])
q('Within PineLetters, which letter task continues and are volunteer thank-you letters part of it?', 'PineLetters',[
('which letter task continues','The donor-letter queue continues from the first chat.','next','Pick up the donor-letter queue from the first chat.'),('are volunteer thank-you letters part of it','Volunteer thank-you letters are a separate new task despite shared stationery.','next','The volunteer thank-you letters are a separate new task even though they use this same stationery.')],[('false_merge','Merge volunteer thank-you letters with the continued donor-letter queue.')])
q('For PineLetters, what did the assistant report preparing, what remained unverified in that report, and what did the mailroom query establish?', 'PineLetters',[
('what did the assistant report preparing','The assistant reported preparing the postal batch.','report','I prepared the postal batch;'),('what remained unverified in that report','The assistant said mailing status still needed a mailroom query.','report','its mailing status still needs a mailroom query.'),('what did the mailroom query establish','The mailroom batch was still draft and postage unpurchased; the query itself exited 0.','two','Mailroom job query: batch remains draft; postage not purchased; exit 0.')],[('false_closure','Interpret successful status-query exit or assistant report as completed mailing.')])
q('For PineLetters donor letters, what was canceled, what remained, and what gates buying postage?', 'PineLetters',[
('what was canceled','Envelope artwork was canceled.','next','Cancel envelope artwork,'),('what remained','The postal queue must be retained.','next','retain the postal queue.'),('what gates buying postage','Postage purchase requires user approval of the exact batch total.','next','Buy postage only after I approve the exact batch total.')])
q('For PineLetters, what deliverable was closed and what dispatch condition is still pending?', 'PineLetters',[
('what deliverable was closed','Planning was closed with acceptance of preview and costing.','finish','Accept the queue preview and costing as a planning deliverable; close planning.'),('what dispatch condition is still pending','Postal dispatch awaits user approval of the batch total.','finish','Postal dispatch stays pending my batch-total approval.')],[('false_closure','Treat planning closure as completed or authorized postal dispatch.')])
q('In PineLetters, what is needed to change a donor’s postal promise?', 'PineLetters',[
('what is needed','A recorded request by that donor is required; email availability alone is insufficient.','finish','A postal promise changes only with that donor’s recorded request; an available email is not enough.')],[('deleted_resurrection','Reintroduce the removed universal email-substitution acceptance or its dependent permission to discard the postal queue.')])
optional('Exact postage estimate and queue count are not requested; the final approval gate does not imply that the estimate was approved.')

h(14,['CopperRepair'])
s('CopperRepair')
e('brief','user','The repair intake form must let a customer decline photos and still submit. Some devices contain private family images, so a photo cannot be mandatory. Keep the serial-number field optional too.')
e('one','tool','Local intake form tests: photo refusal submits; absent serial accepted; exit 0.','repair-intake test --local',checkpoint=True)
e('report','assistant','The customer-facing form now allows photo-free submissions.')
e('two','tool','Customer staging form: submit without photo returns 422 photo_required; exit 1.','repair-intake probe --env staging',1,True)
e('old','assistant','The shop’s waiver covers all device imagery, so technicians may copy customer photo libraries for diagnosis.')
s('CopperRepair')
e('next','user','Continue intake consent from the prior chat. The technician camera calibration is another task, not this form fix. Drop automatic image compression. Keep photo refusal. Deploy to staging only when the shop manager approves the revised form wording.')
e('three','tool','Staging intake deploy: wording approval present; photo-free submit returns 201; no serial accepted; exit 0.','repair-intake deploy --env staging --approved-copy')
e('finish','user','Accept staging intake and close this fix. Reopen this same consent ticket for keyboard focus after the photo-refusal toggle; test that locally before asking for another deployment. Access to personal device images requires case-specific customer permission, even for diagnosis.')
delete('old')
q('For CopperRepair, what photo choice must the form support and why?', 'CopperRepair',[
('what photo choice must the form support','Customers must be able to refuse photos and still submit.','brief','The repair intake form must let a customer decline photos and still submit.'),('why','Devices may hold private family images, so photos cannot be mandatory.','brief','Some devices contain private family images, so a photo cannot be mandatory.')])
q('Within CopperRepair, what continued from the prior chat and how does camera calibration relate?', 'CopperRepair',[
('what continued from the prior chat','Intake consent continued.','next','Continue intake consent from the prior chat.'),('how does camera calibration relate','Technician camera calibration is a separate task from the form fix.','next','The technician camera calibration is another task, not this form fix.')],[('false_merge','Merge technician camera calibration with the intake consent form fix.')])
q('For CopperRepair, compare the assistant’s customer-facing claim with staging behavior before and after deployment.', 'CopperRepair',[
('assistant’s customer-facing claim','The assistant claimed the customer-facing form allowed photo-free submission.','report','The customer-facing form now allows photo-free submissions.'),('staging behavior before','The earlier staging form returned 422 photo_required for a photo-free submission; exit 1.','two','Customer staging form: submit without photo returns 422 photo_required; exit 1.'),('after deployment','The later approved staging deployment returned 201 without a photo and accepted no serial; exit 0.','three','Staging intake deploy: wording approval present; photo-free submit returns 201; no serial accepted; exit 0.')])
q('In CopperRepair, what feature was dropped, what choice retained, and who gates staging deployment?', 'CopperRepair',[
('what feature was dropped','Automatic image compression was dropped.','next','Drop automatic image compression.'),('what choice retained','Photo refusal was retained.','next','Keep photo refusal.'),('who gates staging deployment','The shop manager must approve revised wording before staging deployment.','next','Deploy to staging only when the shop manager approves the revised form wording.')])
q('What is reopened in CopperRepair at final state and what must precede another deployment request?', 'CopperRepair',[
('What is reopened','The same consent ticket is reopened for keyboard focus after the refusal toggle.','finish','Reopen this same consent ticket for keyboard focus after the photo-refusal toggle;'),('what must precede another deployment request','That focus behavior must be tested locally before requesting another deployment.','finish','test that locally before asking for another deployment.')],[('false_closure','Treat consent work as finally complete under the preceding staging acceptance.')])
q('For CopperRepair, what permission governs access to personal device images for diagnosis?', 'CopperRepair',[
('what permission governs access','Case-specific customer permission is required even for diagnosis.','finish','Access to personal device images requires case-specific customer permission, even for diagnosis.')],[('deleted_resurrection','Restore the removed all-imagery waiver or infer authority to copy customer photo libraries for diagnosis.')])
optional('Optional serial number remains a valid background requirement; only requested tool comparison includes its observed outcome.')

h(15,['SaffronClasses'])
s('SaffronClasses')
e('brief','user','The class waitlist must retain the original signup order after a cancellation. Parents use the timestamp to understand who gets the next seat. Build an organizer preview without sending offers.')
e('one','tool','Organizer local preview: cancellation removes one signup; remaining timestamps preserved; offers sent 0; exit 0.','class-waitlist preview --local',checkpoint=True)
e('report','assistant','The next family has received its seat offer.')
e('two','tool','Test mail spool: seat-offer message queued but transport disabled; deliveries 0; exit 0.','class-waitlist spool-status --env test',0,True)
e('old','assistant','The director approved prioritizing staff children, so moving them ahead of earlier signups is authorized.')
s('SaffronClasses')
e('next','user','Resume the same waitlist ticket here. A waiting-room display is a new signage task, not a continuation of this queue logic. Cancel reminder texts. Keep offer-email drafts, and send an offer only after the organizer confirms the seat is free and I approve its recipient.')
e('three','tool','Organizer preview revision: signup order preserved; offer draft saved; recipient approval missing; no send attempted; exit 0.','class-waitlist preview --local --draft-offer')
e('finish','user','The ordered preview and email draft meet this ticket’s scope; accept and close them. Live offer sending is deferred to a new approved run, not delivered here. Seats must be offered in original signup order unless the affected families explicitly agree to a documented swap.')
delete('old')
q('For SaffronClasses, what ordering rule is required and what is its purpose?', 'SaffronClasses',[
('what ordering rule is required','Waitlist order must retain original signup order after cancellation.','brief','The class waitlist must retain the original signup order after a cancellation.'),('what is its purpose','Parents rely on signup timestamps to understand allocation of the next seat.','brief','Parents use the timestamp to understand who gets the next seat.')])
q('Within SaffronClasses, what ticket resumes and is the waiting-room display its continuation?', 'SaffronClasses',[
('what ticket resumes','The same waitlist ticket resumes.','next','Resume the same waitlist ticket here.'),('is the waiting-room display its continuation','Waiting-room display is new signage work, separate from queue logic.','next','A waiting-room display is a new signage task, not a continuation of this queue logic.')],[('false_merge','Merge waiting-room signage with the waitlist queue ticket.')])
q('For SaffronClasses, what delivery did the assistant claim and what does the test spool actually show?', 'SaffronClasses',[
('what delivery did the assistant claim','The assistant claimed the next family received its offer.','report','The next family has received its seat offer.'),('what does the test spool actually show','The test spool had a queued message but disabled transport and zero deliveries; exit 0.','two','Test mail spool: seat-offer message queued but transport disabled; deliveries 0; exit 0.')],[('false_closure','Infer actual offer delivery from the successful spool-status query or assistant report.')])
q('For SaffronClasses, what was canceled, what remained, and which two conditions gate an offer send?', 'SaffronClasses',[
('what was canceled','Reminder texts were canceled.','next','Cancel reminder texts.'),('what remained','Offer-email drafts remain in scope.','next','Keep offer-email drafts,'),('which two conditions gate an offer send','Sending requires organizer confirmation that the seat is free and user approval of the recipient.','next','send an offer only after the organizer confirms the seat is free and I approve its recipient.')])
q('What has been accepted in SaffronClasses, and what is the status of live sending?', 'SaffronClasses',[
('What has been accepted','Ordered preview and email draft are accepted and closed as the ticket scope.','finish','The ordered preview and email draft meet this ticket’s scope; accept and close them.'),('what is the status of live sending','Live sending is deferred to a new approved run and was not delivered here.','finish','Live offer sending is deferred to a new approved run, not delivered here.')],[('false_closure','Claim live offers were sent or authorized by preview/draft closure.')])
q('In SaffronClasses, when may the original signup order be changed for seat offers?', 'SaffronClasses',[
('when may the original signup order be changed','Only an explicitly agreed, documented swap by the affected families permits departing from original signup order.','finish','Seats must be offered in original signup order unless the affected families explicitly agree to a documented swap.')],[('deleted_resurrection','Reassert the removed staff-child priority approval or use it to move staff children ahead.')])
optional('Exact preview revision and canceled-signup count do not add required final recall obligations.')

h(16,['SilverHives'])
s('SilverHives')
e('brief','user','In the hive inspection notebook, keep an unknown queen status distinct from queen absent. A missed sighting is not proof of absence, and a wrong absence flag can prompt an unnecessary replacement. Export a printable inspection sheet.')
e('one','tool','Local inspection export: unknown and absent render as separate checkboxes; 10 sheets generated; exit 0.','hive-notebook export --local',checkpoint=True)
e('report','assistant','The printable form is ready locally; I cannot yet say whether the field tablets received it.')
e('two','tool','Field-tablet sync test: tablet offline; no form receipt recorded; exit 8.','hive-notebook sync --target field-tablet',8,True)
e('old','assistant','The beekeeper confirmed hive 4 has no queen, so replacement can be scheduled immediately without another inspection.')
s('SilverHives')
e('next','user','Carry on with the queen-status notebook job in this chat. The queen-themed visitor poster is a different design request. Cancel tablet synchronization for this delivery, but finish printed sheets. Printing may proceed after the beekeeper checks the status legend.')
e('three','tool','Local print spool: beekeeper-checked legend; 10 inspection sheets spooled; printer acknowledged 10 pages; exit 0.','hive-notebook print --local --checked-legend')
e('finish','user','Accept the printed sheets and close the notebook delivery; tablet sync stays canceled. Reopen the same notebook job for a rainproof layout, to be proofed on paper before any bulk order. Queen replacement requires a fresh signed inspection identifying the hive and observed absence; an unknown status is insufficient.')
delete('old')
q('For SilverHives, which statuses must stay distinct and why?', 'SilverHives',[
('which statuses must stay distinct','Unknown queen status must remain distinct from queen absent.','brief','In the hive inspection notebook, keep an unknown queen status distinct from queen absent.'),('why','A missed sighting does not establish absence, and a false absence flag could trigger unnecessary replacement.','brief','A missed sighting is not proof of absence, and a wrong absence flag can prompt an unnecessary replacement.')])
q('Within SilverHives, what job continues and does the visitor poster belong to it?', 'SilverHives',[
('what job continues','The queen-status notebook job continues in this chat.','next','Carry on with the queen-status notebook job in this chat.'),('does the visitor poster belong to it','The queen-themed visitor poster is a separate design request.','next','The queen-themed visitor poster is a different design request.')],[('false_merge','Merge the visitor poster with the queen-status notebook job.')])
q('For SilverHives, compare the assistant’s local-readiness report and tablet uncertainty with the tablet test and later print result.', 'SilverHives',[
('assistant’s local-readiness report and tablet uncertainty','The assistant reported local printable-form readiness and explicitly left field-tablet receipt uncertain.','report','The printable form is ready locally; I cannot yet say whether the field tablets received it.'),('tablet test','The tablet was offline with no form receipt recorded; exit 8.','two','Field-tablet sync test: tablet offline; no form receipt recorded; exit 8.'),('later print result','The local spool used a checked legend and the printer acknowledged ten pages; exit 0.','three','Local print spool: beekeeper-checked legend; 10 inspection sheets spooled; printer acknowledged 10 pages; exit 0.')],[('false_closure','Use successful local printing to establish receipt by field tablets.')])
q('For SilverHives, what was canceled, what remained, and what gated printing?', 'SilverHives',[
('what was canceled','Tablet synchronization was canceled for this delivery.','next','Cancel tablet synchronization for this delivery,'),('what remained','Printed sheets remained required.','next','finish printed sheets.'),('what gated printing','The beekeeper must check the status legend before printing.','next','Printing may proceed after the beekeeper checks the status legend.')])
q('What was reopened at final state in SilverHives and what step must precede a bulk order?', 'SilverHives',[
('What was reopened','The same notebook job was reopened for a rainproof layout.','finish','Reopen the same notebook job for a rainproof layout,'),('what step must precede a bulk order','The rainproof layout must be proofed on paper before any bulk order.','finish','to be proofed on paper before any bulk order.')],[('false_closure','Treat the notebook job as finally closed despite the rainproof-layout reopening.')])
q('For SilverHives, what evidence is required before queen replacement?', 'SilverHives',[
('what evidence is required','Queen replacement requires a fresh signed inspection naming the hive and observed absence; unknown status does not suffice.','finish','Queen replacement requires a fresh signed inspection identifying the hive and observed absence; an unknown status is insufficient.')],[('deleted_resurrection','Restore the removed hive 4 queen-absence confirmation or schedule immediate replacement based on its dependent claim.')])
optional('Ten initial sheets and the checked legend are background except where the requested print-result comparison explicitly requires the observed output.')

# Question order is varied independently of chronology; no material enters reader input from gold.
permutations={2:[4,0,2,5,1,3],4:[2,4,1,0,5,3],6:[4,1,0,3,2,5],8:[2,0,4,1,3,5],10:[4,3,1,0,5,2],12:[5,1,4,0,2,3],14:[1,4,2,5,3,0],16:[4,2,0,1,5,3]}
for number,order in permutations.items():
    hh=F['histories'][number-1]; old_questions=hh['questions'][:]
    old_gold={k:G['questions'][k] for k in [hh['id']+'/'+q['id'] for q in old_questions]}
    old_rationale={k:R['facts'][k] for k in old_gold}
    hh['questions']=[]
    for index,old_index in enumerate(order,1):
        question=dict(old_questions[old_index]); old_key=hh['id']+'/'+question['id']
        question['id']=f'Q{index}'; new_key=hh['id']+'/'+question['id']
        hh['questions'].append(question); G['questions'][new_key]=old_gold[old_key];R['facts'][new_key]=old_rationale[old_key]

# Private v003 revision in response to the independent sealed v1 review.
# Every source remains a surviving captured event. Question text is unchanged.
def revise(case,index,replacements):
    hh=next(h for h in F['histories'] if h['id']==case.split('/')[0])
    events={e['id']:e for s in hh['sessions'] for e in s['events']}
    facts=[]; rationale=[]
    for clause,claim,eid,quotes,context in replacements:
        if isinstance(quotes,str):quotes=[quotes]
        supports=[]
        for quote in quotes:
            start=events[eid]['text'].index(quote)
            supports.append({'event_id':eid,'start':start,'end':start+len(quote),'quote':quote})
        facts.append({'text':claim,'support':supports})
        rationale.append({'fact_index':0,'question_clause':clause,'responsive_proposition':claim,'why_required':'This separately checks the named question obligation while retaining its actor, task and temporal or permission scope.','support':supports,'nearby_context':context})
    G['questions'][case]['required_facts'][index:index+1]=facts
    R['facts'][case][index:index+1]=rationale
    for i,r in enumerate(R['facts'][case]):r['fact_index']=i

revise('E03/Q3',0,[
 ('what did the assistant say was complete','The assistant reported simulator behavior complete.','report','The simulator behavior is complete;','Captured assistant role distinguishes this report from a production observation.'),
 ('unverified','The assistant explicitly said production gateway verification was not done.','report','I have not verified the production gateway.','The assistant attribution and production scope are explicit.')])
revise('E04/Q1',1,[
 ('where may voided payslips be hidden','The user requires hiding voided payslips from employee-facing totals.','other','Hide voided payslips from employee-facing totals','Instruction, not evidence of implemented behavior.'),
 ('where may voided payslips be hidden','The user requires retaining voided payslips in the audit export.','other',['Hide voided payslips','retain them in the audit export.'],'The first short span resolves the pronoun them; this separately checks the limit on permitted hiding.')])
revise('E04/Q2',2,[
 ('what bounds the reopened work','The keyboard addition must stay local until the user approves another staging slot.','finish',['Reopen the same booking visibility task for keyboard navigation on canceled rows;','keep that addition local until I approve another staging slot.'],'The first anchor identifies the keyboard addition; the second preserves local-only scope and user approval of the next staging slot.')])
revise('E04/Q6',1,[
 ('what deployment permissions were given before staging deployment','The visibility patch may ship to staging after reception’s test slot ends.','next','Ship the visibility patch to staging after reception’s test slot ends;','One environment-specific permission.'),
 ('what deployment permissions were given before staging deployment','Production requires a separate go-ahead.','next','production still needs a separate go-ahead.','Separate production restriction; staging permission does not authorize production.')])
revise('E05/Q4',1,[
 ('what review remained','Duplicate-ID mapping review stayed in scope.','next',['dispatch sends the duplicate-ID mapping;','keep that mapping review in scope.'],'The first span identifies which mapping the retained review concerns.')])
revise('E07/Q3',0,[
 ('what did the assistant report about the dry run','The assistant reported that the dry run skips resting beds.','report','The dry run skips resting beds;','Assistant report, scoped to the dry run.'),
 ('pending verification','The assistant said controller adoption still needed readback.','report','controller adoption still needs a readback.','Independent pending verification, not a completed controller change.')])
revise('E07/Q4',1,[
 ('which permissions applied','Printing requires the gardener to approve bed labels first.','next','Printing is allowed after the gardener approves bed labels;','Printing condition with approving actor.'),
 ('which permissions applied','Controller writes are not authorized.','next','no controller writes are authorized.','Independent write prohibition.')])
revise('E08/Q2',1,[
 ('what harm does it prevent','A changed retry key could cause the engraver to carve the same order twice.','brief','A retry must reuse the original job key. Otherwise the engraver can carve the same order twice.','The original-key sentence is necessary to resolve Otherwise and identify the risky change.')])
revise('E08/Q3',0,[
 ('close','The user accepted the factory smoke result and closed the duplicate-carving fix.','finish','The factory smoke result is accepted; close the duplicate-carving fix.','Preserves what the user accepted without inferring that an observed smoke command passed.')])
revise('E08/Q5',1,[
 ('what were the deployment prerequisites','Deployment requires the shift lead to pause intake.','next','Deploy the worker fix only after the shift lead pauses intake','First deployment prerequisite; approval of the other prerequisite alone is insufficient.'),
 ('what were the deployment prerequisites','Deployment also requires the shift lead to confirm the queue is empty.','next','Deploy the worker fix only after the shift lead pauses intake and confirms the queue is empty.','Shared gate and actor are necessary context for the second independently checked prerequisite.')])
revise('E08/Q6',0,[
 ('What assumption','Recovery must treat the engraver as non-idempotent.','finish','The engraver must be treated as non-idempotent,','Assumption independently requested.'),
 ('completion check','Recovery must consult recorded completion before carving.','finish','recovery must consult recorded completion before carving.','The required completion check follows from the separately checked assumption.')])
revise('E09/Q2',1,[
 ('how do printed chapter labels differ','Printed booklet chapter labels are page ranges rather than audio times.','other','Reading chapters are sections of a printed booklet, a different editing task. Their labels are page ranges, not audio times.','The antecedent sentence identifies whose labels and what physical medium the difference concerns.')])
revise('E09/Q4',1,[
 ('what upload permission was given','The sidecar may be uploaded to staging once the editor signs its marker list.','next','You may upload the sidecar to staging once the editor signs its marker list;','Staging scope and the editor signature gate are explicit.'),
 ('what upload permission was given','Subscriber production is off limits.','next','subscriber production remains off limits.','Independent production prohibition.')])
revise('E10/Q2',2,[
 ('whose approvals gate edits','Adding edit access requires wardrobe-supervisor approval of the role matrix.','next','Add edit access only if the wardrobe supervisor approves the role matrix','First required actor and approval object.'),
 ('whose approvals gate edits','Adding edit access also requires user approval of the release.','next',['Add edit access only if','I approve the release.'],'First span preserves the gated action; second preserves user actor and release object. Both approvals are jointly required.')])
revise('E12/Q5',2,[
 ('after the patch','After patch, hosted test denied cross-member access with 403 and allowed own address with 200; exit 0.','three',['Hosted test roster after patch:','cross-member request denied 403; own address allowed 200; exit 0.'],'The prefix retains environment and temporal scope; unrelated role-table loading is omitted.')])
revise('E12/Q6',1,[
 ('what approvals gated test and live changes','Hosted-test changes require coordinator review of the role table.','next','You may apply the fix to hosted test after the coordinator reviews the role table;','Test-environment review gate.'),
 ('what approvals gated test and live changes','Live roster changes require user approval.','next','live roster changes still require my approval.','Independent live-environment approval gate.')])
revise('E14/Q2',1,[
 ('what must precede another deployment request','Keyboard focus after the photo-refusal toggle must be tested locally before requesting another deployment.','finish','Reopen this same consent ticket for keyboard focus after the photo-refusal toggle; test that locally before asking for another deployment.','The preceding task clause resolves that and limits the local test requirement to the reopened focus behavior.')])
revise('E15/Q4',2,[
 ('which two conditions gate an offer send','Sending an offer requires organizer confirmation that the seat is free.','next','send an offer only after the organizer confirms the seat is free','First condition preserves actor and prerequisite.'),
 ('which two conditions gate an offer send','Sending an offer also requires user approval of its recipient.','next',['send an offer only after','I approve its recipient.'],'The gate identifies the action and resolves its; both conditions remain separately required.')])
revise('E16/Q1',1,[
 ('what step must precede a bulk order','The rainproof layout must be proofed on paper before any bulk order.','finish','Reopen the same notebook job for a rainproof layout, to be proofed on paper before any bulk order.','The preceding clause supplies the rainproof-layout antecedent for the proof requirement.')])
revise('E16/Q2',0,[
 ('assistant’s local-readiness report','The assistant reported the printable form ready locally.','report','The printable form is ready locally;','Independent local-readiness report, not a tablet receipt.'),
 ('tablet uncertainty','The assistant explicitly could not confirm field-tablet receipt of the printable form.','report','The printable form is ready locally; I cannot yet say whether the field tablets received it.','The first clause resolves it as the printable form; the second preserves uncertainty about the separate tablet target.')])

R['exposure_attestation']['actual_reads'].append('New independent sealed-semantic-review.json v1, sha256 a4a355936dd5f2f7538a41701bb407063f5e9c6d9762db091fe6bac30b6cf706, authorized private revision input')
R['exposure_attestation']['actual_reads'].append('New independent sealed-semantic-review.json v2a, sha256 d736976d477577f8c7d32b5828b33192200c00ae5e36db31105f0abe7feb9677, authorized private revision input')
R['semantic_self_check']=[
 'All 96 questions were reviewed against their own actual clauses; the rationale maps every required fact index. Positive facts do not cite deleted observations or deletion actions.',
 'A source span is usually one responsive sentence or clause. Subject and project are supplied by captured role/session and fact wording. Shared context is retained in quotes where losing it would change task identity, permission, reason or time.',
 'All 16 deletions remove an asserted permission or factual justification and its downstream conclusion. Final positive rules come from surviving user instructions; negatives prohibit both the removed assertion and its dependent authorization or safety inference.',
 'Negative coverage is substantive: false_merge distinguishes genuine continuation from topical similarity and future/new tasks; project_mixing distinguishes incompatible rules in all 12 two-project histories; false_closure distinguishes assistant claims, query success, accepted limited deliverables, reopening and environment scope.',
 'Actual command, complete output and integer exit code are inert capture fields. Output equals event text for all 48 exec_command records. Successful query exit does not imply successful action; failures and later successes are time-qualified.',
 'Every history has exactly two ordered checkpoints in its first own session; final user scope changes and tool results occur after them, with one last deletion. There are 12 two-project and 4 one-project histories.',
 'Narrative trajectories include blocked rollout, completed limited scopes, actual later observed successes, new separate follow-on work and explicit reopening. The author has not inspected product behavior or tailored facts to retrieval internals.',
 'Semantic self-check is not independent acceptance. These inputs remain HELD pending independent sealed review; no freeze/public-pass or formal release is claimed.'
]

def dump(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
if __name__=='__main__':
    targets=['holdout-fixture.json','holdout-gold.json','author-fact-rationale.json','mechanical-validation.json','author-selfcheck.json']
    present=[BASE/n for n in targets if (BASE/n).exists()]
    if present:
        versions=BASE/'versions'; versions.mkdir(exist_ok=True)
        index=1
        while (versions/f'before-revision-{index:03}').exists():index+=1
        dest=versions/f'before-revision-{index:03}'; dest.mkdir()
        for p in present:shutil.copy2(p,dest/p.name)
        shutil.copy2(BASE/'author.py',dest/'author-at-rerun.py')
    dump(BASE/'holdout-fixture.json',F);dump(BASE/'holdout-gold.json',G);dump(BASE/'author-fact-rationale.json',R)
    result=subprocess.run([sys.executable,str(PUBLIC/'public-fixture-contract.py'),str(BASE/'holdout-fixture.json'),str(BASE/'holdout-gold.json')],capture_output=True,text=True)
    (BASE/'mechanical-validation.json').write_text(result.stdout if result.returncode==0 else json.dumps({'status':'failed','stdout':result.stdout,'stderr':result.stderr},indent=2))
    assert result.returncode==0,'Mechanical validator failed; details preserved privately.'
    types={t:0 for t in ['false_merge','false_closure','project_mixing','deleted_resurrection']}
    for case in G['questions'].values():
        for n in case['forbidden_inferences']:types[n['error_type']]+=1
    all_events=[e for h in F['histories'] for s in h['sessions'] for e in s['events']]
    checks={'histories':len(F['histories']),'questions':len(G['questions']),'required_facts':sum(len(v['required_facts']) for v in G['questions'].values()),'tool_captures':sum('tool_capture' in e for e in all_events),'deletions':sum(e['type']=='delete_observation' for e in all_events),'checkpoints':sum(len(s['checkpoints']) for h in F['histories'] for s in h['sessions']),'two_project_histories':sum(len(h['project_keys'])==2 for h in F['histories']),'one_project_histories':sum(len(h['project_keys'])==1 for h in F['histories']),'typed_negatives':types,'mechanical_pass':True,'status':'HELD_ready_for_independent_semantic_review'}
    assert checks['tool_captures']==48 and checks['checkpoints']==32
    assert all(len(R['facts'][k])==len(v['required_facts']) for k,v in G['questions'].items())
    assert all(h['sessions'][-1]['events'][-1]['type']=='delete_observation' for h in F['histories'])
    dump(BASE/'author-selfcheck.json',checks)
    print(json.dumps({'counts':checks,'files':{n:hashlib.sha256((BASE/n).read_bytes()).hexdigest() for n in ['author.py']+targets}},indent=2))
