"""Synthetic public receipts/runtime only. No sealed input reads or native calls."""
from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch

HERE = Path(__file__).parent
REPO = HERE.resolve().parents[2]
spec = importlib.util.spec_from_file_location('protocol_builder', HERE / 'build-protocol.py')
builder = importlib.util.module_from_spec(spec)
spec.loader.exec_module(builder)


class ProtocolBuilderTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(dir='/private/tmp')
        self.addCleanup(self.temp.cleanup)
        self.repo = Path(self.temp.name)
        (self.repo / 'codex_mem').mkdir()
        shutil.copyfile(REPO / 'codex_mem/episode_processor.py', self.repo / 'codex_mem/episode_processor.py')
        (self.repo / 'codex_mem/public_toy.py').write_text('"""Inert toy runtime."""\n')
        self.runtime = builder.runtime_files(self.repo)
        self.guide = json.loads((REPO / 'docs/evidence/project-memory-quality-2026-10-21-r16/protocol.json').read_text())
        self.baseline = self.repo / 'baseline'
        (self.baseline / 'codex_mem').mkdir(parents=True)
        for number in range(47):
            (self.baseline / 'codex_mem' / f'module_{number}.py').write_text(f'# public baseline toy {number}\n')
        # Pure seam supplies a toy guide. CLI always pins the real R16 guide SHA.
        self.guide['baseline_runtime_hashes'] = builder.runtime_files(self.baseline)
        harness = {}
        for name in builder.PUBLIC:
            target = self.repo / builder.PREFIX / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(HERE / name, target)
            harness[builder.PREFIX + name] = builder.sha(target.read_bytes())
        helper = 'scripts/project_memory_consolidation_experiment.py'
        (self.repo / 'scripts').mkdir()
        shutil.copyfile(REPO / helper, self.repo / helper)
        harness[helper] = builder.sha((self.repo / helper).read_bytes())
        self.config = {'schema_version':1,'sealed_directory':str(self.repo/'never-open-sealed'),
                       'baseline_runtime_root':str(self.baseline),'harness_files':harness,
                       'repeats':{'regeneration':'Toy01','reader':'Toy02'}}
        self.config['runtime_receipt'] = self.save('runtime.json', {'status':'final_source_candidate','runtime_files':self.runtime})
        source_manifest = self.save('source-manifest.json', {'runtime_files':self.runtime})
        self.originals = {}
        for role in ('tests','spec','standards'):
            original = {'status':'passed' if role=='tests' else 'clear','runtime_files':self.runtime}
            if role=='tests':
                log = self.save('toy-tests.log', 'Synthetic offline evidence only.\n', raw=True)
                original.update(tests_run=20,failed=0,errors=0,full_suite=True,acceptance_hooks=True,protocol_tests=True,
                                evidence_files={log['path']:log['sha256']})
            else:
                original.update(unresolved_findings=0,source_manifest=source_manifest)
            self.originals[role] = self.save(role+'-original.json', original)
            self.config[role+'_binding'] = self.save(role+'-binding.json',
                {'status':original['status'],'runtime_files':self.runtime,'original':self.originals[role]})
        fake_hash = lambda label: hashlib.sha256(('public toy sealed '+label).encode()).hexdigest()
        self.metadata = {'schema_version':1,'status':'accepted','unresolved_findings':0,
            'fixture_sha256':fake_hash('fixture'),'gold_sha256':fake_hash('gold'),
            'mechanical_contract_sha256':harness[builder.PREFIX+'public-fixture-contract.py'],
            'semantic_guidance_sha256':harness[builder.PREFIX+'prospective-gold-semantics-contract.json'],
            'sealed_review_receipt_sha256':fake_hash('findings'),
            'independence_attestation':'independent_author_inputs_only_no_product_prior_inputs_answers_or_grades',
            'coverage':{'questions':96,'required_facts':128,'all_questions_reviewed':True,
                        'all_required_facts_reviewed':True,'negative_cases_reviewed':True}}
        self.refresh_sealed_metadata()
        self.config['historical_spend'] = self.save('spend.json', {'status':'public_toy_no_billing_claim'})

    def save(self, name, value, raw=False):
        path = self.repo / name
        path.write_text(value if raw else json.dumps(value))
        return {'path':str(path),'sha256':builder.sha(path.read_bytes())}

    def refresh_sealed_metadata(self):
        self.config['review_metadata'] = self.save('review-metadata.json', self.metadata)
        files = {'holdout-fixture.json':self.metadata['fixture_sha256'],'holdout-gold.json':self.metadata['gold_sha256'],
                 'sealed-semantic-review.json':self.metadata['sealed_review_receipt_sha256'],
                 'sealed-semantic-review-metadata.json':self.config['review_metadata']['sha256']}
        self.config['author_manifest'] = self.save('author-manifest.json', {'files':files,'counts':{'questions':96,'required_facts':128}})
        self.config['sealed_pins'] = self.save('sealed-pins.json', {'files':files,'counts':{'questions':96,'required_facts':128}})
        self.config['review_readiness'] = self.save('readiness.json',
            {'status':'accepted_sealed_semantic_review_metadata_only_not_trial_readiness',
             'metadata_sha256':self.config['review_metadata']['sha256'],
             'pins_sha256':self.config['sealed_pins']['sha256'],
             'manifest_sha256':self.config['author_manifest']['sha256'],'review_unresolved_findings':0})

    def build(self):
        return builder.build_protocol(self.config, self.repo, self.guide)

    def test_complete_pins_build_in_memory_with_all_strict_gates_and_no_clock(self):
        result = self.build()
        self.assertEqual(result['source_repairs']['runtime_files'], self.runtime)
        self.assertEqual(result['limits']['max_calls'],360)
        self.assertEqual(result['limits']['max_observed_tokens'],7000000)
        self.assertEqual(result['limits']['wall_seconds'],7200)
        self.assertEqual(result['protocol_preparation']['planned_answer_records'],216)
        self.assertEqual(result['protocol_preparation']['candidate_min_primary_supported'],87)
        self.assertEqual(result['pass_criteria']['individual_required_fact_loss_max'],0)
        self.assertEqual(result['independent_review_contract']['metadata_receipt_sha256'],self.config['review_metadata']['sha256'])
        self.assertEqual(result['public_preflight']['selected_disclosed_cases'],self.guide['public_preflight']['selected_disclosed_cases'])
        self.assertFalse((self.repo/'run.json').exists())
        self.assertFalse((self.repo/'freeze.json').exists())
        self.assertFalse((self.repo/'protocol.json').exists())

    def test_missing_original_or_changed_original_or_nonclear_verdict_rejects(self):
        for role in ('tests','spec','standards'):
            path=Path(self.originals[role]['path']);original=path.read_bytes()
            with self.subTest(role=role,kind='missing'):
                path.unlink()
                with self.assertRaises(FileNotFoundError):self.build()
                path.write_bytes(original)
            with self.subTest(role=role,kind='changed'):
                path.write_text('{}')
                with self.assertRaisesRegex(ValueError,'pinned_file_changed'):self.build()
                path.write_bytes(original)
            with self.subTest(role=role,kind='bad_status_even_when_rebound'):
                value=json.loads(original);value['status']='failed'
                old_binding=deepcopy(self.config[role+'_binding'])
                self.originals[role]=self.save(role+'-original.json',value)
                self.config[role+'_binding']=self.save(role+'-binding-rejected.json',
                    {'status':'passed' if role=='tests' else 'clear','runtime_files':self.runtime,'original':self.originals[role]})
                with self.assertRaisesRegex(ValueError,'original_not_final'):self.build()
                path.write_bytes(original);self.config[role+'_binding']=old_binding

    def test_added_changed_missing_runtime_and_stale_final_bindings_reject(self):
        path=self.repo/'codex_mem/public_toy.py';raw=path.read_bytes()
        path.write_text('# changed\n')
        with self.assertRaisesRegex(ValueError,'runtime_receipt'):self.build()
        path.write_bytes(raw);extra=self.repo/'codex_mem/extra.py';extra.write_text('# omitted from receipt\n')
        with self.assertRaisesRegex(ValueError,'runtime_receipt'):self.build()
        extra.unlink();path.unlink()
        with self.assertRaisesRegex(ValueError,'runtime_receipt'):self.build()
        path.write_bytes(raw)
        binding=json.loads(Path(self.config['spec_binding']['path']).read_text());binding['runtime_files']={}
        self.config['spec_binding']=self.save('stale-spec.json',binding)
        with self.assertRaisesRegex(ValueError,'spec_binding_not_final'):self.build()

    def test_review_source_manifest_must_match_every_actual_runtime_file(self):
        path=self.repo/'source-manifest.json';value=json.loads(path.read_text());value['runtime_files']={}
        ref=self.save('changed-source-manifest.json',value)
        original=json.loads(Path(self.originals['standards']['path']).read_text());original['source_manifest']=ref
        original_ref=self.save('rebound-review.json',original)
        self.config['standards_binding']=self.save('rebound-binding.json',
            {'status':'clear','runtime_files':self.runtime,'original':original_ref})
        with self.assertRaisesRegex(ValueError,'source_manifest_differs'):self.build()

    def test_missing_test_logs_failed_tests_or_review_findings_reject(self):
        path=self.repo/'toy-tests.log';path.unlink()
        with self.assertRaises(FileNotFoundError):self.build()

    def test_failed_test_counts_and_review_findings_cannot_be_rebound_as_clear(self):
        for role, change in (('tests', {'failed':1}), ('tests', {'errors':1}),
                             ('tests', {'full_suite':False}), ('spec', {'unresolved_findings':1})):
            with self.subTest(role=role,change=change):
                original = json.loads(Path(self.originals[role]['path']).read_text())
                changed = dict(original, **change)
                original_ref = self.save('bad-'+role+'-original.json', changed)
                old = self.config[role+'_binding']
                self.config[role+'_binding'] = self.save('bad-'+role+'-binding.json',
                    {'status':'passed' if role=='tests' else 'clear','runtime_files':self.runtime,'original':original_ref})
                with self.assertRaises(ValueError):self.build()
                self.config[role+'_binding'] = old

    def test_missing_harness_or_changed_common_producer_cannot_be_called_final(self):
        key=builder.PREFIX+'test-driver.py';pin=self.config['harness_files'].pop(key)
        with self.assertRaisesRegex(ValueError,'harness_pins_incomplete'):self.build()
        self.config['harness_files'][key]=pin
        producer=self.repo/'codex_mem/episode_processor.py';producer.write_text('# changed producer\n')
        runtime=builder.runtime_files(self.repo)
        self.config['runtime_receipt']=self.save('runtime-rebound.json', {'status':'final_source_candidate','runtime_files':runtime})
        with self.assertRaisesRegex(ValueError,'common_producer_changed'):self.build()

    def test_cli_never_overwrites_existing_protocol_or_reads_inputs_on_that_path(self):
        output=self.repo/'protocol.json';output.write_text('preserve original')
        argv=['builder','--inputs',str(self.repo/'nonexistent.json'),'--inputs-sha256','0'*64,'--output',str(output)]
        with patch('sys.argv',argv),self.assertRaisesRegex(ValueError,'already_exists'):builder.main()
        self.assertEqual(output.read_text(),'preserve original')

    def test_rejected_unresolved_incomplete_and_text_leaking_metadata_reject(self):
        for change in ({'status':'changes_required'},{'unresolved_findings':1},{'case_text':'not metadata'}):
            with self.subTest(change=change):
                original=deepcopy(self.metadata);self.metadata.update(change);self.refresh_sealed_metadata()
                with self.assertRaises(ValueError):self.build()
                self.metadata=original;self.refresh_sealed_metadata()

    def test_builder_never_opens_sealed_directory_or_named_content(self):
        old_read=Path.read_bytes
        def guarded(path):
            if path.is_relative_to(self.repo/'never-open-sealed') or path.name in builder.SEALED_CONTENT:
                raise AssertionError('sealed content opened')
            return old_read(path)
        with patch.object(Path,'read_bytes',guarded):self.build()
        self.config['review_metadata']={'path':str(self.repo/'never-open-sealed/sealed-semantic-review-metadata.json'),'sha256':self.config['review_metadata']['sha256']}
        with self.assertRaisesRegex(ValueError,'sealed_content_must_not_be_opened'):self.build()

    def test_baseline_helper_producer_placeholder_or_missing_harness_reject(self):
        path=self.baseline/'codex_mem/module_0.py';path.write_text('# drift\n')
        with self.assertRaisesRegex(ValueError,'baseline_runtime'):self.build()
        with self.assertRaisesRegex(ValueError,'placeholder'):builder.digest('0'*64)
        with self.assertRaisesRegex(ValueError,'placeholder'):builder.digest('TODO')


if __name__=='__main__':unittest.main()
