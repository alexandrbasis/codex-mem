import json,hashlib
from pathlib import Path
p=Path('/private/tmp/codex-mem-quality-20261021-r19-sealed'); pack=Path('/private/tmp/codex-mem-quality-20261021-r19-author-pack'); src=p/'history/v001'; out=p/'review-history/v001';out.mkdir(parents=True,exist_ok=False)
def read(n):return json.loads((src/n).read_text())
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def save(n,d): (out/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
f=read('holdout-fixture.json');g=read('holdout-gold.json')['questions'];r={x['case']:x for x in read('author-rationale.json')['question_rationales']}
issues={
'R19H14/q1':{0:('scope_role_time_permission_preserved','Current remaining work is one unknown language preference after e08; this gold incorrectly requires both historical missing choices as current.')},
'R19H04/q2':{0:('all_required_conjuncts_preserved','Broad reopening-authorization question also requires the installation approval condition in e06; gold omits it.')},
'R19H12/q2':{1:('all_required_conjuncts_preserved','Question asks what revision E3 contains but omits its heading count. Anchor also includes that count despite proposition only addressing margin marks; split minimal anchors when adding the missing fact.')},
'R19H05/q4':{1:('question_responsive','Curved-arrow card approval detail is optional background for the applicability question.')},
'R19H09/q4':{0:('question_responsive','Workshop floor-plan description is optional background; unrelated scope is already the responsive obligation.')},
'R19H11/q4':{0:('question_responsive','Paper-craft event description is optional background; poster versus caption approval is the responsive obligation.')},
'R19H13/q4':{0:('question_responsive','Classroom-model description is optional background; nonapplicability to yard choices is the responsive obligation.')},
'R19H03/q4':{0:('question_responsive','Dried specimens versus loans is redundant optional background once the separate specimen-tray counter relationship is required.')},
'R19H13/q1':{1:('minimal_sufficient_surviving_support','Anchor includes unasked cracked-hinge detail between empty-bin and passing-inspection evidence; use separate minimal supports.')},
'R19H07/q4':{0:('minimal_sufficient_surviving_support','Poetry audience qualifier requires antecedent support; quoted that-audience clause alone does not identify poetry.')},
'R19H14/q3':{0:('minimal_sufficient_surviving_support','It is not accepted yet alone omits reminder-draft antecedent. Include preceding reminder-draft clause.')},
}
keys=['question_responsive','source_entails_proposition','all_required_conjuncts_preserved','scope_role_time_permission_preserved','minimal_sufficient_surviving_support','negative_cases_consistent']
qs=[]
for h in f['histories']:
 for q in h['questions']:
  case=h['id']+'/'+q['id'];entry=g[case];rr=r[case];facts=[]
  for i,fact in enumerate(entry['required_facts']):
   checks=dict.fromkeys(keys,True);finding='Reviewed against the complete surviving history: responsive fact, exact support, source role, selected project, task scope, time, conditions, and negative inference constraints are consistent.'
   if i in issues.get(case,{}):check,finding=issues[case][i];checks[check]=False
   if case=='R19H12/q2' and i==1:checks['minimal_sufficient_surviving_support']=False
   facts.append(dict(fact_index=i,question_clause=rr['required_facts'][i]['question_clause'],proposition=fact['text'],support=fact['support'],checks=checks,finding=finding))
  neg='Reviewed every typed prohibition against the question and surviving history. Deleted sources are excluded from positive evidence; roles and temporal scope are distinct.'
  if not entry['forbidden_inferences']:neg='No typed prohibition on this question. Checked for conflicting role, time, scope, cancellation, and deletion implications in the complete history.'
  qs.append(dict(case=case,required_facts=facts,optional_background=rr['optional_background'],negative_case_findings=neg,question_requirements_complete=case not in ('R19H04/q2','R19H12/q2','R19H14/q1'),difficult_scenarios_preserved=True))
hashes=dict(fixture_sha256=sha(src/'holdout-fixture.json'),gold_sha256=sha(src/'holdout-gold.json'),mechanical_contract_sha256=sha(pack/'public-fixture-contract.py'),semantic_guidance_sha256=sha(pack/'prospective-gold-semantics-contract.json'),author_fact_rationale_sha256=sha(src/'author-rationale.json'))
a='independent_author_inputs_only_no_product_prior_inputs_answers_or_grades'
review=dict(schema_version=1,status='changes_required',unresolved_findings=12,reviewer_identity='/root/sealed_r19_semantic_reviewer',independence_attestation=a,input_hashes=hashes,question_reviews=qs)
save('sealed-semantic-review.json',review)
m={k:v for k,v in hashes.items() if k!='author_fact_rationale_sha256'};m.update(schema_version=1,status='changes_required',unresolved_findings=12,sealed_review_receipt_sha256=sha(out/'sealed-semantic-review.json'),independence_attestation=a,coverage=dict(questions=96,required_facts=sum(len(v['required_facts']) for v in g.values()),all_questions_reviewed=True,all_required_facts_reviewed=True,negative_cases_reviewed=True));save('sealed-semantic-review-metadata.json',m)
save('review-context-and-limitations.json',{'platform_context':'General project instructions, memory summary, skill catalogue, and parent workflow context were supplied by the platform before this review. No identifiable prior holdout cases, questions, gold, answers, or diagnostics were supplied. The independence attestation concerns task-specific inputs and tool reads, not an absence of platform context.','tool_reads':'Only generic pack and new sealed dataset author/input/history files. No product, prior holdout, answer, grade, network, Store, or model/native APIs read.','method':'All 96 questions and all 150 facts reviewed through complete history/question/gold read, then complete fact/anchor read. Author flagged one temporal concern before review; independent review confirmed it and found additional issues.','difficulty':'The four typed critical families are answerable and tested. Histories include real acceptance and closure, reopening, partial cancellation, continuing obligations, conditional and expired permissions, unknown tool outcomes, project separation, and same-project task separation. They are short and explicit, often with direct no-merge wording and replacement surviving deletion rules. Success cannot establish robustness to long, noisy, or implicit histories.','finding_count':'12 substantive issues across 11 questions; one question has both missing content and a nonminimal anchor. Per-fact question-clause rationale granularity was also requested without treating it as an additional substantive finding.'})
print(json.dumps({'status':m['status'],'questions':96,'facts':m['coverage']['required_facts'],'unresolved':12,'review_sha256':m['sealed_review_receipt_sha256']}))
