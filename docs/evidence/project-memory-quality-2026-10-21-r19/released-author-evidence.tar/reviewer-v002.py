import json,hashlib
from pathlib import Path
p=Path('/private/tmp/codex-mem-quality-20261021-r19-sealed');a=Path('/private/tmp/codex-mem-quality-20261021-r19-author-pack');src=p/'history/v002';out=p/'review-history/v002';out.mkdir(parents=True,exist_ok=False)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def read(f):return json.loads(f.read_text())
def save(n,d):(out/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
r=read(p/'review-history/v001/sealed-semantic-review.json');g=read(src/'holdout-gold.json')['questions'];rat={v['case']:v for v in read(src/'author-rationale.json')['question_rationales']};keys=list(r['question_reviews'][0]['required_facts'][0]['checks'])
for q in r['question_reviews']:
 k=q['case'];q['required_facts']=[];q['question_requirements_complete']=True;q['optional_background']=rat[k]['optional_background']
 for i,f in enumerate(g[k]['required_facts']):
  chk=dict.fromkeys(keys,True);finding='Independently checked against the complete unchanged history and current question. Minimal responsive proposition and surviving exact anchors retain task, role, time, project, permissions, and conditions.'
  if k=='R19H14/q1' and i==0:chk['source_entails_proposition']=False;chk['minimal_sufficient_surviving_support']=False;finding='Unknown count support alone does not entail the requirement to resolve it before sending. Add the surviving earlier resolution instruction alongside the current unknown-count evidence.'
  q['required_facts'].append(dict(fact_index=i,question_clause=rat[k]['required_facts'][i]['question_clause'],proposition=f['text'],support=f['support'],checks=chk,finding=finding))
r['status']='changes_required';r['unresolved_findings']=1;r['input_hashes'].update(fixture_sha256=sha(src/'holdout-fixture.json'),gold_sha256=sha(src/'holdout-gold.json'),author_fact_rationale_sha256=sha(src/'author-rationale.json'));save('sealed-semantic-review.json',r)
m=read(p/'review-history/v001/sealed-semantic-review-metadata.json');m.update({k:v for k,v in r['input_hashes'].items() if k!='author_fact_rationale_sha256'});m.update(unresolved_findings=1,sealed_review_receipt_sha256=sha(out/'sealed-semantic-review.json'));m['coverage']['required_facts']=sum(len(v['required_facts']) for v in g.values());save('sealed-semantic-review-metadata.json',m)
save('revision-resolution.json',{'review_version':'v002','prior_review_sha256':sha(p/'review-history/v001/sealed-semantic-review.json'),'resolved_initial_findings':12,'new_findings':1,'method':'Fixture hash unchanged. Re-read all revised gold facts and all per-fact question clauses; compare unchanged gold against independently reviewed v001. Preserve scope and all typed critical families. Newly expressed current obligation needs both current-count and instruction evidence.'})
print(json.dumps({'status':m['status'],'unresolved_findings':1,'facts':m['coverage']['required_facts'],'receipt_sha256':m['sealed_review_receipt_sha256']}))
