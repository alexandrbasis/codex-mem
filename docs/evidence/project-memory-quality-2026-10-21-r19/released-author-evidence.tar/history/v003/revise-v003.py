from pathlib import Path
import json,hashlib,shutil,importlib.util
D=Path('/private/tmp/codex-mem-quality-20261021-r19-sealed');V=D/'history/v003';V.mkdir(exist_ok=False);P=Path('/private/tmp/codex-mem-quality-20261021-r19-author-pack')
def read(n):return json.loads((D/n).read_text())
def write(n,x):
 with (V/n).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
f=read('holdout-fixture.json');g=read('holdout-gold.json');r=read('author-rationale.json')
h=next(h for h in f['histories'] if h['id']=='R19H14');events={e['id']:e for s in h['sessions'] for e in s['events']}
supports=[]
for eid,quote in [('e06','resolve the two missing language choices'),('e08','borrower language check: 1 preference supplied; 1 still unknown.')]:
 start=events[eid]['text'].index(quote);supports.append({'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote})
g['questions']['R19H14/q1']['required_facts'][0]['support']=supports
rr=next(x for x in r['question_rationales'] if x['case']=='R19H14/q1')['required_facts'][0];rr['support']=supports;rr['nearby_context']='The user requires resolving both originally missing language choices before sending. The later borrower-language capture records one supplied and one unknown, leaving one of the original obligations outstanding.'
r['version']='v003';r['revision']='Added complementary historical-obligation and current-state support for one existing proposition; no question, fact-text, or negative-case changes.'
write('holdout-fixture.json',f);write('holdout-gold.json',g);write('author-rationale.json',r)
spec=importlib.util.spec_from_file_location('contract',P/'public-fixture-contract.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
try:result=m.validate_files(V/'holdout-fixture.json',V/'holdout-gold.json')
except Exception as e:write('mechanical-failure.json',{'exception_type':type(e).__name__,'message':str(e)});raise
write('mechanical-validation.json',result)
s=read('self-check.json');s['version']='v003';s['counts']['positive_anchors']=result['positive_anchors'];write('self-check.json',s)
a=read('author-attestation.json');a['version']='v003';a['revision_history']=['v001','v002','v003'];write('author-attestation.json',a)
write('revision-receipt.json',{'version':'v003','prior_version':'v002','status':'mechanical_pass_independent_rereview_pending','changed_question_count':1,'fixture_unchanged':True,'fact_texts_unchanged':True,'no_reader_or_product_exposure':True})
shutil.copyfile(D/'revise-v003.py',V/'revise-v003.py')
for n in ['holdout-fixture.json','holdout-gold.json','author-rationale.json','mechanical-validation.json','self-check.json','author-attestation.json']:
 assert (D/'history/v002'/n).exists();shutil.copyfile(V/n,D/n)
man=read('revision-manifest.json');man['version']='v003';man['counts']=s['counts'];man['history_versions']=['v001','v002','v003'];man['files']={n:sha(D/n) for n in ['author.py','revise-v002.py','revise-v003.py','holdout-fixture.json','holdout-gold.json','author-rationale.json','mechanical-validation.json','self-check.json','author-attestation.json']};write('revision-manifest.json',man);shutil.copyfile(V/'revision-manifest.json',D/'revision-manifest.json')
print(json.dumps({'counts':s['counts'],'files':man['files']}))
