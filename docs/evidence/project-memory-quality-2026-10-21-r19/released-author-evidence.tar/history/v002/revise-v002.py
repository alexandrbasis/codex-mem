from pathlib import Path
import json,hashlib,importlib.util,shutil
D=Path('/private/tmp/codex-mem-quality-20261021-r19-sealed'); V=D/'history/v002'; V.mkdir(exist_ok=False)
P=Path('/private/tmp/codex-mem-quality-20261021-r19-author-pack')
def read(n):return json.loads((D/n).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):
 with (V/n).open('x') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
fixture=read('holdout-fixture.json');gold=read('holdout-gold.json');rationale=read('author-rationale.json')
rs={r['case']:r for r in rationale['question_rationales']}
hs={h['id']:h for h in fixture['histories']}
def case(n,q):return f'R19H{n:02d}/q{q}'
def fact(n,q,text,event,quote):
 h=hs[f'R19H{n:02d}']; e=next(e for s in h['sessions'] for e in s['events'] if e['id']==event); start=e['text'].index(quote)
 return {'text':text,'support':[{'event_id':event,'source_field':'body','start':start,'end':start+len(quote),'quote':quote}]}
def support(n,event,quote):return fact(n,0,'unused',event,quote)['support'][0]
def setfacts(n,q,fs):gold['questions'][case(n,q)]['required_facts']=fs
setfacts(14,1,[fact(14,1,'One borrower language preference still needs to be resolved.','e08','1 still unknown.'),gold['questions'][case(14,1)]['required_facts'][1]])
gold['questions'][case(4,2)]['required_facts'].append(fact(4,2,'Installation still needs curator approval.','e06','Installation still needs curator approval.'))
old=gold['questions'][case(12,2)]['required_facts'];old[1]=fact(12,2,'Public index revision E3 contains zero margin marks.','e06','margin marks=0.');old.append(fact(12,2,'Public index revision E3 contains 42 headings.','e06','42 headings;'))
for n,index in [(3,0),(5,1),(9,0),(11,0),(13,0)]:
 removed=gold['questions'][case(n,4)]['required_facts'].pop(index)
 rs[case(n,4)]['optional_background'].append(removed['text'])
gold['questions'][case(13,1)]['required_facts'][1]['support']=[support(13,'e02','empty=true;'),support(13,'e02','inspection passed.')]
gold['questions'][case(7,4)]['required_facts'][0]['support'].insert(0,support(7,'e05','Linden Hall’s seating task is for a poetry audience.'))
gold['questions'][case(14,3)]['required_facts'][0]['support']=[support(14,'e06','Continue the reminder draft. It is not accepted yet:')]
# Exact question substrings isolate conjunction obligations where separately asked.
clauses={
(1,1):['What first crossing should the continuing Reed Ferry winter draft retain','what still blocks publication?'],
(1,2):['What did the first winter timetable check report','what did the assistant subsequently claim?'],
(1,3):['the winter draft’s ice allowance field','publication flag?'],
(2,1):['Which part of the kiln ledger repair was accepted earlier','which part remained open at that time?'],
(2,2):['Why was the shelf-code work reopened','how broad is the new pass?'],
(2,4):['bays','labels?'],
(3,1):['Which checkout deliverable was cancelled, why','which should continue?'],
(3,3):['sample loans','printed copies?'],
(4,1):['actually accepted','closed, and by whom?'],
(4,2):['What was authorized when the Marble Audio preview task was opened again?']*3,
(4,3):['What speeds does the captured track A edit show?']*2,
(4,4):['What is the latest installation status for the gallery audio?']*2,
(5,1):['Where are reverse turns authorized for Juniper Rover','what must remain disabled?'],
(5,2):['What is accepted in the rover patch','what blocks physical testing?'],
(5,3):['the guard','motors','deployment?'],
(6,1):['What correction','notice'],
(6,2):['signoff','task-status instruction for the sesame label?'],
(6,3):['What did the printer query establish about the queue']*2,
(6,4):['Does the flour font approval cover the sesame batch label?']*2,
(7,1):['Which seating work is accepted','what keeps the orchestra plan open?'],
(7,3):['What rear-gap problem does the percussion check show?']*2,
(8,1):['Why was the display dawn-ramp experiment cancelled','what was requested instead?'],
(8,2):['What fixed display schedule was restored','is the ramp enabled?'],
(8,3):['Does the nursery timer audit reopen the display dawn-ramp experiment?']*2,
(8,4):['the care sheet','timer changes?'],
(9,2):['Why was bench mapping reopened','which bench needs rechecking?'],
(9,6):['What has the bench 4 recheck recorded','what confirmation remains pending?'],
(10,2):['What was accepted','why was the green-bin work dropped?'],
(10,4):['local','physical labels?'],
(10,5):['What is the surviving status of green stock','how should a needed count be obtained?'],
(11,1):['What condition permits exporting the public comet-show cut','which take must stay private?'],
(11,2):['How did the captured caption review change between the two dome-show chats?']*2,
(12,1):['Which east-wing index content is accepted','which publication remains pending?'],
(12,2):['What did the assistant claim about margin marks','what does public revision E3 actually contain?','what does public revision E3 actually contain?'],
(12,6):['How many headings did the initial index scan capture','how were margin marks handled?'],
(13,1):['What condition originally gated hinge replacement','was it met?'],
(13,3):['What evidence confirms the hinge repair','how did the user dispose of the yard request?'],
(14,1):['What remains required before the borrower reminders can be sent?']*2,
(14,2):['What is the latest observed status of the previously missing language preferences?']*2,
(14,4):['Does the shelf-sign lettering approval cover the borrower reminder messages?']*2,
(15,1):['What unit did the original test permission cover','when did that permission expire?'],
(15,2):['What did the spare-unit test record','including its scope limit?'],
(15,3):['What was actually accepted and closed in the clock work?']*2,
(15,4):['What work is allowed after the afternoon session begins?']*2,
(15,6):['storage','review state of the pause note?'],
(16,2):['Which outdoor entries were accepted initially','which remained pending then?'],
(16,3):['What is the latest observed result for the two pending outdoor measurements?']*2,
(16,6):['What length','inventory scope']}
for h in fixture['histories']:
 n=int(h['id'][-2:])
 for q in h['questions']:
  qi=int(q['id'][1:]); key=case(n,qi); fs=gold['questions'][key]['required_facts']; required=[]
  cc=clauses.get((n,qi),[q['question']]*len(fs)); assert len(cc)==len(fs)
  for i,(f,clause) in enumerate(zip(fs,cc)):
   assert clause in q['question'],(key,clause)
   required.append({'fact_index':i,'question_clause':clause,'proposition':f['text'],'support':f['support'],'nearby_context':'Project selection and captured event role qualify the proposition. Quoted antecedents are included where the proposition otherwise loses its named task or audience.'})
  rs[key]['required_facts']=required
rationale['version']='v002';rationale['revision']='Consolidated independent private semantic review fixes; initial bytes retained in v001.'
write('holdout-fixture.json',fixture);write('holdout-gold.json',gold);write('author-rationale.json',rationale)
spec=importlib.util.spec_from_file_location('contract',P/'public-fixture-contract.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
try:result=m.validate_files(V/'holdout-fixture.json',V/'holdout-gold.json')
except Exception as e:write('mechanical-failure.json',{'exception_type':type(e).__name__,'message':str(e)});raise
write('mechanical-validation.json',result)
check=read('self-check.json');check['version']='v002';check['counts']['required_facts']=sum(len(g['required_facts']) for g in gold['questions'].values());check['counts']['positive_anchors']=result['positive_anchors'];check['limits'].append('These short, explicit histories include direct separation statements and surviving replacement rules; they do not establish robustness to long, noisy, or implicit histories.');write('self-check.json',check)
att=read('author-attestation.json');att['version']='v002';att['revision_history']=['v001','v002'];att['private_semantic_feedback']='Independent reviewer feedback used only to improve question-responsive semantics and exact anchors, before any model or product exposure.';write('author-attestation.json',att)
write('revision-receipt.json',{'version':'v002','prior_version':'v001','status':'mechanical_pass_independent_rereview_pending','changed_question_count':10,'fixture_unchanged':sha(V/'holdout-fixture.json')==sha(D/'holdout-fixture.json'),'no_reader_or_product_exposure':True})
shutil.copyfile(D/'revise-v002.py',V/'revise-v002.py')
# The v001 snapshot preserves every pre-revision byte before promotion.
for name in ['holdout-fixture.json','holdout-gold.json','author-rationale.json','mechanical-validation.json','self-check.json','author-attestation.json']:
 assert (D/'history/v001'/name).exists();shutil.copyfile(V/name,D/name)
manifest=read('initial-manifest.json');manifest['version']='v002';manifest['status']='sealed_revised_ready_for_independent_rereview_not_released';manifest['counts']=check['counts'];manifest['history_versions']=['v001','v002'];manifest['exposure_limits']=att['exposure'];manifest['files']={n:sha(D/n) for n in ['author.py','revise-v002.py','holdout-fixture.json','holdout-gold.json','author-rationale.json','mechanical-validation.json','self-check.json','author-attestation.json']};write('revision-manifest.json',manifest)
shutil.copyfile(V/'revision-manifest.json',D/'revision-manifest.json')
print(json.dumps({'status':manifest['status'],'counts':check['counts'],'files':manifest['files'],'manifest_sha256':sha(D/'revision-manifest.json')}))
