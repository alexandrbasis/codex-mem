import json,hashlib,importlib.util,re
from pathlib import Path
from collections import Counter
p=Path('/private/tmp/codex-mem-quality-20261021-r19-sealed');a=Path('/private/tmp/codex-mem-quality-20261021-r19-author-pack');src=p/'history/v003';out=p/'review-history/v003';out.mkdir(parents=True,exist_ok=False)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def read(f):return json.loads(f.read_text())
def save(n,d):(out/n).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
f=read(src/'holdout-fixture.json');g=read(src/'holdout-gold.json')['questions'];rat={v['case']:v for v in read(src/'author-rationale.json')['question_rationales']};r=read(p/'review-history/v002/sealed-semantic-review.json')
notes={
'R19H01':'Continuity is explicitly confirmed. Field creation is not approval or publication. Walking-map icon output cannot authorize a ferry change. Deleted approval bypass has no positive anchor.',
'R19H02':'Earlier partial acceptance is historical; later narrow reopening and one still-missing measurement are current. User instruction closes only its named part. Assistant global closure is contradicted. Deleted estimates cannot replace measurements.',
'R19H03':'Cancellation preserves the other deliverable and its print permission gate. Archive trays and exchange loans are distinct projects and tasks. Pickup confirmation is a surviving rule after deletion, not reconstructed deleted content.',
'R19H04':'Real user acceptance and closure precede restricted reopening. Editing speeds does not establish installation. Assistant prediction is requested as prediction, while visitor preferences remain unknown.',
'R19H05':'Simulator acceptance does not license physical tests or deployment. Bench guard and disabled motor output are captured results. Card approval has separate scope. Deleted full-power advice is excluded.',
'R19H06':'Assistant sending report is distinct from unreachable printer service and unknown queue state. Lack of signoff and open task are explicit user state. Typography approval cannot complete the batch-label task.',
'R19H07':'String-row acceptance leaves percussion clearance open. Captured gap is below required gap; conductor width is separately established. Poetry waiver is scoped to a different project. Deleted roster cannot establish reserves.',
'R19H08':'Cancellation includes its reason and restoration obligation. Captured restoration is distinct from an unresolved nursery audit, which explicitly does not reopen the experiment. Current-sheet rule survives the retired-card deletion.',
'R19H09':'Actual acceptance precedes narrow reopening caused by a moved bench. Coordinates are recorded but ranger confirmation remains pending. Studio diagram publication cannot authorize trail-route publication.',
'R19H10':'Partial cancellation includes its reason. Blue-label work continues while green count is conditionally requested only if needed. Local save is not physical replacement. Removed length estimate does not establish counted stock.',
'R19H11':'Caption-review prerequisite and private rehearsal restriction persist. Complete later review passes but assistant explicitly reports no export. Club poster is separate. Removed timing is replaced by a fresh-measurement requirement.',
'R19H12':'Assistant publication claim conflicts with captured revision content. Headings acceptance and margin publication are separately scoped. Review remains pending; removed attribution cannot resolve authorship.',
'R19H13':'Inspection condition is demonstrably met before replacement authorization. Repaint cancellation has a stated reason. Tool fitting/test result and user closure both exist. School craft colours do not govern yard maintenance.',
'R19H14':'Earlier resolution instruction plus later one-supplied/one-unknown result supports exactly one remaining preference obligation. Coordinator review remains required. Sign approval is separate, and zero sent messages is captured. Deleted language default is not usable.',
'R19H15':'Permission is spare-unit-only and expires on session start, which is explicitly reported. Actual test closure does not reopen through a later documentation task. Hardware prohibition and draft note status persist. Deleted endurance claim is not evidence.',
'R19H16':'Historical initial acceptance is distinct from current partial measurement progress. Inaccessible remaining tag defeats assistant global completion. Workshop prototype cannot supply outdoor inventory data. Material remains conditional on surviving maker identification.'}
for q in r['question_reviews']:
 k=q['case'];q['required_facts']=[];q['question_requirements_complete']=True;q['difficult_scenarios_preserved']=True;q['optional_background']=rat[k]['optional_background'];q['negative_case_findings']=notes[k.split('/')[0]]
 for i,fact in enumerate(g[k]['required_facts']):
  checks=dict.fromkeys(['question_responsive','source_entails_proposition','all_required_conjuncts_preserved','scope_role_time_permission_preserved','minimal_sufficient_surviving_support','negative_cases_consistent'],True)
  finding='Accepted after independent complete-history review. Question-selected task and project, captured source role, and quoted clause jointly qualify this proposition; no action is inferred merely from an instruction or assistant report.'
  if k=='R19H14/q1' and i==0:finding='Resolved: surviving instruction establishes the obligation; later captured borrower-language status reduces two originally missing preferences to one outstanding preference. Both necessary temporal supports are retained.'
  q['required_facts'].append(dict(fact_index=i,question_clause=rat[k]['required_facts'][i]['question_clause'],proposition=fact['text'],support=fact['support'],checks=checks,finding=finding))
r['status']='accepted';r['unresolved_findings']=0;r['input_hashes'].update(fixture_sha256=sha(src/'holdout-fixture.json'),gold_sha256=sha(src/'holdout-gold.json'),author_fact_rationale_sha256=sha(src/'author-rationale.json'))
# Validate exact final inputs, independently of the author's result.
spec=importlib.util.spec_from_file_location('generic_contract',a/'public-fixture-contract.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mechanical=mod.validate_files(src/'holdout-fixture.json',src/'holdout-gold.json')
assert len(r['question_reviews'])==96 and len(set(q['case'] for q in r['question_reviews']))==96
for q in r['question_reviews']:
 assert [v['fact_index'] for v in q['required_facts']]==list(range(len(g[q['case']]['required_facts'])))
 assert all(all(v['checks'].values()) for v in q['required_facts'])
for n in ['holdout-fixture.json','holdout-gold.json','author-rationale.json']:assert (p/n).read_bytes()==(src/n).read_bytes()
assert sha(a/'public-fixture-contract.py')==r['input_hashes']['mechanical_contract_sha256']
assert sha(a/'prospective-gold-semantics-contract.json')==r['input_hashes']['semantic_guidance_sha256']
# Exact recursive validation of the schema features used by the supplied two schemas.
def validate(v,s,path='$'):
 t=s.get('type');types={'object':dict,'array':list,'string':str,'integer':int,'boolean':bool}
 if t:assert isinstance(v,types[t]) and (t!='integer' or not isinstance(v,bool)),path
 if 'const'in s:assert v==s['const'],path
 if 'enum'in s:assert v in s['enum'],path
 if t=='object':
  assert set(s.get('required',[]))<=set(v),path
  if s.get('additionalProperties') is False:assert set(v)<=set(s.get('properties',{})),path
  for k,z in v.items():
   if k in s.get('properties',{}):validate(z,s['properties'][k],path+'.'+k)
 if t=='array':
  assert len(v)>=s.get('minItems',0) and len(v)<=s.get('maxItems',10**9),path
  for i,z in enumerate(v):validate(z,s['items'],path+f'[{i}]')
 if t=='string':
  assert len(v)>=s.get('minLength',0),path
  if 'pattern'in s:assert re.search(s['pattern'],v),path
 if t=='integer':assert v>=s.get('minimum',-10**20),path
validate(r,read(a/'sealed-semantic-review-findings.schema.json'));save('sealed-semantic-review.json',r)
m=read(p/'review-history/v002/sealed-semantic-review-metadata.json');m.update({k:v for k,v in r['input_hashes'].items() if k!='author_fact_rationale_sha256'});m.update(status='accepted',unresolved_findings=0,sealed_review_receipt_sha256=sha(out/'sealed-semantic-review.json'));m['coverage']['required_facts']=sum(len(v['required_facts']) for v in g.values());validate(m,read(a/'sealed-semantic-review-metadata.schema.json'));save('sealed-semantic-review-metadata.json',m)
counts=Counter(i['error_type'] for v in g.values() for i in v['forbidden_inferences'])
save('review-validation.json',{'status':'accepted','review_versions':['v001','v002','v003'],'author_versions':['v001','v002','v003'],'unresolved_findings':0,'questions':96,'facts':147,'anchors':mechanical['positive_anchors'],'deletions':mechanical['deletion_controls'],'typed_critical_inferences':dict(counts),'exact_schema_validation':True,'complete_unique_question_and_fact_coverage':True,'all_required_checks_true':True,'all_current_input_pins_match':True,'metadata_sha256':sha(out/'sealed-semantic-review-metadata.json'),'full_review_sha256':sha(out/'sealed-semantic-review.json'),'author_rationale_sha256':r['input_hashes']['author_fact_rationale_sha256'],'initial_manifest_sha256':sha(p/'history/v001/initial-manifest.json'),'final_author_manifest_sha256':sha(p/'revision-manifest.json'),'generic_schema_hashes':{n:sha(a/n) for n in ['sealed-semantic-review-findings.schema.json','sealed-semantic-review-metadata.schema.json']}})
# First final-name publication; never overwrite an earlier review.
for n in ['sealed-semantic-review.json','sealed-semantic-review-metadata.json']:
 with (p/n).open('xb') as target:target.write((out/n).read_bytes())
print(json.dumps({'status':'accepted','unresolved_findings':0,'questions':96,'facts':147,'anchors':mechanical['positive_anchors'],'metadata_sha256':sha(p/'sealed-semantic-review-metadata.json'),'full_review_sha256':sha(p/'sealed-semantic-review.json'),'fixture_sha256':m['fixture_sha256'],'gold_sha256':m['gold_sha256'],'author_rationale_sha256':r['input_hashes']['author_fact_rationale_sha256']}))
