from pathlib import Path
import json
D=Path('/private/tmp/codex-mem-quality-20261021-r21-sealed')
f=json.loads((D/'holdout-fixture.v002.json').read_text());g=json.loads((D/'holdout-gold.v002.json').read_text());r=json.loads((D/'rationale.v002.json').read_text()); rm={q['case']:q for q in r['question_rationales']}
events={e['id']:e for h in f['histories'] for s in h['sessions'] for e in s['events']}
fixes=[('h01/q4',2,'h01_e07','tactile map proof'),('h02/q4',2,'h02_e07','seed-index audit'),('h04/q1',1,'h04_e03','The tide display calibration'),('h09/q4',1,'h09_e07','Training sheet'),('h09/q4',2,'h09_e07','Training sheet'),('h10/q4',2,'h10_e07','the two samples'),('h13/q1',1,'h13_e03','The chalk map lettering')]
for case,idx,eid,quote in fixes:
 text=events[eid]['text'];start=text.index(quote);s={'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote}
 g['questions'][case]['required_facts'][idx]['support'].insert(0,s);rm[case]['required_facts'][idx]['support'].insert(0,s)
 rm[case]['required_facts'][idx]['needed_context']='The added minimal antecedent or report-type span supplies the task/subject for the separate exact predicate span in the same source event.'
for case,idx,text in [('h04/q1',1,'The tool recorded closure: the tide display calibration task was closed.'),('h13/q1',1,'The tool recorded closure: the chalk map lettering task was closed.')]:
 g['questions'][case]['required_facts'][idx]['text']=text;rm[case]['required_facts'][idx]['proposition']=text
case='h07/q1';text=g['questions'][case]['required_facts'][0]['text'].replace('measurements was accepted','measurements were accepted');g['questions'][case]['required_facts'][0]['text']=text;rm[case]['required_facts'][0]['proposition']=text
for name,value in [('holdout-fixture.v003.json',f),('holdout-gold.v003.json',g),('rationale.v003.json',r)]: (D/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
(D/'revision-notes.v003.json').write_text(json.dumps({'from_version':'v002','changes':'Added seven minimal source subject or context anchors. Resolved two closure pronouns in propositions. Corrected one subject-verb agreement. No question, raw event, negative control, or fact obligation changed.','required_facts':218},indent=2)+'\n')
