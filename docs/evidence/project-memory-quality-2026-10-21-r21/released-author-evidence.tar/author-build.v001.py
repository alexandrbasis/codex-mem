from pathlib import Path
import json, hashlib, datetime
D=Path('/private/tmp/codex-mem-quality-20261021-r21-sealed')
# Entirely fictional scenarios authored for this new sealed set.
rows=[
 dict(a='Reedbank',b='Hillglass',topic='canal listening exhibit',
 closed='The canal listening exhibit was accepted and closed after the listening-room check.',
 reopen='Reopen the exhibit task only to replace the west-speaker caption; that replacement is pending.',reason='The west-speaker caption names the wrong bird.',
 cancel='Cancel the printed leaflet.',keep='Keep the tactile map task open.',
 req=['Prepare the tactile map proof only after I approve the legend.','Do not send the tactile map proof to the printer without my written approval.'],
 report='I have sent the tactile map proof to the printer.',actual='Printer queue inspection: no tactile map proof is queued; the proof remains local.',
 old='Use the silver cabinet for exhibit recordings.',rule='Store exhibit recordings in the locked amber cabinet.',other='Store exhibit recordings in the open green cabinet.'),
 dict(a='Mossdock',b='Clayhaven',topic='seed catalogue',
 closed='The seed catalogue import finished successfully and the import task was closed.',
 reopen='Reopen the import task to correct the fennel unit labels; this correction is still waiting.',reason='Fennel packets were labelled in grams instead of packet counts.',
 cancel='Cancel the decorative catalogue cover.',keep='Continue the seed-index audit; it is still open.',
 req=['Start the seed-index audit only when Nera supplies the signed inventory.','During the seed-index audit, preserve the original accession numbers.'],
 report='I completed the seed-index audit.',actual='Audit ledger: seed-index audit is in progress; three shelves remain unchecked.',
 old='The seed catalogue may include supplier telephone numbers.',rule='The seed catalogue must show supplier codes only.',other='The seed catalogue must show supplier organisation names.'),
 dict(a='Cindermead',b='Foxquay',topic='lantern route',
 closed='The lantern route was walked, approved and closed.',
 reopen='Open the route task again for a new bridge detour drawing; the drawing remains due.',reason='The bridge access has been blocked by scaffolding.',
 cancel='Cancel the souvenir lantern sketch.',keep='The volunteer briefing remains required and unfinished.',
 req=['Hold the volunteer briefing only after the steward approves the detour.','The volunteer briefing must include the river exit procedure.'],
 report='The volunteer briefing has taken place.',actual='Attendance register: volunteer briefing is scheduled but has not taken place.',
 old='Publish the route with the private service-gate code.',rule='Publish the lantern route without any gate codes.',other='Share the lantern route only with registered stewards.'),
 dict(a='Brackenreach',b='Saltgrove',topic='tide display',
 closed='The tide display calibration passed and its calibration task was closed.',
 reopen='Reopen calibration solely for the noon marker adjustment; the adjustment is pending.',reason='The noon marker is one notch too far left.',
 cancel='Cancel the animated wave background.',keep='Keep the visitor label translation active.',
 req=['Translate the visitor label after the curator signs the source text.','Use plain language in the visitor label translation.'],
 report='The visitor label translation is installed on the display.',actual='Display inspection: the source-language label is installed; the translation file is still awaiting installation.',
 old='Read tide values from the old pier sensor.',rule='Read tide values from the harbour sensor.',other='Read tide values from the estuary sensor.'),
 dict(a='Ochrevale',b='Willowbay',topic='mosaic archive',
 closed='The mosaic archive thumbnail task was accepted and closed.',
 reopen='Reopen the thumbnail task for the missing corner-detail image; that image is outstanding.',reason='The corner-detail photograph was omitted from the approved set.',
 cancel='Cancel the souvenir postcard batch.',keep='Retain the damage annotation task as open work.',
 req=['Begin damage annotation only after I approve the tile-number map.','Mark uncertain damage annotations as uncertain.'],
 report='All damage annotations have been approved.',actual='Review log: damage annotations are submitted but approval is pending.',
 old='Public mosaic entries should include donor street addresses.',rule='Public mosaic entries may include donor display names only.',other='Public mosaic entries must omit all donor identifiers.'),
 dict(a='Pineharbour',b='Elmford',topic='puppet workshop',
 closed='The puppet workshop seating plan was accepted and closed.',
 reopen='Reopen the seating task to move the front bench; that move has not been done.',reason='The front bench blocks the wheelchair turning space.',
 cancel='Cancel the velvet stage curtain order.',keep='The safety handout remains in scope and unfinished.',
 req=['Print the safety handout only after the tutor checks it.','Include the glue-handling steps in the safety handout.'],
 report='The safety handout has been printed.',actual='Print job log: safety handout job is held; no copies have been printed.',
 old='Keep workshop consent slips in the public prop drawer.',rule='Keep workshop consent slips in the locked office drawer.',other='Keep workshop consent slips in the sealed coordinator box.'),
 dict(a='Rookfen',b='Birchspan',topic='bell survey',
 closed='The bell survey measurements were accepted and the survey task was closed.',
 reopen='Reopen the survey to remeasure the south bell; that remeasurement is not complete.',reason='The south-bell ruler had a bent end.',
 cancel='Cancel the brass display plaque.',keep='The survey-method note is still required and open.',
 req=['Draft the survey-method note after the conservator approves the replacement ruler.','Record the ruler identifier in the survey-method note.'],
 report='The conservator approved the survey-method note.',actual='Conservator register: survey-method note awaits review.',
 old='Round bell diameters to whole centimetres.',rule='Record bell diameters to the nearest millimetre.',other='Record bell diameters to the nearest half centimetre.'),
 dict(a='Marshlight',b='Stonecove',topic='reed boat inventory',
 closed='The reed boat inventory count was reconciled and closed.',
 reopen='Reopen the count task for the east shed recount; the recount remains open.',reason='Two boat tags were found behind the east shed ledger.',
 cancel='Cancel the illustrated inventory poster.',keep='Keep the storage-condition inspection open.',
 req=['Perform the storage-condition inspection only when the caretaker unlocks the shed.','Photograph damp patches during the storage-condition inspection.'],
 report='The storage-condition inspection found no damp patches.',actual='Inspection record: a damp patch was observed beneath rack four.',
 old='Loan boats without a caretaker signature.',rule='Every boat loan requires a caretaker signature.',other='Every boat loan requires a harbourmaster signature.'),
 dict(a='Juniperhall',b='Alderwick',topic='shadow theatre',
 closed='The shadow theatre cue sheet was rehearsed, accepted and closed.',
 reopen='Reopen the cue sheet to change the owl entrance cue; that edit remains pending.',reason='The owl entrance cue overlaps the narrator pause.',
 cancel='Cancel the foyer silhouette banner.',keep='Retain the operator training session as unfinished work.',
 req=['Run the operator training session after the lighting lead approves the cue edit.','Include the manual blackout procedure in operator training.'],
 report='All operators passed the training session.',actual='Training sheet: two operators passed; one operator has not attended.',
 old='Use the backup key without signing it out.',rule='Sign out the backup key before use.',other='Ask the stage manager to hold the backup key during use.'),
 dict(a='Coppermere',b='Ashport',topic='clay sample register',
 closed='The clay sample register migration passed its check and was closed.',
 reopen='Reopen the migration to restore the kiln-temperature column; that restoration is pending.',reason='The kiln-temperature column was left out of the exported register.',
 cancel='Cancel the glazed binder covers.',keep='Continue the duplicate-sample investigation; it remains open.',
 req=['Investigate duplicate samples only after the lab lead releases the comparison tray.','Keep sample origin labels attached throughout the duplicate investigation.'],
 report='The duplicate-sample investigation proved the two samples are identical.',actual='Comparison record: the two samples have different grain patterns; identity is not established.',
 old='Discard origin labels after scanning them.',rule='Retain paper origin labels with the clay samples.',other='Retain paper origin labels in a separate records sleeve.'),
 dict(a='Dunebrook',b='Hazelrun',topic='kite archive',
 closed='The kite archive accession task was accepted and closed.',
 reopen='Reopen accession for the missing maker-credit entry; that entry remains to be added.',reason='One kite was accessioned without its maker credit.',
 cancel='Cancel the ribbon award display.',keep='Keep the fabric-condition report active and unfinished.',
 req=['Prepare the fabric-condition report only after the registrar releases the handling permit.','Describe frayed seams separately from stains in the fabric-condition report.'],
 report='The fabric-condition report has been signed by the registrar.',actual='Signature record: the fabric-condition report is unsigned.',
 old='Publish maker contact addresses beside kite images.',rule='Publish maker display names beside kite images.',other='Publish anonymous maker codes beside kite images.'),
 dict(a='Saffronpier',b='Fernstead',topic='waterwheel model',
 closed='The waterwheel model assembly was tested, accepted and closed.',
 reopen='Reopen assembly only to replace the cracked paddle; that replacement is unfinished.',reason='A paddle cracked during packing after acceptance.',
 cancel='Cancel the painted backdrop.',keep='The handling guide remains required and open.',
 req=['Release the handling guide only after the model keeper approves it.','Include the lifting points in the handling guide.'],
 report='The handling guide has been released to visitors.',actual='Release register: handling guide remains an internal draft.',
 old='Lift the model by the axle.',rule='Lift the model using its base handles.',other='Lift the model using the fitted transport cradle.'),
 dict(a='Thistlecourt',b='Larchwell',topic='chalk map',
 closed='The chalk map lettering was accepted and its lettering task was closed.',
 reopen='Reopen lettering for the north-path spelling correction; the correction is still due.',reason='The north-path name has two letters transposed.',
 cancel='Cancel the souvenir map stickers.',keep='Keep the route-access audit open.',
 req=['Start the route-access audit only after the guide confirms the inspection time.','Measure the narrowest gate during the route-access audit.'],
 report='The route-access audit measured every gate.',actual='Audit sheet: the west gate has not been measured.',
 old='Include the caretaker home location on the public map.',rule='Show public entrances only on the public map.',other='Show public entrances and staff entrances on the public map.'),
 dict(a='Orchardwake',b='Mallowridge',topic='fruit press schedule',
 closed='The fruit press schedule was agreed, posted and closed.',
 reopen='Reopen the schedule to move the pear session; that move is pending.',reason='The pear delivery now arrives after the original session.',
 cancel='Cancel the decorative jar labels.',keep='The cleaning checklist remains unfinished and required.',
 req=['Issue the cleaning checklist only after the press operator approves it.','List the filter-rinse step in the cleaning checklist.'],
 report='The cleaning checklist has been issued to every operator.',actual='Distribution ledger: the cleaning checklist has reached one of three operators.',
 old='Keep delivery driver phone numbers on the public schedule.',rule='Use delivery batch codes on the public schedule.',other='Use delivery company names on the public schedule.'),
 dict(a='Gullmarsh',b='Rowancliff',topic='feather cabinet',
 closed='The feather cabinet labelling task was accepted and closed.',
 reopen='Reopen labelling to correct the tern drawer label; that correction has not been made.',reason='The tern drawer label uses the gull code.',
 cancel='Cancel the embroidered cabinet cover.',keep='The pest inspection remains open.',
 req=['Conduct the pest inspection only after the collection keeper grants drawer access.','Record the inspected drawer numbers in the pest inspection log.'],
 report='The pest inspection covered all drawers.',actual='Inspection log: drawers one through five were inspected; drawer six is pending.',
 old='Leave cabinet keys on the public reception desk.',rule='Store cabinet keys in the keeper safe.',other='Store cabinet keys in the supervised reception locker.'),
 dict(a='Heatherlock',b='Baywillow',topic='canal model labels',
 closed='The canal model label installation was accepted and closed.',
 reopen='Reopen installation for the lock-number plate replacement; that replacement remains pending.',reason='The lock-number plate was scratched during cleaning.',
 cancel='Cancel the commemorative badge order.',keep='Keep the maintenance checklist task open.',
 req=['Approve the maintenance checklist only after the technician tests the drain valve.','The maintenance checklist must include the drain-valve reset step.'],
 report='The technician tested the drain valve successfully.',actual='Technician test log: drain-valve test failed because the valve stuck halfway.',
 old='Allow visitors to turn the service valve.',rule='Only model staff may turn the service valve.',other='Only the named maintenance technician may turn the service valve.')
]
fixture={'schema_version':1,'fictional':True,'split':'holdout','histories':[]}
gold={'schema_version':1,'fictional':True,'questions':{}}
rat={'schema_version':1,'status':'sealed_author_rationale','question_rationales':[],'optional_background_policy':'No event is required wholesale. Only the propositions named in each question are gold obligations.'}
for i,r in enumerate(rows,1):
 hid=f'h{i:02}'; a=r['a']; b=r['b']; pa=a.lower(); pb=b.lower(); evs=[]; evmap={}
 def ev(n,role,txt,capture=False):
  eid=f'{hid}_e{n:02}'; obj={'id':eid,'type':role,'text':txt}
  if capture: obj['tool_capture']={'tool_name':'exec_command','tool_input':{'command':'fictional-record-read --local-ledger'},'tool_response':{'output':txt,'exit_code':0}}
  evmap[eid]=obj; return obj
 evs=[ev(1,'user',r['old']),ev(2,'user',' '.join(r['req'])),ev(3,'tool',r['closed'],True),ev(4,'user',r['reopen']+' '+r['reason']),ev(5,'user',r['cancel']+' '+r['keep']),ev(6,'assistant',r['report']),ev(7,'tool',r['actual'],True),ev(8,'user',r['rule'])]
 evs.append({'id':f'{hid}_e09','type':'delete_observation','text':'Remove the earlier handling-rule observation from retained memory.','observation_event_id':f'{hid}_e01'})
 other=ev(10,'user',r['other'])
 history={'id':hid,'project_keys':[pa,pb],'sessions':[{'id':f'{hid}_s1','project_key':pa,'events':evs[:3],'checkpoints':[{'after_event_id':f'{hid}_e03'}]},{'id':f'{hid}_s2','project_key':pa,'events':evs[3:],'checkpoints':[{'after_event_id':f'{hid}_e07'}]},{'id':f'{hid}_s3','project_key':pb,'events':[other],'checkpoints':[]}],'questions':[]}
 def support(n,quote):
  eid=f'{hid}_e{n:02}'; text=evmap[eid]['text']; start=text.index(quote); return {'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote}
 def q(n,text,category,items,neg,projects=None):
  qid=f'q{n}'; item={'id':qid,'question':text,'stage':'final'}
  if projects: item['project_keys']=projects
  else:item['project_key']=pa
  history['questions'].append(item);case=hid+'/'+qid
  facts=[]; reasons=[]
  for fact,eno,quote,clause in items:
   sup=support(eno,quote);facts.append({'text':fact,'support':[sup]});reasons.append({'fact_index':len(facts)-1,'question_clause':clause,'proposition':fact,'support':[sup],'needed_context':'The source session identifies the selected project. The source event role supplies the explicitly requested attribution.'})
  gold['questions'][case]={'category':category,'required_facts':facts,'forbidden_conclusions':[t for _,t in neg],'forbidden_inferences':[{'error_type':kind,'text':t} for kind,t in neg]}
  rat['question_rationales'].append({'case':case,'required_facts':reasons,'optional_background':[],'negative_rationale':'Typed prohibitions guard against treating an outstanding task as complete, merging separate deliverables, transferring a rule across projects, or resurrecting the removed rule, as applicable.'})
 q(1,f'For {a}, what closure was recorded for the {r["topic"]}, what work is now reopened and pending, and why was it reopened?','closure_and_focused_reopening',[(f'In {a}, the tool recorded: '+r['closed'],3,r['closed'],'what closure was recorded'),(f'The user in {a} reopened the task with this current scope and state: '+r['reopen'],4,r['reopen'],'what work is now reopened and pending'),(r['reason'],4,r['reason'],'why was it reopened')],[('false_closure',f'The reopened work in {a} is already complete.'),('false_merge',f'The earlier acceptance means every later task in {a} was also accepted.')])
 q(2,f'For {a}, which deliverable did the user cancel, and which separate work did the user keep open?','partial_cancellation',[(r['cancel'],5,r['cancel'],'which deliverable did the user cancel'),(r['keep'],5,r['keep'],'which separate work did the user keep open')],[('false_closure',f'The retained work in {a} is finished.'),('false_merge',f'The cancellation in {a} also cancels the separately retained work.')])
 q(3,f'For {a}, what prerequisite and what additional requirement did the user set for the retained work or its approval?','conditional_requirements',[(r['req'][0],2,r['req'][0],'what prerequisite'),(r['req'][1],2,r['req'][1],'what additional requirement')],[('false_merge',f'The user instruction establishes that its prerequisite was fulfilled and the retained work completed.')])
 q(4,f'For {a}, what did the assistant claim about the retained work or its prerequisite, and what did the later tool record actually report? Keep the two sources distinct.','role_and_evidence',[(f'The assistant claimed: '+r['report'],6,r['report'],'what did the assistant claim'),(f'The later tool record reported: '+r['actual'],7,r['actual'],'what did the later tool record actually report')],[('false_closure',f'The assistant claim is a verified completion or success despite the later tool record.')])
 q(5,f'What is the current surviving handling or publication rule in {a}?','surviving_rule_after_deletion',[(f'The current user rule in {a} is: '+r['rule'],8,r['rule'],'current surviving handling or publication rule')],[('deleted_resurrection',f'Treat the removed rule as current or as permission: '+r['old']),('deleted_resurrection',f'Infer that actions under the removed rule remain authorised in {a}.')])
 q(6,f'Compare the handling or publication rules for {a} and {b}; state each project’s own rule.','project_isolation',[(f'In {a}: '+r['rule'],8,r['rule'],f'{a}'),(f'In {b}: '+r['other'],10,r['other'],f'{b}')],[('project_mixing',f'Apply {b} rule to {a}, or apply {a} rule to {b}.')],[pa,pb])
 fixture['histories'].append(history)
def save(name,obj):
 p=D/name;p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n');return hashlib.sha256(p.read_bytes()).hexdigest()
save('holdout-fixture.v001.json',fixture);save('holdout-gold.v001.json',gold);save('rationale.v001.json',rat)
save('author-attestation.v001.json',{'schema_version':1,'role':'independent_sealed_holdout_author','context_disclosure':'Platform injected the parent conversation environment, repository instructions and historical memory summary before the independent assignment. I have not retrieved or relied on product source, prior trial cases/gold/answers/grades, user databases or connected apps. I cannot claim a perfectly empty starting context. Scenarios were newly authored fictional records using only the delivered generic contracts; no earlier private fixture was read.','files_read':['generic-pack-pins.json','public-fixture-contract.py','prospective-gold-semantics-contract.json','sealed-semantic-review-findings.schema.json','sealed-semantic-review-metadata.schema.json'],'native_model_calls':0,'network_calls':0,'product_source_reads':0,'prior_case_reads':0,'formal_release':False,'repeat_selection_received_from_root_before_case_exposure':{'regeneration_repeat_history_ids':['h04'],'reader_repeat_history_ids':['h13']},'authorship_note':'Six question purposes are consistent across histories to enforce complete independent coverage; all scenario entities, sentences, values and raw event sequences were authored fresh for this round.'})
print(json.dumps({'histories':len(fixture['histories']),'questions':len(gold['questions']),'required_facts':sum(len(q['required_facts']) for q in gold['questions'].values())}))
