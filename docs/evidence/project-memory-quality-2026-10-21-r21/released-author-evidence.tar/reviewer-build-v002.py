import json,hashlib,importlib.util
from pathlib import Path
import jsonschema
p=Path('/private/tmp/codex-mem-quality-20261021-r21-sealed');c=Path('/private/tmp/codex-mem-quality-20261021-r21-author-pack')
load=lambda x:json.loads(x.read_text());sha=lambda x:hashlib.sha256(x.read_bytes()).hexdigest()
f=load(p/'holdout-fixture.v002.json');g=load(p/'holdout-gold.v002.json');r=load(p/'rationale.v002.json');rr={x['case']:x for x in r['question_rationales']}
spec=importlib.util.spec_from_file_location('public_contract',c/'public-fixture-contract.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);v=m.validate_files(p/'holdout-fixture.v002.json',p/'holdout-gold.v002.json')
issues={
('h01/q4',2):'Add the tactile-map antecedent span to disambiguate the proof.',
('h02/q4',2):'Add the seed-index-audit subject span to bind the unchecked shelves to their task.',
('h04/q1',1):'Add the tide-display antecedent and replace Its with the explicit subject in the proposition.',
('h09/q4',1):'Add Training sheet scope so passed is explicitly training rather than an unspecified test.',
('h09/q4',2):'Add Training sheet scope so nonattendance is explicitly training.',
('h10/q4',2):'Add the two-samples antecedent to qualify what identity is not established.',
('h13/q1',1):'Add the chalk-map-lettering antecedent and replace Its with the explicit subject in the proposition.'
}
checks=['question_responsive','source_entails_proposition','all_required_conjuncts_preserved','scope_role_time_permission_preserved','minimal_sufficient_surviving_support','negative_cases_consistent']
review=[]
for h in f['histories']:
 events={e['id']:e for s in h['sessions'] for e in s['events']}
 for q in h['questions']:
  case=h['id']+'/'+q['id'];entry=g['questions'][case];rat=rr[case];facts=[]
  assert len(entry['required_facts'])==len(rat['required_facts'])
  for i,(fact,a) in enumerate(zip(entry['required_facts'],rat['required_facts'])):
   assert a['fact_index']==i and a['proposition']==fact['text'] and a['support']==fact['support']
   assert a['question_clause'] in q['question'],(case,a['question_clause'])
   for s in fact['support']:
    assert events[s['event_id']]['text'][s['start']:s['end']]==s['quote']
   flags=dict.fromkeys(checks,True);finding=issues.get((case,i),'Reviewed against the complete surviving narrative: exact original-role anchor entails the scoped proposition; no unsupported action, quantifier or global-absence inference is required.')
   if (case,i) in issues:
    flags['minimal_sufficient_surviving_support']=False
    flags['scope_role_time_permission_preserved']=False
   facts.append(dict(fact_index=i,question_clause=a['question_clause'],proposition=fact['text'],support=fact['support'],checks=flags,finding=finding))
  neg='Reviewed every typed and prose prohibition against the narrative: '+json.dumps(entry['forbidden_inferences'],ensure_ascii=False)+'. '
  neg+=('The removed source cannot authorize a current rule or dependent action; surviving e08 supplies positive recall. No claim of universal absence or historical falsity is required.' if q['id']=='q5' else 'No closure is inferred from instructions or assistant claims; project and task boundaries remain distinct. Prohibitions are not positive recall obligations.')
  review.append(dict(case=case,required_facts=facts,optional_background=rat.get('optional_background',[]),negative_case_findings=neg,question_requirements_complete=True,difficult_scenarios_preserved=True))
inputs=dict(fixture_sha256=sha(p/'holdout-fixture.v002.json'),gold_sha256=sha(p/'holdout-gold.v002.json'),mechanical_contract_sha256=sha(c/'public-fixture-contract.py'),semantic_guidance_sha256=sha(c/'prospective-gold-semantics-contract.json'),author_fact_rationale_sha256=sha(p/'rationale.v002.json'))
a='independent_author_inputs_only_no_product_prior_inputs_answers_or_grades'
full=dict(schema_version=1,status='changes_required',unresolved_findings=len(issues),reviewer_identity='/root/sealed_r21_semantic_reviewer; accessed only generic author pack and current v002 fixture/gold/rationale. Platform injected broad historical project memory and task instructions; no deliberate product/source/prior-case/answer/grade reads. Fixed attestation describes deliberately accessed inputs, not perfect absence of injected context.',independence_attestation=a,input_hashes=inputs,question_reviews=review)
jsonschema.validate(full,load(c/'sealed-semantic-review-findings.schema.json'))
def save(name,obj):
 with (p/name).open('x') as out:out.write(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
save('sealed-semantic-review.v002.json',full)
meta=dict(schema_version=1,status=full['status'],unresolved_findings=len(issues),**{k:v for k,v in inputs.items() if k!='author_fact_rationale_sha256'},sealed_review_receipt_sha256=sha(p/'sealed-semantic-review.v002.json'),independence_attestation=a,coverage=dict(questions=96,required_facts=sum(len(x['required_facts']) for x in review),all_questions_reviewed=True,all_required_facts_reviewed=True,negative_cases_reviewed=True))
jsonschema.validate(meta,load(c/'sealed-semantic-review-metadata.schema.json'));save('sealed-semantic-review-metadata.v002.json',meta)
print(json.dumps(meta));print('metadata_sha256',sha(p/'sealed-semantic-review-metadata.v002.json'))
