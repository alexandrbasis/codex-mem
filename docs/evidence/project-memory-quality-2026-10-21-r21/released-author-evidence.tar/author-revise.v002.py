from pathlib import Path
import json,copy
D=Path('/private/tmp/codex-mem-quality-20261021-r21-sealed')
f=json.loads((D/'holdout-fixture.v001.json').read_text());g=json.loads((D/'holdout-gold.v001.json').read_text());r=json.loads((D/'rationale.v001.json').read_text());rm={q['case']:q for q in r['question_rationales']}
# source subject, outcome predicate, closure predicate, named outcome clause, optional activity
closures=[
('The canal listening exhibit','accepted','closed','acceptance','The closure followed the listening-room check.'),
('The seed catalogue import','finished successfully','the import task was closed','import result',''),
('The lantern route','approved','closed','approval','The route was walked.'),
('The tide display calibration','passed','its calibration task was closed','calibration result',''),
('The mosaic archive thumbnail task','accepted','closed','acceptance',''),
('The puppet workshop seating plan','accepted','closed','acceptance',''),
('The bell survey measurements','accepted','the survey task was closed','measurement acceptance',''),
('The reed boat inventory count','reconciled','closed','reconciliation result',''),
('The shadow theatre cue sheet','accepted','closed','acceptance','The cue sheet was rehearsed.'),
('The clay sample register migration','passed its check','was closed','migration check result',''),
('The kite archive accession task','accepted','closed','acceptance',''),
('The waterwheel model assembly','accepted','closed','acceptance','The assembly was tested.'),
('The chalk map lettering','accepted','its lettering task was closed','acceptance',''),
('The fruit press schedule','agreed','closed','agreement','The schedule was posted.'),
('The feather cabinet labelling task','accepted','closed','acceptance',''),
('The canal model label installation','accepted','closed','acceptance','')]
report_parts={
1:[('no tactile map proof is queued','No tactile map proof is queued.'),('the proof remains local','The tactile map proof remains local.')],
2:[('seed-index audit is in progress','The seed-index audit is in progress.'),('three shelves remain unchecked','Three shelves remain unchecked in the seed-index audit.')],
3:[('volunteer briefing is scheduled','The volunteer briefing is scheduled.'),('has not taken place','The volunteer briefing has not taken place.')],
4:[('the source-language label is installed','The source-language label is installed.'),('the translation file is still awaiting installation','The translation file is still awaiting installation.')],
5:[('damage annotations are submitted','The damage annotations are submitted.'),('approval is pending','Approval of the damage annotations is pending.')],
6:[('safety handout job is held','The safety handout print job is held.'),('no copies have been printed','No copies of the safety handout have been printed.')],
9:[('two operators passed','Two operators passed the training.'),('one operator has not attended','One operator has not attended the training.')],
10:[('the two samples have different grain patterns','The two samples have different grain patterns.'),('identity is not established','The identity of the two samples is not established.')],
15:[('drawers one through five were inspected','Drawers one through five were inspected.'),('drawer six is pending','The inspection of drawer six is pending.')],
16:[('drain-valve test failed','The drain-valve test failed.'),('the valve stuck halfway','The drain-valve test failed because the valve stuck halfway.')]
}
for i,h in enumerate(f['histories'],1):
 hid=h['id']; events={e['id']:e for s in h['sessions'] for e in s['events']};case=hid+'/q1'; subject,outcome,closed,label,opt=closures[i-1]
 def sup(n,quote):
  eid=f'{hid}_e{n:02}';s=events[eid]['text'];start=s.index(quote);return {'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote}
 def mk(text,n,quotes,clause,context='Source event role is tool. The subject and predicate occur in the same sentence; omitted conjunctions join predicates of that subject.'):
  supports=[sup(n,x) for x in quotes];return {'text':text,'support':supports},{'question_clause':clause,'proposition':text,'support':supports,'needed_context':context}
 question=h['questions'][0];question['question']=question['question'].replace('what closure was recorded',f'what {label} and what closure were recorded')
 # Include the minimal subject-bearing clause and outcome token as disjoint exact spans.
 fa,ra=mk(f'The tool recorded this {label}: {subject} {"was " if outcome in ("accepted","approved","reconciled","agreed") else ""}{outcome}.',3,[subject,outcome],f'what {label}')
 closuretext=(closed[0].upper()+closed[1:]+'.') if closed.startswith(('the ','its ')) else subject+' '+('' if closed.startswith('was ') else 'was ')+closed+'.'
 fb,rb=mk('The tool recorded closure: '+closuretext,3,([closed] if closed.startswith(('the ','its ')) else [subject,closed]),'what closure')
 old=g['questions'][case]['required_facts'];g['questions'][case]['required_facts']=[fa,fb]+old[1:]
 oldr=rm[case]['required_facts'];rm[case]['required_facts']=[ra,rb]+oldr[1:];rm[case]['optional_background']=[opt] if opt else []
 if i in report_parts:
  case4=hid+'/q4'; facts=[];rats=[]
  for quote,proposition in report_parts[i]:
   quotes=[quote]
   # Add a subject anchor where the standalone clause uses a pronoun or ellipsis.
   if i==3 and quote=='has not taken place':quotes=['volunteer briefing',quote]
   if i==5 and quote=='approval is pending':quotes=['damage annotations',quote]
   if i==6 and quote=='no copies have been printed':quotes=['safety handout',quote]
   if i==16 and quote=='the valve stuck halfway':quotes=['drain-valve test failed because the valve stuck halfway']
   fact,reason=mk('The later tool record reported: '+proposition,7,quotes,'what did the later tool record actually report','Minimal report clause; the same report and the question identify its task. Additional subject support is retained where a pronoun or omitted subject needs it.')
   facts.append(fact);rats.append(reason)
  g['questions'][case4]['required_facts']=g['questions'][case4]['required_facts'][:1]+facts
  rm[case4]['required_facts']=rm[case4]['required_facts'][:1]+rats
 if i==10:
  h['questions'][4]['question']='What is the current general storage rule for paper origin labels in Coppermere, apart from the investigation-specific attachment instruction?'
  h['questions'][5]['question']='Compare the general storage locations required for paper origin labels in Coppermere and Ashport, apart from investigation-specific handling; state each project’s own rule.'
  rm[hid+'/q5']['required_facts'][0]['question_clause']='current general storage rule for paper origin labels in Coppermere'
  rm[hid+'/q5']['optional_background']=['The investigation-specific attachment instruction is separately required by q3.']
  rm[hid+'/q6']['optional_background']=['The investigation-specific attachment instruction is separately required by q3.']
for q in r['question_rationales']:
 for idx,fact in enumerate(q['required_facts']):fact['fact_index']=idx
for name,value in [('holdout-fixture.v002.json',f),('holdout-gold.v002.json',g),('rationale.v002.json',r)]:
 (D/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
(D/'revision-notes.v002.json').write_text(json.dumps({'from_version':'v001','review':'sealed-semantic-review.v001.json','changes':'Split closure from prior outcomes in all q1 and explicitly request the outcome; retain unasked activities as optional background. Split ten composite later-tool reports without dropping report obligations. Narrow two storage-rule questions to distinguish the separate investigation constraint. All raw events and all difficult conditions retained unchanged.','required_facts':sum(len(q['required_facts']) for q in g['questions'].values())},indent=2)+'\n')
