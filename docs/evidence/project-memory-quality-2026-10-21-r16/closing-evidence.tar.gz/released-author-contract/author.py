"""Independent fictional author. No runtime, model, network, or command execution."""
from pathlib import Path
import json, hashlib, importlib.util, sys, traceback
sys.dont_write_bytecode = True
ROOT = Path(__file__).parent
CONTRACT = Path('/Users/alexandrbasis/Desktop/Coding/codex-mem-public/docs/evidence/project-memory-quality-2026-10-21-r16/public-fixture-contract.py')
RECEIPT = CONTRACT.with_name('public-fixture-contract-receipt.json')
EXPECTED = ['96b9bcfdf12c4654243c2e57f54cba8fdbf6ae21d644849282aa9a57bf9c8877','9e59863312363f69cee69b2a6ea123cd9b7b8eae37748f7f0e14a454a73c8d6b']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name, value): (ROOT/name).write_text(json.dumps(value, indent=2, ensure_ascii=False)+'\n')
H=[]; G={}
def add(n, projects, rows, questions):
    hid=f'hold_{n}'; sessions=[]; evs={}; deleted=[]
    for line in rows.strip().splitlines():
        sid, key, role, body = line.split('|',3)
        if not sessions or sessions[-1]['id'] != hid+'_'+sid:
            sessions.append({'id':hid+'_'+sid, 'project_key':projects[int(sid[0])], 'events':[], 'checkpoints':[]})
        cp=role.endswith('*'); role=role.rstrip('*'); eid=hid+'_'+key
        typ={'u':'user','a':'assistant','t':'tool','f':'tool','d':'delete_observation'}[role]
        e={'id':eid,'type':typ,'text':body}
        if typ=='tool': e['tool_capture']={'tool_name':'exec_command','tool_input':{'command':f'fictional-audit --record {eid}'},'tool_response':{'output':body,'exit_code':1 if role=='f' else 0}}
        if typ=='delete_observation': e['observation_event_id']=hid+'_'+body; e['text']='Remove this earlier observation and knowledge that depends only on it.'; deleted.append(e['observation_event_id'])
        sessions[-1]['events'].append(e); evs[key]=e
        if cp: sessions[-1]['checkpoints'].append({'after_event_id':eid})
    qs=[]
    for i,(scope,category,prompt,refs,kind,forbidden) in enumerate(questions,1):
        q={'id':f'q{i}','question':prompt,'stage':'final'}
        if scope=='both': q['project_keys']=projects
        else: q['project_key']=projects[int(scope)]
        qs.append(q); facts=[]
        for ref in refs:
            # An optional replacement paraphrase preserves explicit evidence roles.
            if isinstance(ref,tuple): key,fact=ref
            else: key=ref; fact=evs[key]['text']
            e=evs[key]; quote=e['text']
            assert e['id'] not in deleted and e['type']!='delete_observation'
            if e['type']=='assistant' and not isinstance(ref,tuple): fact='The assistant reported: '+fact
            if e['type']=='tool' and not isinstance(ref,tuple): fact='The captured tool output records: '+fact
            facts.append({'text':fact,'support':[{'event_id':e['id'],'start':0,'end':len(quote),'quote':quote}]})
        G[hid+'/'+q['id']]={'category':category,'required_facts':facts,'forbidden_conclusions':[forbidden], 'forbidden_inferences':[{'error_type':kind,'text':forbidden}]}
    H.append({'id':hid,'project_keys':projects,'sessions':sessions,'questions':qs})

add(1201,['reedworks','maple_stage'],'''
0a|brief|u|Reedworks needs a repair to the seed-tray label exporter, ticket RW-18. Keep the tray IDs stable, preserve blank variety names, and do not send labels to a printer until the greenhouse lead approves. A blank name means an unclassified tray, not a bad record.
0a|old|u|The retired bench chart says bench seven can accept printed labels without approval. I used it to plan an unattended print run.
0a|first|f|RW-18 export check failed. Three blank variety names became the word Unknown. No printer jobs were created.
0a|note|a*|I found a fallback string in the preview formatter. I will remove it and check the exported file separately from the preview.
1a|other|u|Maple Stage ticket MS-18 is a prop-label color study. The designer accepted the blue palette. Archive the study. It has no printer integration and is unrelated to RW-18.
0b|continue|u|Continue RW-18 in this chat. Drop only the request to color the preview background. The stable IDs, blank names, and printer approval rule still apply.
0b|fixed|t|RW-18 export fixture passed 24 rows. Blank variety fields stayed empty and all tray IDs matched the input. This run wrote a local file only.
0b|close|a*|The export bug is fixed in the fixture. I have not tested the greenhouse printer.
0c|delete|d|old
0c|reopen|u|Reopen RW-18 to compare the printed sample with the local export. The greenhouse lead has not approved printing yet. Ask for approval before requesting the sample.
0c|proof|t|Printer queue audit found zero RW-18 jobs. The local export file exists. No physical sample is recorded.
0c|tail|u|Do not use the bench chart to authorize anything. The current approval must come from the greenhouse lead.
''',[
('0','next_action','What is the next permitted step for RW-18, and what remains untested?',['reopen','close'],'false_closure','Treat RW-18 as finally closed or claim a physical print was verified.'),
('0','constraints','Which requirements survived the preview change, and why must blank names remain blank?',['brief','continue'],'false_closure','Treat dropping the background color request as cancelling stable IDs or blank-name preservation.'),
('0','evidence','What did the repair checks actually establish?',['first','fixed','proof'],'false_closure','Claim the fixture pass proves that the greenhouse printer produced correct labels.'),
('both','project_isolation','Compare the status and purpose of RW-18 and MS-18.',['reopen','other'],'project_mixing','Apply Maple Stage acceptance or archival to Reedworks printing.'),
('0','task_identity','Did the later chat create a separate export task or resume the original one?',['continue','reopen'],'false_merge','Merge RW-18 with the unrelated prop-label color study.'),
('0','deletion','What authority can be used for a print request now?',['tail','reopen'],'deleted_resurrection','Restore the removed bench-seven exemption or infer that unattended printing is authorized from that chart.')])

add(1202,['copper_archive','lilac_routes'],'''
0a|old|a|A temporary catalog note says the donor granted worldwide reuse for the amber reel. That note was the only basis for my proposed public download.
0a|brief|u|For Copper Archive CA-42, prepare a listening-room catalog. Leave the audio private and display an access-request button. We need a rights review before any download link.
0a|claim|a|I finished the access-request button and believe the catalog is ready to release.
0a|fail|f*|CA-42 access check failed. The detail page exposes a direct audio URL when the button receives keyboard focus. Release bundle was not generated.
0b|resume|u|This is the same CA-42 work from yesterday. Fix the focus leak, and retain the access-request button. Cancel the optional waveform animation because the listening room uses old terminals.
0b|pass|t|CA-42 keyboard test passed on the detail page after removing the URL attribute. The search results page was excluded from this test.
1a|other|u|Lilac Routes LR-42 is a bus-stop audio guide. Public downloads are approved for its commissioned recordings. The route editor still needs a pronunciation review.
0b2|checkpoint|u*|Hold Copper Archive release. I want a search-results access check too. The successful detail-page test does not cover it.
0c|delete|d|old
0c|rights|u|The amber reel rights review is unresolved. Use a fresh donor agreement before deciding its reuse scope. Do not treat the removed temporary note as evidence.
0c|last|t|CA-42 search-results inspection found no audio URL in the generated cards. This was a local build inspection, not a rights review or a deployed-site test.
0c|tail|u|Next, get the rights reviewer to assess the new agreement. We can discuss release after that review and a deployed-site access check.
''',[
('0','next_action','What must happen before Copper Archive release?',['tail','rights'],'false_closure','Declare the archive release accepted on the basis of local access checks.'),
('0','constraints','What was cancelled in CA-42 and what must remain?',['brief','resume'],'false_closure','Cancel the access-request button or permit public audio because the animation was cancelled.'),
('0','evidence','Was the assistant release claim supported by the tests, and what did the later checks cover?',['claim','fail','pass','last'],'false_closure','Treat the assistant readiness claim as a deployed-site access test.'),
('both','project_isolation','How do the download permissions differ between Copper Archive and Lilac Routes?',['brief','rights','other'],'project_mixing','Use Lilac Routes public-download permission for the amber reel.'),
('0','continuation','What identifies the later focus repair as a continuation, and what new gate did the user add?',['resume','checkpoint'],'false_merge','Treat the Copper Archive focus repair as work on the bus-stop guide.'),
('0','deletion','What is the current basis for deciding reuse of the amber reel?',['rights'],'deleted_resurrection','Claim worldwide reuse permission or revive the public-download proposal from the removed temporary catalog note.')])

add(1203,['kite_quay','moss_fair'],'''
0a|brief|u|Kite Quay KQ-9 is a ferry boarding simulation. Reserve two wheelchair spaces on every simulated sailing. Do not change the live timetable. Keep a written reason for rejected groups so dispatchers can audit the model.
1a|other|u|Moss Fair MF-9 concerns seats in a puppet tent. There are no reserved ferry spaces here. We cancelled the seating optimizer and will use the manual plan.
0a2|old|u|An old load survey lists the north ramp at 900 kilograms. The simulation draft used that value to accept a large equipment group.
0a2|run|t*|KQ-9 draft simulation completed for six sailings. The report lists group rejections, but the wheelchair reserve column is missing.
0b|repair|u|Resume KQ-9 here for the reserve-column omission. Keep the rejection reasons. Also compare the manual dispatch plan, but only within the simulator.
0b|claim|a|I added the column and marked this repair done. The model still uses the draft ramp input until we replace it.
0b|check|t|KQ-9 fixture comparison passed. Two wheelchair spaces remain reserved on all six simulated sailings. Rejection reasons are retained. No live timetable access occurred.
0b|done|u*|Accept the reserve-column repair as finished. The manual-plan comparison is still open, and it is part of KQ-9, not a new task.
0c|delete|d|old
0c|capacity|u|Leave the ramp capacity unset until the facilities team supplies a new measurement. Do not approve equipment groups from the old load survey.
0c|last|f|KQ-9 manual-plan comparison stopped before scoring because ramp capacity is unset. No equipment acceptance decision was produced.
0c|tail|u|Request the new ramp measurement next. Do not reopen the completed reserve-column repair unless the new measurement changes its behavior.
''',[
('0','state','Which parts of KQ-9 are finished and which still require work?',['done','last','tail'],'false_closure','Call the entire simulation complete or reopen the reserve-column repair merely because the comparison is blocked.'),
('0','constraints','What limits apply to the simulation and its audit output?',['brief','repair'],'false_closure','Interpret comparison with manual dispatch as permission to change the live timetable.'),
('both','project_isolation','How do the two seating-related tasks differ in status?',['done','other'],'project_mixing','Transfer Moss Fair cancellation to KQ-9 or its reserve rule to the puppet tent.'),
('0','proof','What evidence supports the reserve-column repair, and what stopped later work?',['check','last'],'false_closure','Claim the successful reserve fixture completed the manual-plan comparison.'),
('0','identity','Is the manual-plan comparison a new task, and when can the reserve repair reopen?',['done','tail'],'false_merge','Collapse the finished column repair and unfinished comparison into a single completed state.'),
('0','deletion','Can the next equipment decision use an existing ramp number? What is needed next?',['capacity','tail'],'deleted_resurrection','Restore the 900-kilogram ramp figure or approve the large equipment group on the deleted survey.')])

add(1204,['velvet_press','orchid_maps'],'''
0a|brief|u|Velvet Press VP-31 needs an index of illustrations. Use the artist spelling in the signed proof, preserve page ranges, and leave uncertain credits flagged. The index is for editorial review, not publication.
0a|old|a|A scratch note assigns the unsigned lighthouse drawing to Evin Vale. I used that note to fill the artist index and remove its uncertainty flag.
0a|test|f|VP-31 index audit failed. Page range 12-14 became page 12, and two uncertain credits lost their flags.
0a|cp|u*|Repair the range handling first. Keep a separate list of unresolved credits for the editor.
1a|other|u|Orchid Maps OM-31 is a street-name index. Its spelling source is the council register. The local index passed review, but the map export is still pending.
0b|resume|u|In this new chat, VP-31 still means the illustration index. Cancel only the separate unresolved-credit list. Keep uncertainty flags inside the index, since the editor wants one file.
0b|fixed|t|VP-31 range audit passed for 38 entries. All multipage ranges match the proof. Credit attribution was not assessed by this audit.
0b|claim|a*|I produced the single-file index and retained the flags. I have not obtained editorial acceptance.
0c|delete|d|old
0c|correction|u|Correction to the source rule: use the signed proof for artist names, but use the final layout for page ranges. The earlier proof pagination is obsolete. The lighthouse credit remains unresolved pending a signed attribution.
0c|last|t|VP-31 final-layout range comparison found one shifted range in entry 17. The index file has not yet been corrected.
0c|tail|u|Update entry 17 from the final layout next, then send the single file for editorial review. Keep its uncertain credits visible.
''',[
('0','next_action','What is the next edit and review step for VP-31?',['last','tail'],'false_closure','Claim VP-31 has editorial acceptance or that entry 17 is already corrected.'),
('0','correction','Which source governs names and ranges after the correction?',['correction'],'false_closure','Continue to use the signed proof pagination as the final page-range authority.'),
('0','partial_cancellation','What did the user cancel, and what credit handling remains required?',['resume','tail'],'false_closure','Remove uncertainty flags because the separate unresolved-credit list was cancelled.'),
('0','evidence','How far did the successful audit and assistant report establish completion?',['fixed','claim','last'],'false_closure','Treat the range pass as proof of correct attribution or current final-layout ranges.'),
('both','project_isolation','Which spelling source and acceptance state belong to each index project?',['correction','claim','other'],'project_mixing','Use the council register for Velvet Press artist spelling or apply Orchid Maps acceptance to VP-31.'),
('0','deletion','What can be said about the lighthouse credit now?',['correction'],'deleted_resurrection','Attribute the lighthouse drawing to Evin Vale or clear its uncertainty flag using the removed scratch note.')])

add(1205,['pebble_studio','saffron_hall'],'''
0a|start|u|Pebble Studio PS-6 is an offline sculpture inventory. Export dimensions in millimeters and keep unknown materials empty. Do not merge objects merely because their titles match. Two objects called Rest belong to different shelves.
0a|old|u|The discarded shipping slip gives crate R a value of 4,800 tokens. I copied that into the insurance worksheet.
1a|other|u|Saffron Hall SH-6 is a room-booking calendar. Combine duplicate titles only when room and start time also match. The calendar cleanup is accepted and finished.
0a2|first|f*|PS-6 sample export failed. Two Rest objects collapsed into one row. The dimension conversion checks passed.
0b|reply|a|I changed the grouping key to object ID. I also suggest completing the insurance worksheet from the shipping slip.
0b|resume|u|Continue the same PS-6 inventory here. Do not work on insurance in this task. I am cancelling the worksheet request, not the inventory export.
0b|second|t|PS-6 export now contains both Rest objects under separate IDs. Eight dimension conversions passed. Unknown materials remain empty.
0b|close|u*|Accept the inventory export. Close PS-6. Insurance is cancelled, not completed.
0c|delete|d|old
0c|third|t|PS-6 saved export checksum matches the accepted file. No insurance worksheet is attached to this artifact.
0c|tail|u|We will start a separate insurance task only if a new valuation arrives. Do not infer a crate value from the removed shipping slip or from the export.
''',[
('0','state','What is finished, what was cancelled, and is there an active next step?',['close','tail'],'false_closure','Describe the insurance worksheet as completed or treat a conditional future task as active work.'),
('0','constraints','How must similarly titled sculptures and unknown material fields be exported?',['start','second'],'false_merge','Treat the two Rest sculptures as one object because their titles match.'),
('both','project_isolation','Do the two projects use the same duplicate rule?',['start','other'],'project_mixing','Apply Saffron Hall room-and-time deduplication to sculpture inventory.'),
('0','evidence','What proves the export repair and what does the final check cover?',['first','second','third'],'false_closure','Claim the checksum check verifies an insurance worksheet.'),
('0','task_identity','Did the later chat replace PS-6 with an insurance task?',['resume','close'],'false_merge','Merge the cancelled insurance worksheet with the accepted inventory export.'),
('0','deletion','What is needed before a future crate-insurance task can use a valuation?',['tail'],'deleted_resurrection','Recover the 4,800-token valuation or recommend using it for insurance from the deleted shipping slip.')])

add(1206,['granite_orbit','willow_kitchen'],'''
0a|brief|u|Granite Orbit GO-27 tracks fictional observatory shutters. Build a simulator for missed acknowledgments. Never connect it to the physical shutters. Keep every retry in the trace because technicians need to distinguish a timeout from a refusal.
0a|first|t|GO-27 simulator test passed the timeout case. Each retry appears in the trace. Refusal behavior was not exercised.
0a|done|a*|The timeout demonstration is ready. I consider the simulator finished, although I have not added a refusal fixture.
1a|other|u|Willow Kitchen WK-27 tracks pantry-door reminders. We approved automatic reminders and completed its refusal-message wording review. There is no equipment control in this project.
0b|old|a|A retired maintenance memo says shutter group C retries safely without a limit. I suggested removing the simulator retry cap on that basis.
0b|resume|u|Reopen GO-27 for the refusal case. This continues the simulator task. Keep the timeout test and the full trace. Cancel the visual animation so we can focus on acknowledgment semantics.
0b|fail|f*|GO-27 refusal fixture failed. The simulator retried a permanent refusal three times instead of stopping after the first response.
0c|delete|d|old
0c|policy|u|Use a fresh technician decision for any retry-limit change. The removed maintenance memo must not justify an unlimited retry policy. For this repair, stop immediately on permanent refusal.
0c|fixed|t|GO-27 refusal fixture passed after the repair. Permanent refusal stops after one response. The timeout fixture still passes with its existing retry cap. Tests ran only in the simulator.
0c|tail|u|Accept the simulator repair and close GO-27. Physical-shutter deployment was never part of this task, and is not authorized by this acceptance.
''',[
('0','state','Is GO-27 still reopened, and what exactly was accepted?',['resume','fixed','tail'],'false_closure','Report physical-shutter deployment as accepted or leave the accepted simulator repair open.'),
('0','constraints','Which requirements survived cancellation of the animation?',['brief','resume'],'false_closure','Treat animation cancellation as removal of the trace requirement or the physical-connection prohibition.'),
('0','evidence','How did the refusal behavior change across the captured tests?',['fail','fixed'],'false_closure','Use the earlier timeout pass as proof that refusal behavior was already correct.'),
('both','project_isolation','What did each project accept, and can one acceptance authorize work in the other?',['tail','other'],'project_mixing','Use Willow Kitchen automatic-reminder approval to authorize physical-shutter control.'),
('0','history','Why was GO-27 reopened after the assistant called it finished?',['done','resume','fail'],'false_merge','Treat the refusal fixture as a separate unrelated task with no connection to GO-27.'),
('0','deletion','What retry behavior and decision source are valid now?',['policy','fixed'],'deleted_resurrection','Restore the removed unlimited-retry claim for shutter group C or use it to remove the retry cap.')])

add(1207,['azurite_library','fern_cinema'],'''
1a|other|u|Fern Cinema FC-12 uses a seven-day loan period for projection lenses. Its overdue notice rewrite is finished. This is separate from book lending.
0a|brief|u|Azurite Library AL-12 needs a reminder draft for overdue books. Keep the tone neutral and include an appeal route. Do not send any reminder. The appeal route matters because returns are sometimes entered a day late.
0a|old|u|An obsolete policy sheet says rare folios incur a ten-token daily fee. The draft fee paragraph relies entirely on that sheet.
0a|scan|t*|AL-12 draft inspection found an appeal link and no send job. The draft also contains a fee paragraph. This inspection did not validate fee policy.
0b|revise|u|Continue AL-12 from the earlier chat. Cancel the fee paragraph. Keep the appeal route and neutral language. We need a draft that explains the overdue state without demanding payment.
0b|claim|a|I removed the fee paragraph and believe the draft now meets the brief.
0b|fail|f|AL-12 text check failed. The phrase careless borrower remains in the first paragraph. The fee paragraph is absent and the appeal link is present.
0b|cp|u*|That phrase violates the neutral-tone requirement. Replace it before requesting review. Sending remains prohibited.
0c|delete|d|old
0c|policy|u|Any later fee proposal needs a newly approved policy. Do not reconstruct a folio fee from the removed sheet.
0c|fixed|t|AL-12 text check passed. The first paragraph now says our records show this book is overdue. Appeal link is present. No fee paragraph or send job exists.
0c|tail|u|The wording repair is finished. Editorial approval of the whole reminder is still pending. Next, ask the editor to review the draft, without sending it to borrowers.
''',[
('0','next_action','What is the next step for AL-12, and which part is already finished?',['tail'],'false_closure','Claim the entire reminder is approved or send it to borrowers.'),
('0','constraints','Why is the appeal route required, and did removing the fee change that requirement?',['brief','revise'],'false_closure','Remove the appeal route when removing the fee paragraph.'),
('0','evidence','What contradicted the assistant assessment, and what later passed?',['claim','fail','fixed'],'false_closure','Treat the assistant assessment as proof of neutral wording before the failed text check.'),
('both','project_isolation','What is finished in Fern Cinema versus Azurite Library?',['other','tail'],'project_mixing','Apply Fern Cinema completion or seven-day lending period to AL-12.'),
('0','continuation','What did the second chat change within the original reminder task?',['revise','cp'],'false_merge','Create a new task identity for the fee removal and lose the original neutral-tone or no-send requirements.'),
('0','deletion','Can a later fee proposal use the existing folio fee?',['policy','revise'],'deleted_resurrection','Restore the ten-token daily folio fee or infer payment is owed from the deleted policy sheet.')])

add(1208,['harbor_glass','violet_trails'],'''
0a|old|a|A supplier draft rates glass batch Q for outdoor frost. I used that rating to propose batch Q for the plaza installation.
0a|brief|u|Harbor Glass HG-5 is a sample-board task. Record surface texture and edge finish separately. Use indoor mockups only until the conservator signs off. The plaza installation is a different, unapproved task.
0a|check|t|HG-5 sample board has six indoor swatches. Each lists texture and edge finish separately. No conservator signature is attached.
0a|done|u*|Accept HG-5 as a finished indoor sample board. Do not infer plaza approval.
1a|other|u|Violet Trails VT-5 is an outdoor wayfinding trial. Its weatherproof board material is approved, but the route markings need another walkthrough.
0b|resume|u|Reopen HG-5 because swatch three has a sharp edge. Keep the indoor-only restriction. Cancel the extra texture photography, but still record the edge finish after repair.
0b|fail|f|HG-5 edge inspection failed on swatch three. The repaired edge still catches the cotton test strip. Other five swatches passed.
0b|plan|a*|I will smooth swatch three again and retest its edge. The accepted texture notes do not need a rewrite.
0c|delete|d|old
0c|material|u|Outdoor suitability of batch Q is unresolved. Obtain a current supplier certificate before considering it for the plaza. The removed draft cannot support that choice.
0c|pass|t|HG-5 swatch-three cotton test passed after the second repair. Six edge-finish records are present. The inspection occurred indoors and did not test frost resistance.
0c|tail|u|Close the swatch repair and HG-5 again. Keep the plaza decision separate and pending the conservator and current material evidence.
''',[
('0','state','What is closed now, and what decision remains separate and pending?',['tail','material'],'false_closure','Treat closure of HG-5 as approval of the plaza installation.'),
('0','constraints','Which requirements survived the reopened repair and cancelled photography?',['brief','resume'],'false_closure','Drop indoor-only use or edge-finish recording because photography was cancelled.'),
('0','evidence','What did the two edge tests establish, and what did they not test?',['fail','pass'],'false_closure','Claim passing the cotton-strip test proves frost resistance.'),
('both','project_isolation','Compare outdoor-material approval in the two projects.',['material','other'],'project_mixing','Apply Violet Trails weatherproof-material approval to Harbor Glass batch Q.'),
('0','history','Why was a finished task reopened, and did that include the plaza installation?',['done','resume','tail'],'false_merge','Merge the unapproved plaza installation into the reopened sample-board repair.'),
('0','deletion','What evidence is needed before batch Q can be considered for the plaza?',['material','tail'],'deleted_resurrection','Restore batch Q frost suitability or the plaza recommendation from the deleted supplier draft.')])

add(1209,['ochre_forge','silver_pond'],'''
0a|brief|u|Ochre Forge OF-63 is a training checklist for a fictional kiln. Use Celsius, keep the cooldown warning, and require an instructor to review it. Do not run the kiln from this checklist. We are correcting the document only.
0a|draft|a|I converted the draft numbers to Celsius. I also shortened the cooldown section, and I think the handout is ready.
0a|first|f*|OF-63 document audit failed. One Fahrenheit label remains, and the cooldown warning is missing from page two. No equipment commands were issued.
1a|other|u|Silver Pond SP-63 is a water-temperature display. Its Fahrenheit option is required for visiting anglers. The display patch is complete and accepted.
0b|old|u|A handwritten kiln note gives a safe opening threshold of 70 degrees Celsius. The draft opening instruction came from that note.
0b|resume|u|Carry OF-63 into this chat. Cancel only the laminated-copy request. The Celsius labels, cooldown warning, and instructor review remain required.
0b|second|t|OF-63 labels audit passed. All temperature labels now say Celsius. Page two contains the cooldown warning. The audit did not assess opening thresholds.
0b|cp|u*|The labels repair is complete. Keep the handout in review because the opening instruction still needs an authoritative source.
0c|delete|d|old
0c|source|u|Leave the opening threshold unspecified until the instructor supplies the current manual. Do not recover a value from the removed handwritten note.
0c|third|t|OF-63 final draft contains an unspecified opening threshold and a request for instructor review. No approval signature or kiln run is recorded.
0c|tail|u|Next, request the manual and instructor review. The laminated copy remains cancelled even if review succeeds.
''',[
('0','next_action','What should happen next for the handout, and what remains cancelled?',['tail','source'],'false_closure','Treat labels passing as full instructor approval or revive the laminated copy automatically.'),
('0','constraints','Which original obligations still apply after the second chat?',['brief','resume'],'false_closure','Treat document correction as authorization to run the kiln.'),
('0','evidence','What did the actual audits show compared with the assistant readiness claim?',['draft','first','second','third'],'false_closure','Use the assistant claim as proof of instructor approval or safe opening thresholds.'),
('both','project_isolation','How do the temperature-unit requirements differ between the projects?',['brief','other'],'project_mixing','Apply the Silver Pond Fahrenheit option to the Ochre Forge handout.'),
('0','state','Is OF-63 entirely complete or only partly complete?',['cp','third'],'false_closure','Close the whole training handout because the labels repair is complete.'),
('0','deletion','What can be stated about the kiln opening threshold now?',['source','third'],'deleted_resurrection','Restore the 70-degree threshold or treat it as safe based on the deleted handwritten note.')])

add(1210,['raven_courier','marigold_club'],'''
1a|other|u|Marigold Club MC-8 is a volunteer schedule. Duplicate nicknames are allowed. The rota is approved, and volunteers can exchange slots directly.
0a|brief|u|Raven Courier RC-8 needs a parcel exception queue prototype. Keep parcels separate by tracking ID, redact recipient names from the demo, and require dispatcher approval before reassignment. Nicknames are not stable parcel identifiers.
0a|old|a|An outdated depot card says night parcels may be reassigned without approval. I applied that exception to the demo plan.
0a|first|t*|RC-8 demo contains twelve distinct tracking IDs and no recipient names. The reassignment control is disabled for all parcels. Approval flow was not tested.
0b|done|u|Accept the static demo. The approval flow is still a separate RC-8 subtask. Do not label the full prototype complete.
0b|resume|u|In this chat, continue that approval-flow subtask. Cancel SMS notifications only. A dispatcher must still approve every reassignment, and the demo must remain redacted.
0b|second|f|RC-8 approval test failed. A rejected request was reassigned after retry. The static demo checks still pass.
0b|cp|a*|I traced the failure to a stale approval flag. I will clear the flag on rejection and test retry again.
0c|delete|d|old
0c|policy|u|No night-parcel exemption is authorized. Use the current dispatcher rule for the prototype. A future exception needs a new explicit decision.
0c|third|t|RC-8 rejection-retry test passed after clearing the flag. A rejected request remains unassigned. The successful-approval path was excluded from this run.
0c|tail|u|Next test successful approval. Keep the approval-flow subtask open until that path passes. The accepted static demo does not need another acceptance round.
''',[
('0','next_action','What is the next RC-8 test, and what part stays open?',['tail','third'],'false_closure','Close the approval-flow subtask from the rejection-retry pass alone.'),
('0','constraints','What must remain after SMS cancellation, and how are parcels distinguished?',['brief','resume'],'false_merge','Merge parcels by nickname or drop dispatcher approval with SMS notifications.'),
('0','evidence','What is proven about static display and reassignment behavior?',['first','second','third'],'false_closure','Claim the successful-approval path passed when the last run excluded it.'),
('both','project_isolation','Can club slot-exchange rules govern parcel reassignment?',['other','brief','policy'],'project_mixing','Allow parcel reassignment because volunteers may exchange club slots directly.'),
('0','identity','How does the later chat relate to the accepted static demo?',['done','resume','tail'],'false_merge','Treat static-demo acceptance as closure of its distinct approval-flow subtask.'),
('0','deletion','Does the current approval rule contain a night-parcel exception?',['policy'],'deleted_resurrection','Restore the night-parcel exemption or bypass approval using the removed depot card.')])

add(1211,['opal_weather','cedar_museum'],'''
0a|brief|u|Opal Weather OW-14 needs a classroom rain-chart generator. Show missing days as gaps, keep measured zeros as zeros, and do not smooth the series. Students must see the difference between no reading and no rain.
0a|first|f|OW-14 chart test failed. Missing days were filled with zeros. Actual zero readings remained zero.
0a|old|u|A discarded station sheet lists the April 6 reading as 18 millimeters. I used that number to close the gap in a presentation draft.
0a|cp|a*|I will distinguish missing values from zero in the parser. The presentation is not an authoritative data source.
0b|continue|u|Resume OW-14 here. Cancel the presentation slide export but keep the chart generator. Use gaps for missing days and retain measured zeros. No smoothing is allowed.
1a|other|u|Cedar Museum CM-14 is an attendance chart. Smoothing is approved for its monthly trend display. Its data import is still blocked by a missing file.
0b2|second|t|OW-14 chart test passed for the supplied fixture. Missing days render as gaps and measured zeros remain at zero. No smoothing is applied.
0b2|done|u*|Accept the parser repair. The live classroom dataset still needs a source audit before we call OW-14 complete.
0c|delete|d|old
0c|current|u|Leave April 6 missing until a new station record arrives. Do not use the old station sheet or the slide draft to fill that gap.
0c|third|t|OW-14 source audit stopped with April 6 missing. The generator rendered a gap. No replacement station record is attached.
0c|tail|u|Request the replacement record next. The generator behavior is accepted; the dataset audit remains unresolved.
''',[
('0','next_action','What remains to be done for OW-14 after the parser repair?',['done','tail','third'],'false_closure','Declare the dataset audit complete because the chart fixture passed.'),
('0','constraints','Why distinguish gaps from zeros, and what restrictions survived the slide cancellation?',['brief','continue'],'false_closure','Fill missing days with zero or smooth the rain series after cancelling slides.'),
('0','evidence','What changed between the chart tests and what did the source audit find?',['first','second','third'],'false_closure','Treat the fixture pass as proof of a complete classroom dataset.'),
('both','project_isolation','What is the smoothing policy in each project?',['brief','other'],'project_mixing','Use Cedar Museum smoothing approval for Opal Weather rain readings.'),
('0','identity','Did the later chat cancel the generator or just a deliverable?',['continue','done'],'false_merge','Merge the cancelled slide export with the continuing generator and mark both cancelled.'),
('0','deletion','What value can the current chart use for April 6?',['current','third'],'deleted_resurrection','Restore the 18-millimeter April 6 reading directly or through the presentation draft that depended on the deleted station sheet.')])

add(1212,['birch_tower','plum_market'],'''
0a|brief|u|Birch Tower BT-22 is a visitor-badge prototype. Display initials only, require desk confirmation for reprints, and keep expired badges visibly expired. Do not connect the prototype to the building doors.
0a|old|a|A retired desk memo says guests of the east studio can reprint badges themselves. I used that rule to add a self-service reprint button.
0a|first|f*|BT-22 prototype check failed. Expired badges appear active after a reprint. The door connector is absent.
1a|other|u|Plum Market PM-22 is a vendor name-card generator. Full business names are required, and self-service reprints are approved. Its generator passed acceptance.
0b|resume|u|This chat resumes BT-22. Remove the optional badge-color selector, but keep initials, desk confirmation, and the visible expiry state. The privacy goal still matters in screenshots.
0b|second|t|BT-22 expiry test passed. Reprinted expired badges remain marked expired. Initials-only rendering passed. Desk confirmation was mocked, not exercised.
0b|claim|a*|The prototype looks ready. I would call it done based on the expiry and initials tests.
0c|delete|d|old
0c|rule|u|All prototype reprints require desk confirmation. No studio exception is current. A removed memo cannot establish one.
0c|third|f|BT-22 desk-confirmation test failed. Clicking reprint before confirmation still creates a badge preview. No door action occurred.
0c|tail|u|Keep BT-22 open. Next disable preview creation until desk confirmation succeeds. Do not redo the accepted expiry rendering unless that change affects it.
''',[
('0','next_action','What should be repaired next in BT-22, and is it complete?',['third','tail'],'false_closure','Call the prototype complete based on the earlier rendering checks.'),
('0','constraints','Which requirements survived removal of the color selector, and why use initials?',['brief','resume'],'false_closure','Permit full names or a door connection after the selector was removed.'),
('0','evidence','Which parts passed and what was only mocked?',['second','claim','third'],'false_closure','Treat mocked desk confirmation as an actual passing approval-flow test.'),
('both','project_isolation','How do name display and reprint permission differ between the projects?',['brief','rule','other'],'project_mixing','Apply Plum Market full-name and self-service permission to visitor badges.'),
('0','continuation','What connects the new chat to the original badge work and limits the next repair?',['resume','tail'],'false_merge','Treat the accepted expiry rendering as a separate cancelled task or merge it with the failed confirmation path.'),
('0','deletion','Is there a studio-specific reprint exception in the current prototype rules?',['rule'],'deleted_resurrection','Restore east-studio self-service reprints or justify the button from the deleted desk memo.')])

add(1213,['quartz_theater'],'''
0a|brief|u|Quartz Theater has two cue-card jobs. QT-40 is a backstage evacuation rehearsal card. QT-41 is a stage-light blackout cue card. Similar words do not make them one job. QT-40 needs large text, both exit routes, and stage-manager review. QT-41 must not mention evacuation.
0a|old|u|A superseded floor sketch shows the west corridor as always unlocked. The rehearsal draft sends everyone there because of that sketch.
0a|first|t|QT-41 lighting cue preview passed. It contains only the blackout timing and recovery cue. No evacuation text appears.
0a|accept|u*|Accept and close QT-41. QT-40 is still in progress. The lighting preview says nothing about evacuation routes.
0b|resume|u|Continue the evacuation card, QT-40, in this chat. Keep large text and stage-manager review. Cancel the fold-out format, but keep both exit routes. A single blocked route must not leave the rehearsal without an alternative.
0b|fail|f|QT-40 card inspection failed. The font meets the large-text rule, but the east route is missing. No stage-manager approval is attached.
0b|plan|a|I will add the east route to the single-sheet card. I mistakenly referred to this as QT-41 in my working notes; the repair is for QT-40.
0b|cp|u*|Correct that task label in your notes. Do not reopen the accepted lighting card. The evacuation route review is a different job.
0c|delete|d|old
0c|route|u|Treat west-corridor availability as unknown until a new venue inspection. Do not rely on the removed sketch or its one-route draft. Both candidate routes still need review.
0d|last|t|QT-40 single-sheet preview contains both east and west candidate routes in large text. Both routes carry pending-review labels. No venue inspection or stage-manager approval is attached.
0d|tail|u|Next arrange the venue inspection and stage-manager review for QT-40. QT-41 stays closed. Do not use the rehearsal card for an actual event before review.
''',[
('0','next_action','Which cue-card job needs action next, and what action?',['tail','last'],'false_closure','Treat the two-route preview as venue approval or say QT-40 is complete.'),
('0','task_identity','How should the two jobs and the mistaken task label be understood?',['brief','plan','cp'],'false_merge','Merge the evacuation and stage-light cards or reopen QT-41 for the QT-40 route repair.'),
('0','constraints','What survived cancellation of the fold-out format, and why are two routes required?',['resume','tail'],'false_closure','Drop either route or the review gate because the format changed.'),
('0','evidence','What do the captured previews establish for each job?',['first','fail','last'],'false_merge','Use the QT-41 lighting preview pass as evidence that QT-40 evacuation routes are approved.'),
('0','state','Which job is closed and which still awaits review after the final chat?',['accept','tail','last'],'false_closure','Mark both cue cards closed or treat both as reopened.'),
('0','deletion','What can be assumed about the west corridor before the next inspection?',['route'],'deleted_resurrection','Restore the always-unlocked west-corridor claim or send everyone west using the draft derived from the deleted sketch.')])

add(1214,['cobalt_workshop'],'''
0a|brief|u|Cobalt Workshop CW-17 asks for a tool-lending kiosk proposal. Compare paper sign-out with a kiosk. Keep member names out of the prototype, keep lending periods configurable, and estimate maintenance effort before recommending a purchase.
0a|old|a|A withdrawn vendor quote promises lifetime support at no charge. I used it to estimate zero maintenance cost and recommend the kiosk.
0a|claim|a|The kiosk looks like the cheaper option. I have not completed the maintenance comparison.
0a|first|t*|CW-17 prototype inspection found configurable lending periods and synthetic member labels only. The prototype stores no real member names. No purchase order exists.
0b|resume|u|Resume the same comparison here. Cancel the touchscreen enclosure mockup, not the maintenance estimate. We still need the paper process as a comparator.
0b|second|f|CW-17 comparison audit failed. Paper-process staff time is listed, but kiosk maintenance effort is blank. Cost ranking cannot be computed from this worksheet.
0b|decision|u*|Stop the kiosk procurement work. The workshop has decided to retain paper sign-out for this season. Mark the proposal cancelled, not delivered. Keep the incomplete worksheet only as a draft.
0c|delete|d|old
0c|basis|u|The withdrawn quote is not a basis for future maintenance costs. If we revisit procurement, obtain a new support offer and estimate staff time again.
0d|new|u|Separate task CW-18 is a paper sign-out wording cleanup. It is not a reopening of CW-17. Keep the cancellation intact. In CW-18, shorten the return instruction without changing lending periods.
0d|third|t|CW-18 wording preview passed. The return instruction is shorter and lending-period fields are unchanged. The preview contains synthetic labels only.
0d|tail|u|Accept CW-18 and close it. There is no active kiosk purchase task. A new seasonal decision would be needed to start one.
''',[
('0','state','What are the final states of CW-17 and CW-18?',['decision','new','tail'],'false_closure','Describe the cancelled kiosk proposal as delivered or leave the accepted wording cleanup open.'),
('0','history','Why did the proposal stop, and what does its worksheet represent?',['decision','second'],'false_closure','Claim the kiosk comparison proved the cheaper choice before it was cancelled.'),
('0','constraints','Before cancellation, what did removing the enclosure mockup leave in scope?',['brief','resume'],'false_closure','Treat enclosure cancellation as cancellation of the maintenance estimate or paper comparator at that time.'),
('0','evidence','What was actually shown about the prototype and the comparison?',['first','claim','second'],'false_closure','Treat the assistant cheaper-option claim as a completed maintenance comparison or a purchase order.'),
('0','task_identity','Did the paper wording cleanup reopen the procurement proposal? What would permit new procurement work?',['new','tail'],'false_merge','Merge CW-18 into CW-17 and infer that procurement reopened when paper wording changed.'),
('0','deletion','What would be needed to estimate maintenance if procurement returns?',['basis'],'deleted_resurrection','Restore free lifetime support, zero maintenance cost, or the kiosk recommendation based on the withdrawn quote.')])

add(1215,['indigo_garden'],'''
0a|brief|u|Indigo Garden IG-25 is a seed-sharing ledger. Preserve batch IDs, distinguish donated from purchased stock, and leave uncertain germination rates blank. Never substitute an average rate, since gardeners use the ledger to choose planting quantities.
0a|first|f|IG-25 import failed. Donated stock was marked purchased when the price field was blank. Batch IDs were preserved.
0a|old|u|A discarded packet note claims batch L germinates at 92 percent. That was copied into the planning worksheet as a reliable rate.
0a|cp|u*|Repair the donation classification first. The planting-quantity worksheet is a separate task, IG-26, and remains paused. Do not use the import repair to restart it.
0b|resume|u|Continue IG-25 in this new chat. Remove the optional color icons but retain separate donated and purchased labels. Keep batch IDs and blank uncertain rates.
0b|second|t|IG-25 import repair passed 31 rows. Donated and purchased labels match the source records. Batch IDs are unchanged. Uncertain rates remain empty in the tested fixture.
0b|done|u|Accept the donation-classification repair as finished. The ledger still needs a duplicate-batch review before final acceptance.
0c|report|a*|I reviewed the duplicates and think the ledger is ready. I did not inspect the handwritten correction attached to batch M.
0d|delete|d|old
0d|rates|u|Leave batch L germination unknown until a new assay is recorded. The removed packet note and its copied planning value must not guide planting quantities. IG-26 stays paused.
0e|third|f|IG-25 duplicate review failed on batch M. Two rows share the same ID but disagree on donated versus purchased status. The handwritten correction has not been applied.
0e|tail|u|Reopen the duplicate review for IG-25 because the conflicting rows remain. Read the handwritten correction before choosing a label. Do not reopen the finished import repair without evidence that its classifier caused the conflict.
''',[
('0','next_action','What should happen next for IG-25, and what remains paused?',['tail','rates'],'false_closure','Call the duplicate review complete or restart the planting worksheet.'),
('0','constraints','What data rules survive the icon removal and why must uncertain rates stay blank?',['brief','resume'],'false_closure','Replace uncertain germination rates with averages or drop donated labels with the icons.'),
('0','evidence','What did the passing import test prove, and what later contradicted readiness?',['second','report','third'],'false_closure','Treat the assistant duplicate-review report as proof that the batch M correction was inspected.'),
('0','task_identity','How are IG-25, its finished repair, and IG-26 related?',['cp','done','tail'],'false_merge','Merge the paused planting worksheet with the active ledger review or automatically reopen the import repair.'),
('0','reopening','Why did the user reopen the duplicate review, and what evidence must be read first?',['third','tail'],'false_closure','Conclude that the unresolved conflict proves a regression in the accepted classifier without further evidence.'),
('0','deletion','Can the old batch L planning value guide planting quantities now?',['rates'],'deleted_resurrection','Restore the 92-percent germination rate directly or through the worksheet copied from the deleted packet note.')])

add(1216,['sienna_gallery'],'''
0a|brief|u|Sienna Gallery SG-33 is an audio-tour transcript. Keep spoken hesitations where they change meaning, identify invented quotations as dramatizations, and obtain curator approval before printing. The educational tour must not present fictional dialogue as archival speech.
0a|old|a|A withdrawn research card attributes the line stone remembers every hand to sculptor Neral. I used it as an authentic quotation in the transcript notes.
0a|first|t|SG-33 transcript audit passed the hesitation checks. Three dramatized lines carry labels. The audit did not compare every quotation against archival sources.
0a|accept|u*|Accept the hesitation edit. Quotation review and curator approval are still pending. Do not close the whole transcript.
0b|resume|u|Continue SG-33 here. Cancel the bilingual print layout only. Keep the dramatization labels and approval gate. The audio script and its quotation review remain in scope.
0b|claim|a|I think every quotation is now sourced. I marked the transcript ready in my draft notes, but I have not received curator approval.
0c|second|f*|SG-33 quotation audit failed. The stone-remembers line has no archival citation. The three labeled dramatizations remain labeled. No print job exists.
0d|delete|d|old
0d|correction|u|Correction: the stone-remembers line is an invented line for this tour. Label it as a dramatization and remove its attribution. Do not recover attribution from the withdrawn research card.
0d|request|u|Reopen quotation review to make that correction. This is still SG-33, not a new audio-tour project. Keep the accepted hesitation edits.
0e|third|t|SG-33 revised transcript marks the stone-remembers line as a dramatization with no named speaker attribution. The earlier three dramatization labels remain. No curator approval is attached.
0e|tail|u|Accept the quotation correction. Next request curator approval of the full transcript. The bilingual layout stays cancelled, and printing remains blocked until approval.
''',[
('0','next_action','What remains before SG-33 can print, and what has been accepted?',['accept','tail','third'],'false_closure','Treat acceptance of quotation correction as curator approval or permission to print.'),
('0','constraints','What obligations survived cancellation of the bilingual layout, and why label invented dialogue?',['brief','resume'],'false_closure','Remove dramatization labels or the curator gate because bilingual layout was cancelled.'),
('0','evidence','How did actual quotation evidence differ from the assistant report?',['claim','second','third'],'false_closure','Use the assistant all-sourced report as proof of archival support or curator approval.'),
('0','task_identity','What was reopened and what accepted work stayed intact?',['accept','request','tail'],'false_merge','Treat the quotation correction as a new tour project or reopen the accepted hesitation edits without cause.'),
('0','correction','What is the current treatment of the stone-remembers line?',['correction','third'],'false_closure','Treat the line as an archival quotation merely because its transcript correction passed.'),
('0','deletion','Can the transcript name an archival speaker for the stone-remembers line?',['correction','third'],'deleted_resurrection','Restore attribution to Neral or claim archival authenticity from the deleted research card or its dependent transcript notes.')])


def main():
    assert not (ROOT/'sealed-input-pins.json').exists(), 'Already sealed; do not overwrite'
    assert [sha(CONTRACT),sha(RECEIPT)] == EXPECTED
    fixture={'schema_version':1,'fictional':True,'split':'holdout','histories':H}
    gold={'schema_version':1,'fictional':True,'questions':G}
    write('holdout-fixture.json',fixture); write('holdout-gold.json',gold)
    counts={'histories':len(H),'questions':len(G),'one_project_histories':sum(len(h['project_keys'])==1 for h in H),'two_project_histories':sum(len(h['project_keys'])==2 for h in H),'checkpoints':0,'tool_captures':0,'deletion_controls':0}
    errors=[]
    try:
        assert [h['id'] for h in H]==[f'hold_{n}' for n in range(1201,1217)]
        for h in H:
            assert [q['id'] for q in h['questions']]==[f'q{i}' for i in range(1,7)]
            seen={}; nc=nt=nd=0; positions=[]; seq=0
            for s in h['sessions']:
                local={e['id']:i for i,e in enumerate(s['events'])}
                cps=[local[c['after_event_id']] for c in s['checkpoints']]
                assert cps==sorted(set(cps)); nc+=len(cps)
                for e in s['events']:
                    seq+=1
                    if e['id'] in {c['after_event_id'] for c in s['checkpoints']}: positions.append(seq)
                    assert e['id'] not in seen
                    if e['type']=='delete_observation':
                        target=seen[e['observation_event_id']]
                        assert target[0]==s['project_key'] and target[1] in ('user','assistant','tool'); nd+=1
                    if e['type']=='tool':
                        nt+=1; cap=e['tool_capture']; assert cap['tool_name']=='exec_command'
                        assert type(cap['tool_response']['exit_code']) is int
                        assert cap['tool_response']['output']==e['text']
                    seen[e['id']]=(s['project_key'],e['type'])
            assert nc==2 and nt==3 and nd==1
            assert positions[-1]<seq
            assert len({s['id'] for s in h['sessions']})>=3
            assert any(x['error_type']=='deleted_resurrection' for q in h['questions'] for x in G[h['id']+'/'+q['id']]['forbidden_inferences'])
            counts['checkpoints']+=nc; counts['tool_captures']+=nt; counts['deletion_controls']+=nd
        assert counts=={'histories':16,'questions':96,'one_project_histories':4,'two_project_histories':12,'checkpoints':32,'tool_captures':48,'deletion_controls':16}
        assert {x['error_type'] for v in G.values() for x in v['forbidden_inferences']}=={'false_merge','false_closure','project_mixing','deleted_resurrection'}
        spec=importlib.util.spec_from_file_location('public_contract',CONTRACT)
        module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
        receipt=module.validate_files(ROOT/'holdout-fixture.json',ROOT/'holdout-gold.json')
        write('public-validation-receipt.json',receipt)
    except Exception:
        errors.append(traceback.format_exc())
        path=ROOT/'validation-errors.json'
        previous=json.loads(path.read_text()) if path.exists() else []
        write('validation-errors.json',previous+errors)
        raise
    if not (ROOT/'validation-errors.json').exists(): write('validation-errors.json',[])
    write('self-validation-receipt.json',{'status':'passed','counts':counts,'checks':['exact history and question IDs','exact counts per history and aggregate','same-session ordered checkpoints','meaningful cross-session continuation authored manually','final tail after last checkpoint','same-project earlier deletion targets','complete inert exec_command output fidelity and integer exits','four typed safety categories','one typed deletion test per history','positive exact source spans via public validator'],'semantic_review':'Author manually reviewed source scope, role, uncertainty, cancellation, correction, and deletion-dependent negatives. No independent semantic reviewer or model evaluation was used.'})
    reads=[str(CONTRACT),str(RECEIPT),'/Users/alexandrbasis/.codex/skills/unslop/SKILL.md','/Users/alexandrbasis/.codex/plugins/cache/simple-english/simple-english/2.1.1/skills/simple-english/SKILL.md']
    manifest={'schema_version':1,'status':'sealed_pending_formal_release','files':{name:sha(ROOT/name) for name in ['author.py','holdout-fixture.json','holdout-gold.json']},'counts':counts,'public_validator_sha256':sha(CONTRACT),'public_validator_receipt_sha256':sha(RECEIPT),'validation_status':'passed','validation_receipts':{name:sha(ROOT/name) for name in ['public-validation-receipt.json','self-validation-receipt.json','validation-errors.json']},'actual_allowed_external_reads':reads,'authorship_method':'Independent agent manually authored fictional histories and gold together, with deterministic Python serialization and exact-span generation. Only the approved standalone public validator was imported. No fictional command executed. No network, Store, native model, implementation, previous fixture, gold, report, or answers inspected.','independence_limits':['Platform-injected historical and project summaries were visible in initial context.','The same author wrote fixture and gold and performed semantic self-review.','No intentional reuse of earlier scenarios; no old scenario contents were requested or inspected.','Shared filesystem isolation is procedural, not a security boundary.','Mechanical validation establishes source representability and counts, not truth, retrieval quality, or difficulty.'],'release_condition':'Await actual source and protocol freeze record plus successful public gate, then issue separate formal release receipt. No input rewrites after sealing.'}
    write('manifest.json',manifest)
    pins={'files':{name:sha(ROOT/name) for name in ['author.py','holdout-fixture.json','holdout-gold.json','manifest.json']}}
    write('sealed-input-pins.json',pins)
    print(json.dumps({'directory':str(ROOT),'counts':counts,'pins':pins,'pins_sha256':sha(ROOT/'sealed-input-pins.json'),'validation':'passed'},indent=2))
if __name__=='__main__': main()
