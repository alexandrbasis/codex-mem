from pathlib import Path
import json,importlib.util,traceback,hashlib
r=Path('/private/tmp/codex-mem-quality-20261021-r20-sealed');p=Path('/private/tmp/codex-mem-quality-20261021-r20-author-pack')
def load(n):return json.loads((r/n).read_text())
def new(n,v):
 with (r/n).open('x') as f:json.dump(v,f,ensure_ascii=False,indent=2);f.write('\n')
fixture=load('holdout-fixture.v001.json');gold=load('holdout-gold.v001.json');rationale=load('author-fact-rationale.v001.json')
events={h['id']:{e['id']:e for s in h['sessions'] for e in s['events']} for h in fixture['histories']}
def fact(case,prop,eid,quote):
 text=events[case.split('/')[0]][eid]['text'];start=text.index(quote)
 return {'text':prop,'support':[{'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote}]}
changes={
'h03/q4':[(0,[('What did the assistant report doing with episode two','The assistant reported exporting a preview of Copper episode two.','e6','I exported a preview of Copper episode two.'),('What did the assistant report doing with episode two','The assistant reported that it did not release Copper episode two.','e6','I did not release it.')])],
'h06/q4':[(1,[('what did the later bench observation show','The bench observation showed that the clear-guard latch was open.','e10','Bench observation: clear guard latch open'),('what did the later bench observation show','The bench observation showed a stationary fan.','e10','fan stationary.')])],
'h13/q3':[(0,[('What reopened the puppet repair','The puppet repair was reopened to loosen its left wrist.','e9','Reopen the puppet repair to loosen its left wrist'),('What reopened the puppet repair','The puppet repair was reopened because the puppet could not hold the cup.','e9','because it cannot hold the cup.')])],
'h14/q3':[(0,[('Is the scale-bar correction open again','The scale-bar correction remains closed.','e11','The scale-bar correction remains closed')])],
'h06/q3':[(0,[('What is the latest accepted hull state','Hull sealing remains accepted and must not reopen.','e11','Do not reopen hull sealing. It remains accepted')])]
}
rr={x['case']:x for x in rationale['questions']}
for case,edits in changes.items():
 for index,replacements in sorted(edits,reverse=True):
  fs=[fact(case,prop,eid,quote) for clause,prop,eid,quote in replacements]
  gold['questions'][case]['required_facts'][index:index+1]=fs
  rs=[]
  for (clause,prop,eid,quote),ff in zip(replacements,fs):
   rs.append({'fact_index':0,'question_clause':clause,'proposition':prop,'support':ff['support'],'needed_context':'Source role and session project establish attribution and scope. Pronouns refer to the named subject in the same source event. The quote retains only the requested proposition.'})
  rr[case]['required_facts'][index:index+1]=rs
 for i,row in enumerate(rr[case]['required_facts']):row['fact_index']=i
rationale['version']='v002'
rationale['revision_note']='Independent review requested three conjunction splits and two shorter anchors. v001 and its review are preserved. No case or required meaning was removed.'
new('holdout-fixture.v002.json',fixture);new('holdout-gold.v002.json',gold);new('author-fact-rationale.v002.json',rationale)
sp=importlib.util.spec_from_file_location('sealed_public_contract',p/'public-fixture-contract.py');m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
try:result=m.validate_files(r/'holdout-fixture.v002.json',r/'holdout-gold.v002.json')
except Exception:
 with (r/'validation-v002-failed.txt').open('x') as f:f.write(traceback.format_exc())
 raise
new('mechanical-validation.v002.json',result)
for stem in ['holdout-fixture','holdout-gold','author-fact-rationale']:
 (r/(stem+'.json')).write_bytes((r/(stem+'.v002.json')).read_bytes())
new('revision-log.v002.json',{'version':'v002','parent_version':'v001','trigger':'Independent sealed reviewer identified five semantic findings before trial freeze and before product or answer exposure.','resolved_finding_count':5,'changes':changes,'mechanical_status':result['status'],'failed_validation_attempts':0,'release_authorized':False})
print(json.dumps({'status':result['status'],'histories':len(fixture['histories']),'questions':len(gold['questions']),'required_facts':sum(len(x['required_facts']) for x in gold['questions'].values()),'positive_anchors':result['positive_anchors'],'pins':{stem+'.json':hashlib.sha256((r/(stem+'.json')).read_bytes()).hexdigest() for stem in ['holdout-fixture','holdout-gold','author-fact-rationale']}},indent=2))
