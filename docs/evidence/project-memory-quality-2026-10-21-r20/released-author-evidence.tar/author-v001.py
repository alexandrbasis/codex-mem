from pathlib import Path
import json, hashlib, importlib.util, traceback
ROOT=Path('/private/tmp/codex-mem-quality-20261021-r20-sealed')
PACK=Path('/private/tmp/codex-mem-quality-20261021-r20-author-pack')
# Each source below is newly authored fiction. No external corpus is used.
H=[]; G={}; R=[]
def history(n, events, questions, checkpoints):
    hid=f'h{n:02d}'; pa=f'p{n:02d}a'; pb=f'p{n:02d}b'
    sources={}; sessions=[]
    for si,(project,rows) in enumerate(events,1):
        evs=[]
        for eid,role,body in rows:
            e={'id':eid,'type':role,'text':body}
            if role=='delete_observation': e['observation_event_id']=body; e['text']='Remove the named source observation.'
            if role=='tool': e['tool_capture']={'tool_name':'exec_command','tool_input':{'command':f'fictional-inspector --record {eid}'},'tool_response':{'output':body,'exit_code':0}}
            evs.append(e); sources[eid]=e
        sessions.append({'id':f'{hid}s{si}','project_key':pa if project=='a' else pb,'events':evs,'checkpoints':[{'after_event_id':x} for x in checkpoints.get(si,[])]})
    qs=[]
    for qi,(prompt,scope,category,facts,negatives,background) in enumerate(questions,1):
        qid=f'q{qi}'; case=f'{hid}/{qid}'; q={'id':qid,'question':prompt,'stage':'final'}
        q.update({'project_keys':[pa,pb]} if scope=='both' else {'project_key':pa if scope=='a' else pb})
        qs.append(q); goldfacts=[]; rationales=[]
        for fi,(clause,proposition,anchors) in enumerate(facts):
            support=[]
            for eid,quote in anchors:
                body=sources[eid]['text']; start=body.index(quote)
                support.append({'event_id':eid,'source_field':'body','start':start,'end':start+len(quote),'quote':quote})
            goldfacts.append({'text':proposition,'support':support})
            rationales.append({'fact_index':fi,'question_clause':clause,'proposition':proposition,'support':support,'needed_context':'The source role and session project identify attribution and scope. Quoted conditions and time words are retained where the proposition depends on them.'})
        G[case]={'category':category,'required_facts':goldfacts,'forbidden_conclusions':[t for _,t in negatives],'forbidden_inferences':[{'error_type':k,'text':t} for k,t in negatives]}
        R.append({'case':case,'question':prompt,'required_facts':rationales,'optional_background':background})
    H.append({'id':hid,'project_keys':[pa,pb],'sessions':sessions,'questions':qs})
def f(clause,prop,eid,quote): return (clause,prop,[(eid,quote)])

history(1,[('a',[
('e1','user','For the Lantern exhibit, print the large labels only after Mira approves the contrast sample. The sample gate is required because the hall lighting is dim.'),
('e2','user','Make a floor guide and an audio guide as separate deliverables.'),
('e3','assistant','I finished the floor guide draft. I think the audio guide can be called finished too.'),
('e4','user','Accept the floor guide and close that task. Cancel the audio narration recording, but keep the audio script review open.'),
('e5','tool','Temporary delivery note: the label courier is Nilo.')]),('b',[
('e6','user','For the Harbor exhibit, Tess can approve label printing. This authority applies only to Harbor.')]),('a',[
('e7','delete_observation','e5'),
('e8','user','For Lantern deliveries, use the coordinator named in the signed dispatch sheet.'),
('e9','user','Reopen the floor guide to correct the west-door arrow. Keep the already accepted room names.'),
('e10','tool','Floor guide file inspection: west-door arrow still points east.')])],[
('What must happen before Lantern labels can be printed, and why is that gate required?','a','conditional_requirement',[f('What must happen','Lantern label printing requires Mira to approve the contrast sample.','e1','print the large labels only after Mira approves the contrast sample.'),f('why','The sample gate is required because the hall lighting is dim.','e1','The sample gate is required because the hall lighting is dim.')],[],['Label size is incidental to this question.']),
('Which audio-guide work was canceled, and which work remains open?','a','partial_cancellation',[f('was canceled','Audio narration recording was canceled.','e4','Cancel the audio narration recording'),f('remains open','Audio script review remains open.','e4','keep the audio script review open.')],[('false_closure','The entire audio guide is complete or canceled.')],[]),
('What is the floor guide task now, and what accepted content must stay?','a','reopening',[f('task now','The floor guide is reopened to correct the west-door arrow.','e9','Reopen the floor guide to correct the west-door arrow.'),f('must stay','The accepted room names must stay.','e9','Keep the already accepted room names.')],[('false_closure','The floor guide is still closed.')],[]),
('Did the floor-guide acceptance also accept the audio guide? What did the assistant claim?','a','source_roles',[f('Did ... also accept','The deliverables are separate, so floor-guide acceptance does not accept the audio guide.','e2','Make a floor guide and an audio guide as separate deliverables.'),f('assistant claim','The assistant said it thought the audio guide could be called finished.','e3','I think the audio guide can be called finished too.')],[('false_merge','Floor-guide acceptance establishes audio-guide completion.')],['The audio scope was later narrowed.']),
('Who approves label printing for Lantern, and who has that authority for Harbor?','both','project_isolation',[f('for Lantern','Lantern requires Mira to approve the contrast sample before printing.','e1','print the large labels only after Mira approves the contrast sample.'),f('for Harbor','Tess can approve printing for Harbor only.','e6','For the Harbor exhibit, Tess can approve label printing. This authority applies only to Harbor.')],[('project_mixing','Tess can approve Lantern printing.')],[]),
('Which surviving rule determines the Lantern delivery coordinator?','a','deletion',[f('surviving rule','Use the coordinator named in the signed dispatch sheet for Lantern deliveries.','e8','For Lantern deliveries, use the coordinator named in the signed dispatch sheet.')],[('deleted_resurrection','Nilo is the current Lantern courier based on the removed delivery note.')],[])],{1:['e2','e5'],3:['e8']})

history(2,[('a',[
('e1','user','For the Alder seed trial, water plot C only if the morning sensor reads below 18 percent. This avoids washing seeds out of saturated soil.'),
('e2','tool','Trial ledger: plot C watering is pending; shade-frame repair is pending.'),
('e3','assistant','The shade frame looks repaired to me, so I assume watering is done as well.'),
('e4','user','I inspected and accepted the shade-frame repair. Close that repair. Watering is a separate task and remains pending.'),
('e5','user','The provisional seed supplier is Vela Nursery.')]),('a',[
('e6','delete_observation','e5'),
('e7','user','Use only the supplier on the current purchase order for the Alder seed trial.'),
('e8','user','Cancel the afternoon moisture reading. Keep the morning reading, because it controls whether plot C is watered.'),
('e9','tool','Morning sensor record: plot C moisture 21 percent.')]),('b',[
('e10','user','For the Birch seed trial, water plot C every morning. Birch does not use the Alder moisture gate.')])],[
('Under what condition may plot C be watered in Alder, and what is the reason?','a','conditional_requirement',[f('condition','Alder plot C may be watered only when the morning sensor reads below 18 percent.','e1','water plot C only if the morning sensor reads below 18 percent.'),f('reason','The condition avoids washing seeds out of saturated soil.','e1','This avoids washing seeds out of saturated soil.')],[],[]),
('After the schedule change, which moisture reading remains and why?','a','partial_cancellation',[f('which ... remains','The morning moisture reading remains required.','e8','Keep the morning reading'),f('why','The morning reading controls whether plot C is watered.','e8','because it controls whether plot C is watered.')],[],['The afternoon reading was canceled.']),
('What is the accepted state of the shade-frame repair, and what is the watering task state?','a','genuine_closure',[f('repair','The user accepted and closed the shade-frame repair.','e4','I inspected and accepted the shade-frame repair. Close that repair.'),f('watering','Watering is separate and remains pending.','e4','Watering is a separate task and remains pending.')],[('false_merge','Accepting the shade-frame repair completes watering.'),('false_closure','Watering is complete.')],[]),
('What did the assistant infer about watering, and what did the morning sensor actually record?','a','source_roles',[f('assistant infer','The assistant assumed watering was done because the shade frame looked repaired.','e3','The shade frame looks repaired to me, so I assume watering is done as well.'),f('sensor ... record','The tool recorded plot C moisture at 21 percent.','e9','Morning sensor record: plot C moisture 21 percent.')],[('false_closure','The assistant assumption proves that watering occurred.')],[]),
('How do the watering instructions for plot C differ between Alder and Birch?','both','project_isolation',[f('Alder','Alder permits watering only below 18 percent on the morning sensor.','e1','water plot C only if the morning sensor reads below 18 percent.'),f('Birch','Birch requires watering every morning without the Alder gate.','e10','For the Birch seed trial, water plot C every morning. Birch does not use the Alder moisture gate.')],[('project_mixing','Alder plot C must be watered every morning regardless of moisture.')],[]),
('What is the current source of authority for choosing the Alder seed supplier?','a','deletion',[f('source of authority','The current purchase order determines the Alder supplier.','e7','Use only the supplier on the current purchase order for the Alder seed trial.')],[('deleted_resurrection','Vela Nursery is the authorized supplier based on the deleted provisional source.')],[])],{1:['e4'],2:['e8']})

history(3,[('a',[
('e1','user','For the Copper radio play, release episode two only when both actors sign the voice-use form. We need both signatures because the episode includes both performances.'),
('e2','user','Treat the music cue sheet and dialogue edit as separate tasks.'),
('e3','user','The dialogue edit is accepted and closed. The music cue sheet is still under review.'),
('e4','tool','Unconfirmed contact card: rights reviewer is Oren.')]),('b',[
('e5','user','For the Silver radio play, the producer alone approves release. Actor signatures are already covered by its standing agreement.')]),('a',[
('e6','assistant','I exported a preview of Copper episode two. I did not release it.'),
('e7','delete_observation','e4'),
('e8','user','Route Copper rights questions to the reviewer listed in the active rights register.'),
('e9','user','Reopen the dialogue edit because the final line names the wrong station. Fix only that station name.'),
('e10','user','Drop the optional flute cue from the cue sheet, but finish checking the drum cue.'),
('e11','tool','Export folder contains preview-02.wav; publication receipt field is empty.')])],[
('What signatures does Copper episode two need before release, and why?','a','conditional_requirement',[f('What signatures','Both actors must sign the voice-use form before Copper episode two is released.','e1','release episode two only when both actors sign the voice-use form.'),f('why','Both signatures are needed because the episode includes both performances.','e1','We need both signatures because the episode includes both performances.')],[],[]),
('Which music-cue work remains after the scope change?','a','partial_cancellation',[f('remains','Checking the drum cue remains required.','e10','finish checking the drum cue.')],[('false_closure','All music-cue work was canceled.')],['The optional flute cue was dropped.']),
('Why was the dialogue edit reopened, and how far should the correction go?','a','reopening',[f('Why','The dialogue edit was reopened because its final line names the wrong station.','e9','Reopen the dialogue edit because the final line names the wrong station.'),f('how far','Only that station name must be fixed.','e9','Fix only that station name.')],[('false_closure','The dialogue edit remains closed.')],[]),
('What did the assistant report doing with episode two, and does the cue-sheet review count as dialogue acceptance?','a','source_roles',[f('report doing','The assistant reported exporting a preview and not releasing it.','e6','I exported a preview of Copper episode two. I did not release it.'),f('does ... count','The cue sheet and dialogue edit are separate tasks, so cue-sheet review does not accept dialogue.','e2','Treat the music cue sheet and dialogue edit as separate tasks.')],[('false_merge','Cue-sheet review accepts the dialogue edit.'),('false_closure','Copper episode two was released.')],['The export-folder record is corroborating background.']),
('Can the producer-alone release rule from Silver be used for Copper? State each project rule.','both','project_isolation',[f('Copper','Copper requires both actors to sign the voice-use form before release.','e1','release episode two only when both actors sign the voice-use form.'),f('Silver','Silver allows its producer alone to approve release.','e5','For the Silver radio play, the producer alone approves release.')],[('project_mixing','Producer approval alone authorizes Copper release.')],['The reason for Silver\'s different rule is optional here.']),
('Where should Copper rights questions be routed now?','a','deletion',[f('Where','To the reviewer listed in the active rights register.','e8','Route Copper rights questions to the reviewer listed in the active rights register.')],[('deleted_resurrection','Oren is the current rights reviewer based on the removed contact card.')],[])],{1:['e3'],3:['e8','e10']})

history(4,[('a',[
('e1','user','For the Meadow footbridge survey, enter the east bank only after the ranger confirms that nesting has ended. Keep that restriction because survey traffic disturbs the birds.'),
('e2','assistant','I completed the west-bank measurements. I would mark the whole survey complete.'),
('e3','user','Accept and close the west-bank measurements only. The east-bank visit is blocked by the nesting restriction.'),
('e4','tool','Draft route card: meeting point is Red Mill.')]),('a',[
('e5','user','Cancel the drone photography. The hand-drawn bank sketch is still needed.'),
('e6','delete_observation','e4'),
('e7','user','Take the meeting point from the ranger\'s dated visit permit.'),
('e8','tool','Permit inspection: east-bank access is not authorized yet.'),
('e9','user','Keep the west-bank measurements closed. Do not reopen them just because the east-bank visit is pending.')]),('b',[
('e10','user','For the Ridge culvert survey, east-bank access needs the landowner\'s permission, not a ranger nesting confirmation.')])],[
('What controls entry to Meadow\'s east bank, and why?','a','conditional_requirement',[f('What controls','The ranger must confirm nesting has ended before east-bank entry.','e1','enter the east bank only after the ranger confirms that nesting has ended.'),f('why','Survey traffic disturbs the birds.','e1','Keep that restriction because survey traffic disturbs the birds.')],[],[]),
('What visual record is still required after photography was canceled?','a','partial_cancellation',[f('still required','The hand-drawn bank sketch is still required.','e5','The hand-drawn bank sketch is still needed.')],[('false_closure','All visual records were canceled.')],[]),
('Are the west-bank measurements open again, and what is the east-bank access state?','a','genuine_closure',[f('west-bank','The west-bank measurements remain closed.','e9','Keep the west-bank measurements closed.'),f('east-bank access','The inspected permit does not yet authorize east-bank access.','e8','Permit inspection: east-bank access is not authorized yet.')],[('false_merge','The pending east-bank visit reopens the west-bank measurement task.'),('false_closure','The east-bank visit is complete.')],[]),
('How did the user limit the assistant\'s suggested survey completion?','a','source_roles',[f('assistant ... suggested','The assistant suggested marking the whole survey complete after west-bank measurements.','e2','I completed the west-bank measurements. I would mark the whole survey complete.'),f('user limit','The user accepted and closed only the west-bank measurements.','e3','Accept and close the west-bank measurements only.')],[('false_closure','The user accepted the entire survey as complete.')],['The east-bank blocking reason is asked separately.']),
('Which permission applies to east-bank entry in Meadow versus Ridge?','both','project_isolation',[f('Meadow','Meadow requires ranger confirmation that nesting ended.','e1','enter the east bank only after the ranger confirms that nesting has ended.'),f('Ridge','Ridge requires landowner permission.','e10','For the Ridge culvert survey, east-bank access needs the landowner\'s permission, not a ranger nesting confirmation.')],[('project_mixing','Landowner permission alone satisfies Meadow\'s entry requirement.')],[]),
('Which surviving instruction identifies the survey meeting point?','a','deletion',[f('instruction','Use the meeting point on the ranger\'s dated visit permit.','e7','Take the meeting point from the ranger\'s dated visit permit.')],[('deleted_resurrection','Red Mill remains the meeting point based on the deleted route card.')],[])],{1:['e3'],2:['e7']})

history(5,[('a',[
('e1','user','In the Juniper costume workshop, cut the velvet only after Sada signs the paper pattern. Velvet is scarce, so we cannot replace a mistaken cut.'),
('e2','user','The cape pattern and coat pattern are separate orders.'),
('e3','tool','Work board: cape pattern accepted; coat pattern awaiting fitting.'),
('e4','user','I accept the cape pattern and close it.'),
('e5','assistant','Since the cape is accepted, I think the coat can skip its fitting.'),
('e6','tool','Old stock note: reserve roll is stored in cupboard nine.')]),('b',[
('e7','user','In the Marigold workshop, Ivo signs paper patterns. That appointment covers Marigold only.')]),('a',[
('e8','delete_observation','e6'),
('e9','user','Find the reserve roll using the current stock ledger.'),
('e10','user','Reopen the cape pattern for a shorter collar, because the actor cannot turn their head. Do not change its hem.'),
('e11','user','Cancel the coat\'s silver trim. Keep its fitting on the task list.')])],[
('Who must authorize Juniper velvet cutting, and why is prior authorization necessary?','a','conditional_requirement',[f('Who','Sada must sign the paper pattern before Juniper velvet is cut.','e1','cut the velvet only after Sada signs the paper pattern.'),f('why','Velvet is scarce and a mistaken cut cannot be replaced.','e1','Velvet is scarce, so we cannot replace a mistaken cut.')],[],[]),
('What coat work was removed, and what is still on the task list?','a','partial_cancellation',[f('removed','The coat\'s silver trim was canceled.','e11','Cancel the coat\'s silver trim.'),f('still','The coat fitting remains on the task list.','e11','Keep its fitting on the task list.')],[('false_closure','The coat order is fully canceled.')],[]),
('What change reopened the cape pattern, why, and what must remain unchanged?','a','reopening',[f('What change','The cape pattern is reopened for a shorter collar.','e10','Reopen the cape pattern for a shorter collar'),f('why','The actor cannot turn their head.','e10','because the actor cannot turn their head.'),f('unchanged','The cape hem must not change.','e10','Do not change its hem.')],[('false_closure','The cape pattern remains closed.')],[]),
('Did accepting the cape authorize skipping the coat fitting, or was that only the assistant\'s view?','a','source_roles',[f('only ... view','The assistant thought cape acceptance meant the coat could skip fitting.','e5','Since the cape is accepted, I think the coat can skip its fitting.'),f('authorize skipping','The user still requires the coat fitting.','e11','Keep its fitting on the task list.')],[('false_merge','Cape acceptance authorizes skipping the separate coat fitting.')],['The separate-order instruction corroborates task separation.']),
('Who signs patterns in Juniper and in Marigold?','both','project_isolation',[f('Juniper','Sada signs the Juniper paper pattern before cutting.','e1','cut the velvet only after Sada signs the paper pattern.'),f('Marigold','Ivo signs paper patterns for Marigold only.','e7','In the Marigold workshop, Ivo signs paper patterns. That appointment covers Marigold only.')],[('project_mixing','Ivo is authorized to sign Juniper patterns.')],[]),
('How should the reserve roll be located now?','a','deletion',[f('How','Use the current stock ledger to find the reserve roll.','e9','Find the reserve roll using the current stock ledger.')],[('deleted_resurrection','The reserve roll is in cupboard nine based on the removed stock note.')],[])],{1:['e4','e6'],3:['e9']})

history(6,[('a',[
('e1','user','For the Pebble ferry model, run the fan test only with the clear guard latched. The guard keeps loose rigging away from the fan blades.'),
('e2','user','Hull sealing and fan testing are independent acceptance tasks.'),
('e3','assistant','I sealed the hull. I assume the model is ready to sail.'),
('e4','user','Hull sealing passed my inspection and is closed. Fan testing remains unstarted.'),
('e5','tool','Temporary test plan: use battery pack K4.')]),('b',[
('e6','user','For the Slate ferry model, use a mesh fan guard. The clear guard rule belongs to Pebble.')]),('a',[
('e7','user','Cancel painting the display stand. Still attach the model\'s identification plate.'),
('e8','delete_observation','e5'),
('e9','user','Choose the test battery from the approved power list.'),
('e10','tool','Bench observation: clear guard latch open; fan stationary.'),
('e11','user','Do not reopen hull sealing. It remains accepted while we wait for fan testing.')])],[
('What must be true before Pebble\'s fan test, and what hazard does the rule address?','a','conditional_requirement',[f('What must be true','Pebble\'s clear fan guard must be latched before the fan test.','e1','run the fan test only with the clear guard latched.'),f('hazard','The guard keeps loose rigging away from fan blades.','e1','The guard keeps loose rigging away from the fan blades.')],[],[]),
('Which display-stand job was canceled, and which identification job remains?','a','partial_cancellation',[f('canceled','Painting the display stand was canceled.','e7','Cancel painting the display stand.'),f('remains','The model\'s identification plate must still be attached.','e7','Still attach the model\'s identification plate.')],[],[]),
('What is the latest accepted hull state, and what is the stated fan-testing task state?','a','genuine_closure',[f('hull state','Hull sealing remains accepted and must not reopen.','e11','Do not reopen hull sealing. It remains accepted while we wait for fan testing.'),f('fan-testing task state','Fan testing remains unstarted.','e4','Fan testing remains unstarted.')],[('false_closure','Fan testing is complete.'),('false_merge','Waiting for fan testing reopens hull sealing.')],[]),
('What readiness did the assistant assume, and what did the later bench observation show?','a','source_roles',[f('assistant assume','The assistant assumed the model was ready to sail after sealing the hull.','e3','I sealed the hull. I assume the model is ready to sail.'),f('observation show','The bench observation showed an open clear-guard latch and a stationary fan.','e10','Bench observation: clear guard latch open; fan stationary.')],[('false_closure','The model\'s readiness to sail is established by the assistant assumption.')],[]),
('Which fan guard is specified for each ferry model?','both','project_isolation',[f('Pebble','Pebble specifies a clear guard that must be latched for testing.','e1','run the fan test only with the clear guard latched.'),f('Slate','Slate specifies a mesh fan guard.','e6','For the Slate ferry model, use a mesh fan guard.')],[('project_mixing','A mesh guard is the specified Pebble guard.')],[]),
('What should determine the battery used for the test?','a','deletion',[f('What','The approved power list must determine the test battery.','e9','Choose the test battery from the approved power list.')],[('deleted_resurrection','Battery pack K4 is the approved choice based on the deleted plan.')],[])],{1:['e4'],3:['e9']})

history(7,[('a',[
('e1','user','For the Willow oral-history collection, publish a transcript only after its speaker approves the redactions. Speakers need this control because a recording can mention neighbors.'),
('e2','user','The transcript cleanup and consent review are separate tasks.'),
('e3','user','Accept the cleanup of interview seven. Close cleanup, but keep consent review open.'),
('e4','assistant','I believe the interview can go online now that cleanup is accepted.'),
('e5','tool','Early catalog note: interview seven belongs in shelf group D.')]),('a',[
('e6','delete_observation','e5'),
('e7','user','Use the signed catalog allocation sheet to select the shelf group.'),
('e8','user','Reopen cleanup of interview seven to restore a missing pause marker. Keep the speaker\'s wording exactly as accepted.'),
('e9','user','Cancel the short promotional excerpt. Continue the full transcript consent review.'),
('e10','tool','Consent register: interview seven redaction approval pending.')]),('b',[
('e11','user','For the Ash oral-history collection, the archive editor approves redactions under its donated-rights agreement.')])],[
('Whose approval is needed before a Willow transcript is published, and why is that control required?','a','conditional_requirement',[f('Whose approval','The speaker must approve redactions before a Willow transcript is published.','e1','publish a transcript only after its speaker approves the redactions.'),f('why','A recording can mention neighbors, so speakers need this control.','e1','Speakers need this control because a recording can mention neighbors.')],[],[]),
('What remains in scope after the promotional excerpt was canceled?','a','partial_cancellation',[f('remains','The full transcript consent review continues.','e9','Continue the full transcript consent review.')],[('false_closure','Canceling the excerpt cancels consent review.')],[]),
('What does the reopened cleanup require, and what text must it preserve?','a','reopening',[f('require','Cleanup of interview seven is reopened to restore a missing pause marker.','e8','Reopen cleanup of interview seven to restore a missing pause marker.'),f('preserve','The speaker\'s wording must stay exactly as accepted.','e8','Keep the speaker\'s wording exactly as accepted.')],[('false_closure','Interview seven cleanup remains closed.')],[]),
('Was publication readiness the assistant\'s belief or an approved consent state? What does the register say?','a','source_roles',[f('assistant ... belief','The assistant believed cleanup acceptance meant the interview could go online.','e4','I believe the interview can go online now that cleanup is accepted.'),f('register','The consent register records interview seven redaction approval as pending.','e10','Consent register: interview seven redaction approval pending.')],[('false_merge','Cleanup acceptance is consent approval.'),('false_closure','Interview seven consent approval is complete.')],[]),
('Who approves redactions in Willow and in Ash?','both','project_isolation',[f('Willow','Willow requires the speaker to approve redactions.','e1','publish a transcript only after its speaker approves the redactions.'),f('Ash','Ash uses archive-editor approval under its donated-rights agreement.','e11','For the Ash oral-history collection, the archive editor approves redactions under its donated-rights agreement.')],[('project_mixing','Willow can substitute archive-editor approval for speaker approval.')],[]),
('Which record should select interview seven\'s shelf group?','a','deletion',[f('Which record','The signed catalog allocation sheet selects the shelf group.','e7','Use the signed catalog allocation sheet to select the shelf group.')],[('deleted_resurrection','Interview seven belongs in shelf group D based on the removed early catalog note.')],[])],{1:['e3'],2:['e7','e9']})

history(8,[('a',[
('e1','user','For the Lark kite festival, open the large-kite lane only when the wind marshal records a speed below 20 knots. The limit protects the small-kite lane beside it.'),
('e2','tool','Festival checklist: fence placement complete; lane opening not checked.'),
('e3','user','I accept fence placement and close that task. Opening the lane is a separate decision.'),
('e4','assistant','The fence is ready, so I think the large-kite lane is open.'),
('e5','tool','Draft roster: lane steward is Pavi.')]),('b',[
('e6','user','For the Wren kite festival, the large-kite lane limit is 15 knots. This is Wren\'s rule.')]),('a',[
('e7','delete_observation','e5'),
('e8','user','Assign the lane steward from the signed morning roster.'),
('e9','user','Cancel the evening kite parade, but keep the afternoon safety briefing.'),
('e10','tool','Wind marshal log: 23 knots. Lane gate remains locked.'),
('e11','user','Fence placement stays closed. The locked lane gate does not reopen the fence task.')])],[
('When may Lark\'s large-kite lane open, and why is the wind limit in place?','a','conditional_requirement',[f('When','The wind marshal must record a speed below 20 knots before the lane opens.','e1','open the large-kite lane only when the wind marshal records a speed below 20 knots.'),f('why','The wind limit protects the adjacent small-kite lane.','e1','The limit protects the small-kite lane beside it.')],[],[]),
('Which scheduled activity survives the parade cancellation?','a','partial_cancellation',[f('survives','The afternoon safety briefing remains scheduled.','e9','keep the afternoon safety briefing.')],[],['The canceled parade was in the evening.']),
('Does the locked gate reopen fence placement, and what gate state was recorded?','a','genuine_closure',[f('reopen','Fence placement stays closed despite the locked lane gate.','e11','Fence placement stays closed. The locked lane gate does not reopen the fence task.'),f('gate state','The wind marshal log records that the lane gate remains locked.','e10','Lane gate remains locked.')],[('false_merge','The locked gate reopens fence placement.'),('false_closure','The lane has opened.')],['The wind speed is not requested here.']),
('What did the assistant assume about the lane, and what measurement did the marshal record?','a','source_roles',[f('assistant assume','The assistant thought the lane was open because the fence was ready.','e4','The fence is ready, so I think the large-kite lane is open.'),f('measurement','The marshal recorded 23 knots.','e10','Wind marshal log: 23 knots.')],[('false_closure','The assistant assumption establishes that the lane is open.')],[]),
('What wind limits apply to the large-kite lane at Lark and Wren?','both','project_isolation',[f('Lark','Lark requires a marshal-recorded speed below 20 knots.','e1','open the large-kite lane only when the wind marshal records a speed below 20 knots.'),f('Wren','Wren uses a 15-knot limit.','e6','For the Wren kite festival, the large-kite lane limit is 15 knots.')],[('project_mixing','Lark uses Wren\'s 15-knot limit.')],[]),
('How is the lane steward selected under the surviving instruction?','a','deletion',[f('How','Select the steward from the signed morning roster.','e8','Assign the lane steward from the signed morning roster.')],[('deleted_resurrection','Pavi is the steward based on the deleted draft roster.')],[])],{1:['e3','e5'],3:['e9']})

history(9,[('a',[
('e1','user','For the Moss ceramic commission, fire the blue glaze sample only after the kiln operator approves the test tile. We need the tile approval because this clay body is new.'),
('e2','user','The vase silhouette and glaze selection are separate approvals.'),
('e3','user','The vase silhouette is accepted. Close the silhouette task. Glaze selection stays open.'),
('e4','assistant','I photographed the accepted silhouette. I suspect that means the glaze is approved too.'),
('e5','tool','Superseded packing note: deliver in crate Z8.')]),('b',[
('e6','user','For the Fern ceramic commission, the client approves the test tile. The kiln operator does not replace that approval.')]),('a',[
('e7','delete_observation','e5'),
('e8','user','Use the crate specified on the final packing slip for Moss.'),
('e9','user','Reopen the silhouette to widen the base for stability. Leave its neck profile unchanged.'),
('e10','user','Cancel the gold stripe option. Continue testing the blue glaze.'),
('e11','tool','Glaze board: blue test tile awaiting kiln-operator approval.')])],[
('What approval gates Moss\'s blue glaze firing, and why?','a','conditional_requirement',[f('What approval','The kiln operator must approve the test tile before the blue glaze sample is fired.','e1','fire the blue glaze sample only after the kiln operator approves the test tile.'),f('why','The test tile needs approval because the clay body is new.','e1','We need the tile approval because this clay body is new.')],[],[]),
('What glaze work remains after the option was canceled?','a','partial_cancellation',[f('remains','Testing the blue glaze continues.','e10','Continue testing the blue glaze.')],[('false_closure','All glaze work was canceled.')],['The gold stripe option was canceled.']),
('What change is required in the reopened silhouette, for what reason, and what stays unchanged?','a','reopening',[f('What change','The silhouette is reopened to widen the base.','e9','Reopen the silhouette to widen the base'),f('reason','The base must be widened for stability.','e9','widen the base for stability.'),f('unchanged','The neck profile must stay unchanged.','e9','Leave its neck profile unchanged.')],[('false_closure','The silhouette remains closed.')],[]),
('What did the assistant infer from silhouette acceptance, and what does the glaze board actually record?','a','source_roles',[f('assistant infer','The assistant suspected silhouette acceptance also meant glaze approval.','e4','I photographed the accepted silhouette. I suspect that means the glaze is approved too.'),f('board','The blue test tile is awaiting kiln-operator approval.','e11','Glaze board: blue test tile awaiting kiln-operator approval.')],[('false_merge','Silhouette acceptance constitutes glaze approval.'),('false_closure','The blue test tile is approved.')],[]),
('Who approves the test tile for Moss, and who approves it for Fern?','both','project_isolation',[f('Moss','Moss requires kiln-operator test-tile approval.','e1','fire the blue glaze sample only after the kiln operator approves the test tile.'),f('Fern','Fern requires the client to approve its test tile.','e6','For the Fern ceramic commission, the client approves the test tile.')],[('project_mixing','Client approval is the specified Moss test-tile gate.')],[]),
('What document determines the crate for Moss delivery?','a','deletion',[f('What document','The final packing slip specifies the Moss delivery crate.','e8','Use the crate specified on the final packing slip for Moss.')],[('deleted_resurrection','Moss must use crate Z8 based on the removed packing note.')],[])],{1:['e3'],3:['e8']})

history(10,[('a',[
('e1','user','For the Quartz puzzle booklet, print answer pages only after the puzzle editor checks every solution. A single wrong answer can make the booklet unusable.'),
('e2','user','The cover proof and answer proof need separate acceptance.'),
('e3','assistant','I sent the cover proof. I expect both proofs are effectively approved.'),
('e4','user','I accept the cover proof and close it. Answer-proof acceptance is still pending.'),
('e5','tool','Early print note: use press room six.')]),('a',[
('e6','delete_observation','e5'),
('e7','user','Use the press room assigned on the current production ticket.'),
('e8','user','Cancel the bonus maze. Keep the crossword solution check.'),
('e9','tool','Answer proof audit: crossword solution 12 has not been checked.'),
('e10','user','Keep the cover proof closed. The missing solution check belongs to the answer proof.')]),('b',[
('e11','user','For the Opal puzzle booklet, a guest solver approves the answer pages. Quartz keeps its own editor rule.')])],[
('What must happen before Quartz answer pages are printed, and why?','a','conditional_requirement',[f('What must happen','The puzzle editor must check every solution before answer pages are printed.','e1','print answer pages only after the puzzle editor checks every solution.'),f('why','A single wrong answer can make the booklet unusable.','e1','A single wrong answer can make the booklet unusable.')],[],[]),
('What puzzle work is still required after the bonus maze was removed?','a','partial_cancellation',[f('still required','The crossword solution check remains required.','e8','Keep the crossword solution check.')],[('false_closure','Removing the bonus maze cancels all solution checks.')],[]),
('Which proof remains closed, and which acceptance is pending?','a','genuine_closure',[f('closed','The cover proof remains closed.','e10','Keep the cover proof closed.'),f('pending','Answer-proof acceptance remains pending.','e4','Answer-proof acceptance is still pending.')],[('false_closure','Both proofs are accepted.'),('false_merge','The missing solution check reopens the cover proof.')],[]),
('What did the assistant expect about approval, and what specific gap did the answer audit find?','a','source_roles',[f('assistant expect','The assistant expected both proofs were effectively approved.','e3','I expect both proofs are effectively approved.'),f('gap','The answer audit found crossword solution 12 had not been checked.','e9','Answer proof audit: crossword solution 12 has not been checked.')],[('false_closure','The assistant\'s expectation proves both proofs were accepted.')],[]),
('Who is responsible for checking or approving answer pages in Quartz and Opal?','both','project_isolation',[f('Quartz','Quartz requires its puzzle editor to check every solution before printing.','e1','print answer pages only after the puzzle editor checks every solution.'),f('Opal','Opal uses a guest solver to approve answer pages.','e11','For the Opal puzzle booklet, a guest solver approves the answer pages.')],[('project_mixing','A guest solver replaces the Quartz puzzle editor requirement.')],[]),
('Where should the press-room assignment be taken from?','a','deletion',[f('Where','The current production ticket determines the press room.','e7','Use the press room assigned on the current production ticket.')],[('deleted_resurrection','Press room six is the current assignment based on the deleted print note.')],[])],{1:['e4'],2:['e8']})

history(11,[('a',[
('e1','user','For the Dune lantern walk, light the hanging lanterns only after the fire steward approves the spacing. The spacing keeps hot lanterns away from fabric banners.'),
('e2','user','Route marking and lantern lighting are distinct tasks.'),
('e3','user','Accept the route marking and close it. Lantern lighting still awaits approval.'),
('e4','tool','Temporary volunteer list: spare lantern keeper is Yara.')]),('b',[
('e5','user','For the Reef lantern walk, the venue manager approves lantern spacing. Reef uses electric lanterns.')]),('a',[
('e6','assistant','I see the route markers are finished, so I think the lantern walk is ready to start.'),
('e7','delete_observation','e4'),
('e8','user','Get the spare lantern keeper from the final volunteer sign-in sheet.'),
('e9','user','Reopen route marking to move the turn marker away from the well. Keep the route itself unchanged.'),
('e10','user','Drop the closing drum procession, but keep the opening safety talk.'),
('e11','tool','Spacing inspection: approval withheld for the north banner section.')])],[
('What approval does Dune need before lighting hanging lanterns, and what does the spacing rule prevent?','a','conditional_requirement',[f('What approval','The fire steward must approve spacing before hanging lanterns are lit.','e1','light the hanging lanterns only after the fire steward approves the spacing.'),f('prevent','The spacing keeps hot lanterns away from fabric banners.','e1','The spacing keeps hot lanterns away from fabric banners.')],[],[]),
('Which gathering activity remains after the drum procession was dropped?','a','partial_cancellation',[f('remains','The opening safety talk remains required.','e10','keep the opening safety talk.')],[],[]),
('What is the new route-marking task, and does it change the route?','a','reopening',[f('new ... task','Route marking is reopened to move the turn marker away from the well.','e9','Reopen route marking to move the turn marker away from the well.'),f('change ... route','The route itself must stay unchanged.','e9','Keep the route itself unchanged.')],[('false_closure','Route marking remains closed.')],[]),
('What readiness did the assistant infer, and what did the spacing inspection say?','a','source_roles',[f('assistant infer','The assistant thought the walk was ready to start because route markers were finished.','e6','I see the route markers are finished, so I think the lantern walk is ready to start.'),f('inspection','Spacing approval was withheld for the north banner section.','e11','Spacing inspection: approval withheld for the north banner section.')],[('false_merge','Route-marker completion supplies lantern-lighting approval.'),('false_closure','Lantern spacing is fully approved.')],[]),
('Who approves lantern spacing for Dune and for Reef?','both','project_isolation',[f('Dune','Dune requires its fire steward to approve spacing.','e1','light the hanging lanterns only after the fire steward approves the spacing.'),f('Reef','Reef uses venue-manager spacing approval.','e5','For the Reef lantern walk, the venue manager approves lantern spacing.')],[('project_mixing','Venue-manager approval replaces Dune\'s fire-steward approval.')],['Reef lantern type is optional here.']),
('Which surviving record identifies the spare lantern keeper?','a','deletion',[f('Which ... record','The final volunteer sign-in sheet identifies the spare lantern keeper.','e8','Get the spare lantern keeper from the final volunteer sign-in sheet.')],[('deleted_resurrection','Yara is the spare lantern keeper based on the deleted temporary list.')],[])],{1:['e3','e4'],3:['e8']})

history(12,[('a',[
('e1','user','For the Elm chess league, post the final standings only after the arbiter resolves all disputed scores. A disputed score can change a qualifying place.'),
('e2','user','The venue booking and standings publication are separate jobs.'),
('e3','assistant','I confirmed the venue booking. I assume the league administration is finished.'),
('e4','user','The venue booking is accepted and closed. Standings publication remains blocked by the disputed scores.'),
('e5','tool','Old assignment sheet: trophy collector is Beto.')]),('a',[
('e6','delete_observation','e5'),
('e7','user','Choose the trophy collector from the signed duty roster.'),
('e8','user','Cancel the exhibition match, but retain the score-dispute hearing.'),
('e9','tool','Arbiter docket: two disputed scores remain unresolved.'),
('e10','user','The venue booking stays closed while the score hearing proceeds.')]),('b',[
('e11','user','For the Pine chess league, the league secretary resolves score disputes. This assignment applies only to Pine.')])],[
('What must happen before Elm posts final standings, and why does it matter?','a','conditional_requirement',[f('What must happen','The arbiter must resolve all disputed scores before final standings are posted.','e1','post the final standings only after the arbiter resolves all disputed scores.'),f('why','A disputed score can change a qualifying place.','e1','A disputed score can change a qualifying place.')],[],[]),
('Which event remains scheduled after the exhibition match was canceled?','a','partial_cancellation',[f('remains','The score-dispute hearing remains scheduled.','e8','retain the score-dispute hearing.')],[('false_closure','The score-dispute hearing was canceled with the exhibition match.')],[]),
('What is the venue-booking state during the hearing, and what blocks publication?','a','genuine_closure',[f('venue-booking state','The venue booking stays closed during the hearing.','e10','The venue booking stays closed while the score hearing proceeds.'),f('blocks','Standings publication is blocked by disputed scores.','e4','Standings publication remains blocked by the disputed scores.')],[('false_closure','Standings publication is complete.'),('false_merge','Score disputes reopen venue booking.')],[]),
('What did the assistant assume about administration, and what unresolved work does the docket show?','a','source_roles',[f('assistant assume','The assistant assumed league administration was finished after confirming venue booking.','e3','I confirmed the venue booking. I assume the league administration is finished.'),f('docket','The arbiter docket shows two unresolved disputed scores.','e9','Arbiter docket: two disputed scores remain unresolved.')],[('false_closure','All league administration is complete.')],[]),
('Who resolves disputed scores in Elm and in Pine?','both','project_isolation',[f('Elm','Elm requires the arbiter to resolve all disputed scores.','e1','post the final standings only after the arbiter resolves all disputed scores.'),f('Pine','Pine assigns score disputes to its league secretary only for Pine.','e11','For the Pine chess league, the league secretary resolves score disputes. This assignment applies only to Pine.')],[('project_mixing','The league secretary is Elm\'s assigned score-dispute authority.')],[]),
('How should the trophy collector be selected?','a','deletion',[f('How','Select the trophy collector from the signed duty roster.','e7','Choose the trophy collector from the signed duty roster.')],[('deleted_resurrection','Beto is the trophy collector based on the removed assignment sheet.')],[])],{1:['e4'],2:['e8']})

history(13,[('a',[
('e1','user','For the Garnet puppet show, raise the overhead scenery only after the stage rigger signs the load sheet. The signature is required because children perform underneath.'),
('e2','user','The puppet repair and scenery rigging are different tasks.'),
('e3','user','Accept the puppet repair and close it. Scenery rigging remains pending.'),
('e4','assistant','The repaired puppet looks good. I would count scenery setup as done too.'),
('e5','tool','Preliminary prop note: spare crown is in trunk L2.')]),('b',[
('e6','user','For the Ruby puppet show, the venue engineer signs the scenery load sheet. That is Ruby\'s approval route.')]),('a',[
('e7','delete_observation','e5'),
('e8','user','Locate the spare crown through the current prop inventory.'),
('e9','user','Reopen the puppet repair to loosen its left wrist, because it cannot hold the cup. Keep the new paint untouched.'),
('e10','user','Cancel the extra curtain backdrop. Still finish the overhead scenery inspection.'),
('e11','tool','Load-sheet reader: stage-rigger signature absent.')])],[
('What authorization is required to raise Garnet\'s scenery, and why?','a','conditional_requirement',[f('authorization','The stage rigger must sign the load sheet before overhead scenery is raised.','e1','raise the overhead scenery only after the stage rigger signs the load sheet.'),f('why','The signature is required because children perform underneath.','e1','The signature is required because children perform underneath.')],[],[]),
('Which scenery work survives the backdrop cancellation?','a','partial_cancellation',[f('survives','The overhead scenery inspection must still be finished.','e10','Still finish the overhead scenery inspection.')],[('false_closure','All scenery work was canceled.')],[]),
('What reopened the puppet repair, and what must the repair leave untouched?','a','reopening',[f('What reopened','The repair reopened to loosen the left wrist because the puppet cannot hold the cup.','e9','Reopen the puppet repair to loosen its left wrist, because it cannot hold the cup.'),f('untouched','The new paint must remain untouched.','e9','Keep the new paint untouched.')],[('false_closure','Puppet repair remains closed.')],[]),
('What did the assistant say about scenery setup, and what authorization evidence did the reader find?','a','source_roles',[f('assistant say','The assistant would count scenery setup as done because the repaired puppet looked good.','e4','The repaired puppet looks good. I would count scenery setup as done too.'),f('evidence','The load-sheet reader found no stage-rigger signature.','e11','Load-sheet reader: stage-rigger signature absent.')],[('false_merge','Puppet repair completion establishes scenery setup completion.'),('false_closure','Scenery authorization is complete.')],[]),
('Who signs the scenery load sheet in Garnet and Ruby?','both','project_isolation',[f('Garnet','Garnet requires the stage rigger to sign the load sheet.','e1','raise the overhead scenery only after the stage rigger signs the load sheet.'),f('Ruby','Ruby requires its venue engineer to sign the load sheet.','e6','For the Ruby puppet show, the venue engineer signs the scenery load sheet.')],[('project_mixing','The venue engineer is Garnet\'s specified load-sheet signer.')],[]),
('Which source should be used to locate the spare crown?','a','deletion',[f('Which source','Use the current prop inventory to locate the spare crown.','e8','Locate the spare crown through the current prop inventory.')],[('deleted_resurrection','The spare crown is in trunk L2 based on the deleted preliminary note.')],[])],{1:['e3'],3:['e8','e10']})

history(14,[('a',[
('e1','user','For the Kestrel map club, share the cave map only after the land custodian approves the marked entrances. The approval protects access points that must stay private.'),
('e2','user','The scale-bar correction and entrance review need separate sign-off.'),
('e3','assistant','I fixed the scale bar. I think the whole map is cleared for sharing.'),
('e4','user','I accept and close the scale-bar correction. Entrance review remains open.'),
('e5','tool','Temporary map index: backup sheet is in drawer Q.')]),('b',[
('e6','user','For the Osprey map club, the park surveyor approves marked entrances. This rule does not apply to Kestrel.')]),('a',[
('e7','delete_observation','e5'),
('e8','user','Find the backup sheet using the controlled map index.'),
('e9','user','Cancel the decorative compass rose. Keep the entrance review.'),
('e10','tool','Review ledger: entrance E3 not approved for sharing.'),
('e11','user','The scale-bar correction remains closed despite the open entrance review.')])],[
('What must happen before Kestrel shares its cave map, and what does that protect?','a','conditional_requirement',[f('What must happen','The land custodian must approve the marked entrances before the cave map is shared.','e1','share the cave map only after the land custodian approves the marked entrances.'),f('protect','The approval protects access points that must stay private.','e1','The approval protects access points that must stay private.')],[],[]),
('What review remains after the decorative compass rose was canceled?','a','partial_cancellation',[f('remains','The entrance review remains required.','e9','Keep the entrance review.')],[('false_closure','Canceling the compass rose cancels entrance review.')],[]),
('Is the scale-bar correction open again, and what is the entrance-review state?','a','genuine_closure',[f('scale-bar','The scale-bar correction remains closed.','e11','The scale-bar correction remains closed despite the open entrance review.'),f('entrance-review','Entrance review remains open.','e4','Entrance review remains open.')],[('false_merge','Entrance review reopens the scale-bar correction.'),('false_closure','Entrance review is complete.')],[]),
('What did the assistant claim about sharing, and what specific exception is in the review ledger?','a','source_roles',[f('assistant claim','The assistant thought the whole map was cleared for sharing after fixing the scale bar.','e3','I fixed the scale bar. I think the whole map is cleared for sharing.'),f('exception','Entrance E3 is not approved for sharing in the review ledger.','e10','Review ledger: entrance E3 not approved for sharing.')],[('false_closure','The map is fully cleared for sharing.')],[]),
('Who approves marked entrances for Kestrel and for Osprey?','both','project_isolation',[f('Kestrel','Kestrel requires the land custodian to approve marked entrances.','e1','share the cave map only after the land custodian approves the marked entrances.'),f('Osprey','Osprey uses park-surveyor approval.','e6','For the Osprey map club, the park surveyor approves marked entrances.')],[('project_mixing','Park-surveyor approval satisfies Kestrel\'s specified gate.')],[]),
('How should the backup map sheet be located now?','a','deletion',[f('How','Use the controlled map index to find the backup sheet.','e8','Find the backup sheet using the controlled map index.')],[('deleted_resurrection','The backup sheet is in drawer Q based on the deleted temporary index.')],[])],{1:['e4'],3:['e9']})

history(15,[('a',[
('e1','user','For the Citrine clock exhibit, start the pendulum only after the conservator approves the mounting bracket. The old case cannot bear an unchecked load.'),
('e2','user','Dial cleaning and bracket approval are separate tasks.'),
('e3','user','Accept dial cleaning and close it. Bracket approval is pending.'),
('e4','assistant','The dial is clean, so I assume the clock can run now.'),
('e5','tool','Early equipment card: winding key is held by Leto.')]),('a',[
('e6','delete_observation','e5'),
('e7','user','Obtain the winding key from the custodian named in the signed equipment register.'),
('e8','user','Reopen dial cleaning to remove one fingerprint near twelve. Preserve the remaining patina.'),
('e9','user','Cancel polishing the rear panel. Keep the mounting-bracket inspection.'),
('e10','tool','Bracket inspection record: conservator decision deferred.')]),('b',[
('e11','user','For the Amber clock exhibit, the mechanical curator approves the mounting bracket. That permission is limited to Amber.')])],[
('What approval is needed before Citrine\'s pendulum starts, and why?','a','conditional_requirement',[f('What approval','The conservator must approve the mounting bracket before the pendulum starts.','e1','start the pendulum only after the conservator approves the mounting bracket.'),f('why','The old case cannot bear an unchecked load.','e1','The old case cannot bear an unchecked load.')],[],[]),
('Which inspection remains required after rear-panel polishing was canceled?','a','partial_cancellation',[f('remains','The mounting-bracket inspection remains required.','e9','Keep the mounting-bracket inspection.')],[('false_closure','Canceling rear-panel polishing cancels the bracket inspection.')],[]),
('What must the reopened dial-cleaning task remove, and what must it preserve?','a','reopening',[f('remove','The reopened dial-cleaning task must remove one fingerprint near twelve.','e8','Reopen dial cleaning to remove one fingerprint near twelve.'),f('preserve','The remaining patina must be preserved.','e8','Preserve the remaining patina.')],[('false_closure','Dial cleaning remains closed.')],[]),
('What running permission did the assistant assume, and what did the bracket record actually say?','a','source_roles',[f('assistant assume','The assistant assumed the clock could run because the dial was clean.','e4','The dial is clean, so I assume the clock can run now.'),f('record','The bracket inspection record says the conservator decision is deferred.','e10','Bracket inspection record: conservator decision deferred.')],[('false_merge','Dial-cleaning acceptance gives bracket approval.'),('false_closure','The conservator approved the bracket.')],[]),
('Who approves the mounting bracket for Citrine and for Amber?','both','project_isolation',[f('Citrine','Citrine requires conservator approval of the bracket.','e1','start the pendulum only after the conservator approves the mounting bracket.'),f('Amber','Amber requires mechanical-curator approval limited to Amber.','e11','For the Amber clock exhibit, the mechanical curator approves the mounting bracket. That permission is limited to Amber.')],[('project_mixing','The mechanical curator can replace Citrine\'s conservator approval.')],[]),
('From whom should the winding key be obtained under the surviving instruction?','a','deletion',[f('From whom','Obtain the winding key from the custodian named in the signed equipment register.','e7','Obtain the winding key from the custodian named in the signed equipment register.')],[('deleted_resurrection','Leto is the authorized key holder based on the deleted early equipment card.')],[])],{1:['e3','e5'],2:['e7','e9']})

history(16,[('a',[
('e1','user','For the Brook astronomy camp, uncover the public telescope only after the instrument lead verifies the solar filter lock. The lock prevents the filter from slipping during daytime viewing.'),
('e2','user','Tent setup and telescope readiness are separate approvals.'),
('e3','assistant','The tents are up. I expect the camp is fully ready for observers.'),
('e4','user','Tent setup is accepted and closed. Telescope readiness remains blocked until the filter-lock check.'),
('e5','tool','Draft equipment route: spare eyepiece is in case M.')]),('b',[
('e6','user','For the Lake astronomy camp, the optics technician verifies the solar filter lock. This appointment is for Lake only.')]),('a',[
('e7','delete_observation','e5'),
('e8','user','Locate the spare eyepiece from the current equipment checkout ledger.'),
('e9','user','Cancel the evening constellation quiz. Retain the daytime filter-lock demonstration.'),
('e10','tool','Instrument log: filter-lock check not performed; public telescope remains covered.'),
('e11','user','Keep tent setup closed while telescope readiness is pending.')])],[
('What must happen before Brook uncovers its telescope, and why is the lock needed?','a','conditional_requirement',[f('What must happen','The instrument lead must verify the solar filter lock before the public telescope is uncovered.','e1','uncover the public telescope only after the instrument lead verifies the solar filter lock.'),f('why','The lock prevents the filter from slipping during daytime viewing.','e1','The lock prevents the filter from slipping during daytime viewing.')],[],[]),
('Which demonstration remains after the quiz was canceled?','a','partial_cancellation',[f('remains','The daytime filter-lock demonstration remains required.','e9','Retain the daytime filter-lock demonstration.')],[],[]),
('What is the tent-setup state now, and what blocks telescope readiness?','a','genuine_closure',[f('tent-setup','Tent setup remains closed while telescope readiness is pending.','e11','Keep tent setup closed while telescope readiness is pending.'),f('blocks','Telescope readiness is blocked until the filter-lock check.','e4','Telescope readiness remains blocked until the filter-lock check.')],[('false_merge','Pending telescope readiness reopens tent setup.'),('false_closure','Telescope readiness is complete.')],[]),
('What readiness did the assistant expect, and what telescope state did the instrument log record?','a','source_roles',[f('assistant expect','The assistant expected the whole camp was ready for observers after the tents were up.','e3','The tents are up. I expect the camp is fully ready for observers.'),f('telescope state','The public telescope remains covered in the instrument log.','e10','public telescope remains covered.')],[('false_closure','The camp is fully ready for observers based on the assistant expectation.')],['The missing filter-lock check is the recorded reason for the blocked readiness, but this question asks the telescope state.']),
('Who verifies the solar filter lock at Brook and at Lake?','both','project_isolation',[f('Brook','Brook assigns the solar-filter-lock verification to the instrument lead.','e1','uncover the public telescope only after the instrument lead verifies the solar filter lock.'),f('Lake','Lake assigns the verification to the optics technician for Lake only.','e6','For the Lake astronomy camp, the optics technician verifies the solar filter lock. This appointment is for Lake only.')],[('project_mixing','The optics technician replaces Brook\'s instrument-lead requirement.')],[]),
('Which record should locate the spare eyepiece?','a','deletion',[f('Which record','The current equipment checkout ledger locates the spare eyepiece.','e8','Locate the spare eyepiece from the current equipment checkout ledger.')],[('deleted_resurrection','The spare eyepiece is in case M based on the deleted draft route.')],[])],{1:['e4'],3:['e9']})

fixture={'schema_version':1,'fictional':True,'split':'holdout','histories':H}
gold={'schema_version':1,'fictional':True,'questions':G}
rationale={'schema_version':1,'version':'v001','purpose':'Sealed per-fact question responsiveness rationale. Not a reader input.','questions':R,'author_notes':['All scenario names and events are invented. Each history is independent and uses its own project identifiers.','The same six broad question functions provide coverage across independent domains. Odd histories contain a real cross-chat reopening; even histories preserve genuine closure of one task while a separate task remains pending.','Required facts preserve conditions, requested reasons, source roles, task boundaries and project scope. Question-independent details are optional.','Deletion controls remove exactly one original per history. Positive facts use surviving rules, never deleted claims or deletion actions.','Independent review must assess minimal span sufficiency and conjunction completeness. Mechanical validation establishes representability only.']}
def write_new(name,obj):
    with (ROOT/name).open('x') as out: json.dump(obj,out,ensure_ascii=False,indent=2); out.write('\n')
write_new('holdout-fixture.v001.json',fixture);write_new('holdout-gold.v001.json',gold);write_new('author-fact-rationale.v001.json',rationale)
spec=importlib.util.spec_from_file_location('sealed_public_contract',PACK/'public-fixture-contract.py'); contract=importlib.util.module_from_spec(spec);spec.loader.exec_module(contract)
try:
    result=contract.validate_files(ROOT/'holdout-fixture.v001.json',ROOT/'holdout-gold.v001.json')
except Exception:
    with (ROOT/'validation-v001-failed.txt').open('x') as out:out.write(traceback.format_exc())
    raise
write_new('mechanical-validation.v001.json',result)
for src,dst in [('holdout-fixture.v001.json','holdout-fixture.json'),('holdout-gold.v001.json','holdout-gold.json'),('author-fact-rationale.v001.json','author-fact-rationale.json')]:
    with (ROOT/dst).open('xb') as out:out.write((ROOT/src).read_bytes())
print(json.dumps({'histories':len(H),'questions':len(G),'facts':sum(len(v['required_facts']) for v in G.values()),'deletions':result['deletion_controls'],'status':result['status']}))
